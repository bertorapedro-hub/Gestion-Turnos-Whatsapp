#!/bin/sh
set -e

echo "Esperando a Postgres..."
until node -e "require('node:net').connect(5432,'postgres').on('connect',()=>process.exit(0)).on('error',()=>process.exit(1))" 2>/dev/null; do
  sleep 2
done
echo "Postgres disponible."

npx prisma migrate deploy --schema=prisma/postgres/schema.prisma

exec node dist/index.js
