import "dotenv/config";
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import { authRouter } from "./routes/auth.routes.js";
import { superadminRouter } from "./routes/superadmin.routes.js";
import { businessRouter } from "./routes/business/index.js";
import { publicRouter } from "./routes/public.routes.js";
import { actionsRouter } from "./routes/actions.routes.js";
import { startScheduler } from "./jobs/scheduler.js";
import { reconnectLinkedBusinesses } from "./lib/whatsapp.js";

const app = express();
const PORT = Number(process.env.PORT ?? 4000);

app.use(
  cors({
    origin: process.env.PUBLIC_APP_URL ?? "http://localhost:5173",
    credentials: true,
  })
);
app.use(express.json());
app.use(cookieParser());
app.use("/uploads", express.static("uploads"));

app.use("/api/auth", authRouter);
app.use("/api/superadmin", superadminRouter);
app.use("/api/business", businessRouter);
app.use("/api/public", publicRouter);
app.use("/api/actions", actionsRouter);

app.get("/api/health", (_req, res) => res.json({ ok: true }));

// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err);
  res.status(err.status ?? 500).json({ error: err.message ?? "Error interno" });
});

app.listen(PORT, () => {
  console.log(`Backend escuchando en http://localhost:${PORT}`);
  startScheduler();
  reconnectLinkedBusinesses().catch((err) => console.error("Error reconectando WhatsApp:", err));
});
