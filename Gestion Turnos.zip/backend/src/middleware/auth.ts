import type { NextFunction, Request, Response } from "express";
import { AUTH_COOKIE_NAME, verifyAuthToken, type AuthTokenPayload } from "../lib/jwt.js";
import { Role } from "../lib/constants.js";
import { prisma } from "../lib/prisma.js";

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      auth?: AuthTokenPayload;
    }
  }
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const token = req.cookies?.[AUTH_COOKIE_NAME];
  if (!token) return res.status(401).json({ error: "No autenticado" });
  try {
    req.auth = verifyAuthToken(token);
    next();
  } catch {
    return res.status(401).json({ error: "Sesión inválida o expirada" });
  }
}

export function requireSuperadmin(req: Request, res: Response, next: NextFunction) {
  if (req.auth?.role !== Role.SUPERADMIN) {
    return res.status(403).json({ error: "Acceso restringido al superadministrador" });
  }
  next();
}

/**
 * Exige un usuario de negocio autenticado y además, si el negocio fue pausado
 * por el superadmin después de emitido el token, corta el acceso igual.
 */
export async function requireBusinessOwner(req: Request, res: Response, next: NextFunction) {
  if (req.auth?.role !== Role.BUSINESS_OWNER || !req.auth.businessId) {
    return res.status(403).json({ error: "Acceso restringido al panel de negocio" });
  }
  const business = await prisma.business.findUnique({ where: { id: req.auth.businessId } });
  if (!business || !business.isActive) {
    return res.status(403).json({ error: "El negocio está pausado o no existe" });
  }
  next();
}

/** businessId del negocio autenticado; nunca se toma de params/body del cliente. */
export function currentBusinessId(req: Request): string {
  if (!req.auth?.businessId) throw new Error("No hay businessId en el contexto de auth");
  return req.auth.businessId;
}
