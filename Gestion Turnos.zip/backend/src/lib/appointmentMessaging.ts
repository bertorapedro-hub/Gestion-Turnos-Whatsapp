import type { Appointment, Business, Client, Professional, Service } from "@prisma/client";
import { sendAndLog } from "./messaging.js";
import { RecipientType, type MessageEventType } from "./constants.js";

type FullAppointment = Appointment & { client: Client; professional: Professional; service: Service };

export function appointmentVars(appointment: FullAppointment, business: Business): Record<string, string> {
  return {
    cliente: appointment.client.fullName,
    profesional: appointment.professional.name,
    servicio: appointment.service.name,
    negocio: business.name,
    fecha: appointment.startAt.toLocaleDateString("es-AR"),
    hora: appointment.startAt.toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" }),
  };
}

/** Avisa a la otra parte (cliente o profesional) cuando alguien actuó sobre el turno. */
export async function notifyOtherParty(
  appointment: FullAppointment,
  business: Business,
  templateBody: string,
  eventType: MessageEventType,
  actedBy: "CLIENT" | "PROFESSIONAL" | "BUSINESS",
  extraVars: Record<string, string> = {}
) {
  const vars = { ...appointmentVars(appointment, business), ...extraVars };
  const body = templateBody.replace(/\{\{(\w+)\}\}/g, (_m, k: string) => vars[k] ?? "");

  if (actedBy === "CLIENT" && appointment.professional.phone) {
    await sendAndLog({
      businessId: business.id,
      phone: appointment.professional.phone,
      body,
      eventType,
      recipientType: RecipientType.PROFESSIONAL,
      recipientName: appointment.professional.name,
      appointmentId: appointment.id,
    });
  } else if ((actedBy === "PROFESSIONAL" || actedBy === "BUSINESS") && appointment.client.phone) {
    await sendAndLog({
      businessId: business.id,
      phone: appointment.client.phone,
      body,
      eventType,
      recipientType: RecipientType.CLIENT,
      recipientName: appointment.client.fullName,
      appointmentId: appointment.id,
    });
  }
}
