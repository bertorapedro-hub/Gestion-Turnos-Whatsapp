import makeWASocket, { DisconnectReason, fetchLatestBaileysVersion, type WASocket } from "@whiskeysockets/baileys";
import QRCode from "qrcode";
import { prisma } from "./prisma.js";
import { useDbAuthState, clearAuthState } from "./whatsappAuthStore.js";
import { WhatsAppStatus } from "./constants.js";

interface Session {
  socket: WASocket;
  qr: string | null;
}

const sessions = new Map<string, Session>();

export async function getWhatsAppStatus(businessId: string): Promise<{ status: string; phoneNumber: string | null }> {
  const session = await prisma.whatsAppSession.findUnique({ where: { businessId } });
  return { status: session?.status ?? WhatsAppStatus.DISCONNECTED, phoneNumber: session?.phoneNumber ?? null };
}

export function getCurrentQR(businessId: string): string | null {
  return sessions.get(businessId)?.qr ?? null;
}

function toJid(phone: string): string {
  const digits = phone.replace(/\D/g, "");
  return `${digits}@s.whatsapp.net`;
}

export async function connectBusiness(businessId: string): Promise<void> {
  if (sessions.has(businessId)) return;

  const { state, saveCreds } = await useDbAuthState(businessId);
  const { version } = await fetchLatestBaileysVersion();

  const socket = makeWASocket({ version, auth: state, printQRInTerminal: false });
  sessions.set(businessId, { socket, qr: null });

  await prisma.whatsAppSession.upsert({
    where: { businessId },
    update: { status: WhatsAppStatus.CONNECTING },
    create: { businessId, status: WhatsAppStatus.CONNECTING },
  });

  socket.ev.on("creds.update", saveCreds);

  socket.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;
    const current = sessions.get(businessId);

    if (qr && current) {
      current.qr = await QRCode.toDataURL(qr);
    }

    if (connection === "open") {
      const phoneNumber = socket.user?.id?.split(":")[0] ?? null;
      if (current) current.qr = null;
      await prisma.whatsAppSession.upsert({
        where: { businessId },
        update: { status: WhatsAppStatus.CONNECTED, phoneNumber },
        create: { businessId, status: WhatsAppStatus.CONNECTED, phoneNumber },
      });
    }

    if (connection === "close") {
      sessions.delete(businessId);
      const statusCode = (lastDisconnect?.error as { output?: { statusCode?: number } } | undefined)?.output
        ?.statusCode;

      if (statusCode === DisconnectReason.loggedOut) {
        await clearAuthState(businessId);
        await prisma.whatsAppSession.upsert({
          where: { businessId },
          update: { status: WhatsAppStatus.DISCONNECTED, phoneNumber: null },
          create: { businessId, status: WhatsAppStatus.DISCONNECTED },
        });
      } else {
        await prisma.whatsAppSession.upsert({
          where: { businessId },
          update: { status: WhatsAppStatus.DISCONNECTED },
          create: { businessId, status: WhatsAppStatus.DISCONNECTED },
        });
        // Reconexión automática ante cortes que no son un logout explícito (ej: reinicio del server, caída de red).
        setTimeout(() => connectBusiness(businessId).catch(() => {}), 3000);
      }
    }
  });
}

export async function disconnectBusiness(businessId: string): Promise<void> {
  const session = sessions.get(businessId);
  if (session) {
    await session.socket.logout().catch(() => {});
    sessions.delete(businessId);
  }
  await clearAuthState(businessId);
  await prisma.whatsAppSession.upsert({
    where: { businessId },
    update: { status: WhatsAppStatus.DISCONNECTED, phoneNumber: null },
    create: { businessId, status: WhatsAppStatus.DISCONNECTED },
  });
}

export async function sendText(businessId: string, phone: string, text: string): Promise<void> {
  const session = sessions.get(businessId);
  const dbStatus = await getWhatsAppStatus(businessId);
  if (!session || dbStatus.status !== WhatsAppStatus.CONNECTED) {
    throw new Error("WhatsApp no está vinculado para este negocio");
  }
  await session.socket.sendMessage(toJid(phone), { text });
}

/** Reintenta reconectar los negocios que estaban vinculados antes de un reinicio del proceso. */
export async function reconnectLinkedBusinesses(): Promise<void> {
  const linked = await prisma.whatsAppSession.findMany({ where: { status: WhatsAppStatus.CONNECTED } });
  for (const session of linked) {
    connectBusiness(session.businessId).catch((err) => {
      console.error(`No se pudo reconectar WhatsApp del negocio ${session.businessId}:`, err);
    });
  }
}
