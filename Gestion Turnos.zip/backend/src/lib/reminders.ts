import type { Prisma } from "@prisma/client";
import { prisma } from "./prisma.js";
import { AppointmentStatus, CancelledBy, MessageEventType, RecipientType } from "./constants.js";
import { renderTemplate, sendAndLog, getTemplateBody } from "./messaging.js";
import { createActionLinks, invalidateActionLinks, publicBookingUrl } from "./actionTokens.js";
import { appointmentVars } from "./appointmentMessaging.js";

const appointmentInclude = { client: true, professional: true, service: true, business: true } satisfies Prisma.AppointmentInclude;
type AppointmentWithRelations = Prisma.AppointmentGetPayload<{ include: typeof appointmentInclude }>;

async function sendClientActionReminder(appointment: AppointmentWithRelations, eventType: string) {
  const templateBody = await getTemplateBody(appointment.businessId, eventType);
  if (!templateBody) return;

  const links = await createActionLinks(appointment.id, RecipientType.CLIENT);
  const vars = {
    ...appointmentVars(appointment, appointment.business),
    link_confirmar: links.confirmUrl,
    link_cancelar: links.cancelUrl,
    link_modificar: links.modifyUrl,
  };
  const body = renderTemplate(templateBody, vars);

  await sendAndLog({
    businessId: appointment.businessId,
    phone: appointment.client.phone,
    body,
    eventType,
    recipientType: RecipientType.CLIENT,
    recipientName: appointment.client.fullName,
    appointmentId: appointment.id,
  });
}

async function processDayReminders(now: Date) {
  const businesses = await prisma.business.findMany({ where: { isActive: true } });
  for (const business of businesses) {
    const threshold = new Date(now.getTime() + business.reminderDaysBefore * 24 * 60 * 60 * 1000);
    // eslint-disable-next-line no-await-in-loop
    const appointments = await prisma.appointment.findMany({
      where: {
        businessId: business.id,
        // Los recordatorios solo aplican a turnos ya CONFIRMED: en "pedir turno ya lo confirma"
        // nunca queda PENDING, y en "el profesional aprueba" no tiene sentido recordárselo al
        // cliente hasta que alguien lo aprobó.
        status: AppointmentStatus.CONFIRMED,
        reminderDaySentAt: null,
        startAt: { gt: now, lte: threshold },
      },
      include: appointmentInclude,
    });
    for (const appointment of appointments) {
      // eslint-disable-next-line no-await-in-loop
      await sendClientActionReminder(appointment, MessageEventType.REMINDER_DAY);
      // eslint-disable-next-line no-await-in-loop
      await prisma.appointment.update({ where: { id: appointment.id }, data: { reminderDaySentAt: now } });
    }
  }
}

async function processHourReminders(now: Date) {
  const businesses = await prisma.business.findMany({ where: { isActive: true } });
  for (const business of businesses) {
    const threshold = new Date(now.getTime() + business.reminderHoursBefore * 60 * 60 * 1000);
    // eslint-disable-next-line no-await-in-loop
    const appointments = await prisma.appointment.findMany({
      where: {
        businessId: business.id,
        status: AppointmentStatus.CONFIRMED,
        reminderHourSentAt: null,
        startAt: { gt: now, lte: threshold },
      },
      include: appointmentInclude,
    });
    for (const appointment of appointments) {
      // eslint-disable-next-line no-await-in-loop
      await sendClientActionReminder(appointment, MessageEventType.REMINDER_HOUR);
      // eslint-disable-next-line no-await-in-loop
      await prisma.appointment.update({ where: { id: appointment.id }, data: { reminderHourSentAt: now } });
    }
  }
}

async function sendProfessionalApprovalReminder(appointment: AppointmentWithRelations) {
  if (!appointment.professional.phone) return;
  const templateBody = await getTemplateBody(appointment.businessId, MessageEventType.PROFESSIONAL_APPROVAL_REQUEST);
  if (!templateBody) return;

  const links = await createActionLinks(appointment.id, RecipientType.PROFESSIONAL);
  const vars = {
    ...appointmentVars(appointment, appointment.business),
    link_confirmar: links.confirmUrl,
    link_cancelar: links.cancelUrl,
  };

  await sendAndLog({
    businessId: appointment.businessId,
    phone: appointment.professional.phone,
    body: renderTemplate(templateBody, vars),
    eventType: MessageEventType.PROFESSIONAL_APPROVAL_REQUEST,
    recipientType: RecipientType.PROFESSIONAL,
    recipientName: appointment.professional.name,
    appointmentId: appointment.id,
  });
}

async function processUnconfirmedFollowups(now: Date) {
  const businesses = await prisma.business.findMany({ where: { isActive: true } });
  for (const business of businesses) {
    const threshold = new Date(now.getTime() - business.unconfirmedFollowupHours * 60 * 60 * 1000);
    // eslint-disable-next-line no-await-in-loop
    const appointments = await prisma.appointment.findMany({
      where: {
        businessId: business.id,
        status: AppointmentStatus.PENDING,
        unconfirmedFollowupSentAt: null,
        startAt: { gt: now },
        createdAt: { lte: threshold },
      },
      include: appointmentInclude,
    });
    for (const appointment of appointments) {
      // PENDING solo existe en el modo "el profesional aprueba" (en "pedir turno ya lo confirma"
      // un turno nunca queda pendiente), así que quien tiene que actuar acá es siempre el profesional.
      // eslint-disable-next-line no-await-in-loop
      await sendProfessionalApprovalReminder(appointment);
      // eslint-disable-next-line no-await-in-loop
      await prisma.appointment.update({ where: { id: appointment.id }, data: { unconfirmedFollowupSentAt: now } });
    }
  }
}

async function processAutoCancelUnconfirmed(now: Date) {
  const businesses = await prisma.business.findMany({ where: { isActive: true, autoCancelHoursBefore: { gt: 0 } } });
  for (const business of businesses) {
    const threshold = new Date(now.getTime() + business.autoCancelHoursBefore * 60 * 60 * 1000);
    // eslint-disable-next-line no-await-in-loop
    const appointments = await prisma.appointment.findMany({
      where: {
        businessId: business.id,
        status: AppointmentStatus.PENDING,
        startAt: { gt: now, lte: threshold },
      },
      include: appointmentInclude,
    });
    for (const appointment of appointments) {
      // eslint-disable-next-line no-await-in-loop
      await prisma.appointment.update({
        where: { id: appointment.id },
        data: { status: AppointmentStatus.CANCELLED, cancelledBy: CancelledBy.BUSINESS },
      });
      // eslint-disable-next-line no-await-in-loop
      await invalidateActionLinks(appointment.id);

      // eslint-disable-next-line no-await-in-loop
      const templateBody = await getTemplateBody(business.id, MessageEventType.AUTO_CANCELLED_UNCONFIRMED);
      if (templateBody) {
        const body = renderTemplate(templateBody, {
          ...appointmentVars(appointment, business),
          link_reservar: publicBookingUrl(business.slug),
        });
        // eslint-disable-next-line no-await-in-loop
        await sendAndLog({
          businessId: business.id,
          phone: appointment.client.phone,
          body,
          eventType: MessageEventType.AUTO_CANCELLED_UNCONFIRMED,
          recipientType: RecipientType.CLIENT,
          recipientName: appointment.client.fullName,
          appointmentId: appointment.id,
        });
      }
    }
  }
}

function todayStr(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

async function processDailySummaries(now: Date) {
  const currentHHMM = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  const today = todayStr(now);

  const businesses = await prisma.business.findMany({
    where: { isActive: true, dailySummaryLastSentDate: { not: today } },
  });

  for (const business of businesses) {
    if (currentHHMM < business.dailySummaryTime) continue;

    // eslint-disable-next-line no-await-in-loop
    const templateBody = await getTemplateBody(business.id, MessageEventType.DAILY_SUMMARY);
    if (!templateBody) continue;

    const dayStart = new Date(now);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(now);
    dayEnd.setHours(23, 59, 59, 999);

    // eslint-disable-next-line no-await-in-loop
    const professionals = await prisma.professional.findMany({ where: { businessId: business.id, isActive: true } });

    for (const professional of professionals) {
      // eslint-disable-next-line no-await-in-loop
      const appointments = await prisma.appointment.findMany({
        where: {
          professionalId: professional.id,
          status: { not: AppointmentStatus.CANCELLED },
          startAt: { gte: dayStart, lte: dayEnd },
        },
        include: { client: true, service: true },
        orderBy: { startAt: "asc" },
      });

      if (!professional.phone) continue;

      const lista =
        appointments.length === 0
          ? "No tenés turnos para hoy."
          : appointments
              .map(
                (a) =>
                  `${a.startAt.toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" })} - ${a.client.fullName} (${a.service.name})`
              )
              .join("\n");

      const body = renderTemplate(templateBody, {
        profesional: professional.name,
        negocio: business.name,
        fecha: now.toLocaleDateString("es-AR"),
        lista_turnos: lista,
      });

      // eslint-disable-next-line no-await-in-loop
      await sendAndLog({
        businessId: business.id,
        phone: professional.phone,
        body,
        eventType: MessageEventType.DAILY_SUMMARY,
        recipientType: RecipientType.PROFESSIONAL,
        recipientName: professional.name,
      });
    }

    // eslint-disable-next-line no-await-in-loop
    await prisma.business.update({ where: { id: business.id }, data: { dailySummaryLastSentDate: today } });
  }
}

export async function processDueReminders(): Promise<void> {
  const now = new Date();
  await processDayReminders(now);
  await processHourReminders(now);
  await processUnconfirmedFollowups(now);
  await processAutoCancelUnconfirmed(now);
  await processDailySummaries(now);
}
