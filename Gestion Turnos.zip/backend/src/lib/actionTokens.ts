import crypto from "node:crypto";
import { prisma } from "./prisma.js";
import { ActionType, TokenStatus, type RecipientType } from "./constants.js";

const PUBLIC_APP_URL = process.env.PUBLIC_APP_URL ?? "http://localhost:5173";

/** Link a la página pública de reservas del negocio, para ofrecer "reservar de nuevo" tras una cancelación. */
export function publicBookingUrl(slug: string): string {
  return `${PUBLIC_APP_URL}/reservar/${slug}`;
}

function newToken(): string {
  return crypto.randomBytes(20).toString("hex");
}

export interface ActionLinks {
  confirmUrl: string;
  cancelUrl: string;
  modifyUrl: string;
}

/**
 * Invalida cualquier link vivo previo del turno para ese destinatario y crea un
 * juego nuevo de tokens de un solo uso (confirmar/cancelar/modificar).
 */
export async function createActionLinks(appointmentId: string, recipientType: RecipientType): Promise<ActionLinks> {
  await prisma.actionToken.updateMany({
    where: { appointmentId, recipientType, status: TokenStatus.PENDING },
    data: { status: TokenStatus.EXPIRED },
  });

  const actions = [ActionType.CONFIRM, ActionType.CANCEL, ActionType.MODIFY] as const;
  const tokens = await Promise.all(
    actions.map((action) =>
      prisma.actionToken.create({ data: { token: newToken(), appointmentId, recipientType, action } })
    )
  );

  const byAction = Object.fromEntries(tokens.map((t) => [t.action, t.token]));
  return {
    confirmUrl: `${PUBLIC_APP_URL}/accion/${byAction[ActionType.CONFIRM]}`,
    cancelUrl: `${PUBLIC_APP_URL}/accion/${byAction[ActionType.CANCEL]}`,
    modifyUrl: `${PUBLIC_APP_URL}/accion/${byAction[ActionType.MODIFY]}`,
  };
}

/** Invalida todos los links vivos (de cualquier destinatario) de un turno, por ejemplo tras un cambio de estado. */
export async function invalidateActionLinks(appointmentId: string): Promise<void> {
  await prisma.actionToken.updateMany({
    where: { appointmentId, status: TokenStatus.PENDING },
    data: { status: TokenStatus.EXPIRED },
  });
}
