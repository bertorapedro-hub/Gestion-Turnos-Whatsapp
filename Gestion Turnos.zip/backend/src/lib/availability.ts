import { prisma } from "./prisma.js";
import { AppointmentStatus } from "./constants.js";

const SLOT_STEP_MIN = 15;

function toMinutes(hhmm: string): number {
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
}

function dateAtMinutes(day: Date, minutes: number): Date {
  const d = new Date(day);
  d.setHours(0, 0, 0, 0);
  d.setMinutes(minutes);
  return d;
}

interface AvailabilityParams {
  businessId: string;
  professionalId: string;
  serviceId: string;
  dateStr: string; // YYYY-MM-DD
  excludeAppointmentId?: string;
}

export interface AvailabilityResult {
  slots: string[]; // "HH:mm"
  durationMin: number;
  error?: string;
}

export async function computeAvailableSlots(params: AvailabilityParams): Promise<AvailabilityResult> {
  const { businessId, professionalId, serviceId, dateStr, excludeAppointmentId } = params;

  const [service, professional] = await Promise.all([
    prisma.service.findFirst({ where: { id: serviceId, businessId, isActive: true } }),
    prisma.professional.findFirst({ where: { id: professionalId, businessId, isActive: true } }),
  ]);
  if (!service) return { slots: [], durationMin: 0, error: "Servicio no encontrado o inactivo" };
  if (!professional) return { slots: [], durationMin: 0, error: "Profesional no encontrado o inactivo" };

  const link = await prisma.serviceProfessional.findUnique({
    where: { serviceId_professionalId: { serviceId, professionalId } },
  });
  if (!link) return { slots: [], durationMin: service.durationMin, error: "Ese profesional no realiza este servicio" };

  const day = new Date(`${dateStr}T00:00:00`);
  if (Number.isNaN(day.getTime())) return { slots: [], durationMin: service.durationMin, error: "Fecha inválida" };
  const weekday = day.getDay();
  const dayStart = dateAtMinutes(day, 0);
  const dayEnd = dateAtMinutes(day, 24 * 60);

  const [ranges, blocks, appointments] = await Promise.all([
    getWeeklyRanges(businessId, professionalId, weekday),
    prisma.scheduleBlock.findMany({
      where: {
        businessId,
        OR: [{ professionalId: null }, { professionalId }],
        startAt: { lt: dayEnd },
        endAt: { gt: dayStart },
      },
    }),
    prisma.appointment.findMany({
      where: {
        professionalId,
        status: { not: AppointmentStatus.CANCELLED },
        startAt: { lt: dayEnd },
        endAt: { gt: dayStart },
        ...(excludeAppointmentId ? { id: { not: excludeAppointmentId } } : {}),
      },
    }),
  ]);

  const duration = service.durationMin;
  const now = new Date();
  const slots: string[] = [];

  for (const range of ranges) {
    const rangeStart = toMinutes(range.startTime);
    const rangeEnd = toMinutes(range.endTime);

    for (let start = rangeStart; start + duration <= rangeEnd; start += SLOT_STEP_MIN) {
      const slotStart = dateAtMinutes(day, start);
      const slotEnd = dateAtMinutes(day, start + duration);

      if (slotStart < now) continue;

      const blocked = blocks.some((b) => slotStart < b.endAt && slotEnd > b.startAt);
      if (blocked) continue;

      const taken = appointments.some((a) => slotStart < a.endAt && slotEnd > a.startAt);
      if (taken) continue;

      slots.push(range.startTime.length ? minutesToHHMM(start) : "");
    }
  }

  return { slots, durationMin: duration };
}

/**
 * Si el profesional tiene algún horario propio cargado (en cualquier día), se usa
 * exclusivamente su horario para todos los días (incluyendo "cerrado" los días que
 * no cargó). Si no tiene ninguno, se usa el horario general del negocio.
 */
async function getWeeklyRanges(businessId: string, professionalId: string, weekday: number) {
  const hasCustomSchedule = (await prisma.weeklySchedule.count({ where: { businessId, professionalId } })) > 0;
  return prisma.weeklySchedule.findMany({
    where: { businessId, weekday, professionalId: hasCustomSchedule ? professionalId : null },
  });
}

interface SlotCheckParams {
  businessId: string;
  professionalId: string;
  startAt: Date;
  endAt: Date;
  excludeAppointmentId?: string;
}

/** Chequeo directo de superposición (bloqueos + turnos existentes), sin exigir grilla de 15 min ni horario semanal. */
export async function isSlotFree(params: SlotCheckParams): Promise<{ ok: boolean; reason?: string }> {
  const { businessId, professionalId, startAt, endAt, excludeAppointmentId } = params;
  if (startAt >= endAt) return { ok: false, reason: "El horario de inicio debe ser anterior al de fin" };

  const [blocks, appointments] = await Promise.all([
    prisma.scheduleBlock.findMany({
      where: {
        businessId,
        OR: [{ professionalId: null }, { professionalId }],
        startAt: { lt: endAt },
        endAt: { gt: startAt },
      },
    }),
    prisma.appointment.findMany({
      where: {
        professionalId,
        status: { not: AppointmentStatus.CANCELLED },
        startAt: { lt: endAt },
        endAt: { gt: startAt },
        ...(excludeAppointmentId ? { id: { not: excludeAppointmentId } } : {}),
      },
    }),
  ]);

  if (blocks.length > 0) return { ok: false, reason: "El horario elegido está bloqueado en la agenda" };
  if (appointments.length > 0) return { ok: false, reason: "El profesional ya tiene un turno en ese horario" };
  return { ok: true };
}

function minutesToHHMM(total: number): string {
  const h = Math.floor(total / 60)
    .toString()
    .padStart(2, "0");
  const m = (total % 60).toString().padStart(2, "0");
  return `${h}:${m}`;
}
