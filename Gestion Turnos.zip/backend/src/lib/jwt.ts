import jwt from "jsonwebtoken";
import type { Role } from "./constants.js";

const JWT_SECRET = process.env.JWT_SECRET ?? "dev-secret-change-me";
const TOKEN_TTL = "12h";

export interface AuthTokenPayload {
  userId: string;
  role: Role;
  businessId: string | null;
}

export function signAuthToken(payload: AuthTokenPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: TOKEN_TTL });
}

export function verifyAuthToken(token: string): AuthTokenPayload {
  return jwt.verify(token, JWT_SECRET) as AuthTokenPayload;
}

export const AUTH_COOKIE_NAME = "turnos_session";
export const AUTH_COOKIE_MAX_AGE_MS = 12 * 60 * 60 * 1000;
