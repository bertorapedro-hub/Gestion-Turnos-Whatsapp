import { prisma } from "./prisma.js";
import { sendText } from "./whatsapp.js";
import { MessageStatus, DEFAULT_TEMPLATES } from "./constants.js";

export function renderTemplate(body: string, vars: Record<string, string>): string {
  return body.replace(/\{\{(\w+)\}\}/g, (_match, key: string) => vars[key] ?? "");
}

/**
 * Texto de la plantilla para un negocio/evento: la personalizada si el negocio
 * ya la editó, o el texto por defecto si todavía no tiene una propia guardada
 * (por ejemplo, negocios creados antes de agregarse un nuevo tipo de mensaje).
 */
export async function getTemplateBody(businessId: string, eventType: string): Promise<string | null> {
  const template = await prisma.messageTemplate.findUnique({
    where: { businessId_eventType: { businessId, eventType } },
  });
  return template?.body ?? DEFAULT_TEMPLATES[eventType] ?? null;
}

interface SendParams {
  businessId: string;
  phone: string;
  body: string;
  eventType: string;
  recipientType: string;
  recipientName?: string;
  appointmentId?: string;
}

/** Envía (o intenta enviar) un mensaje de WhatsApp y siempre deja registro en MessageLog. */
export async function sendAndLog(params: SendParams) {
  try {
    await sendText(params.businessId, params.phone, params.body);
    return prisma.messageLog.create({
      data: {
        businessId: params.businessId,
        appointmentId: params.appointmentId ?? null,
        recipientType: params.recipientType,
        recipientName: params.recipientName ?? null,
        recipientPhone: params.phone,
        eventType: params.eventType,
        body: params.body,
        status: MessageStatus.SENT,
      },
    });
  } catch (err) {
    const skipped = err instanceof Error && err.message.includes("no está vinculado");
    return prisma.messageLog.create({
      data: {
        businessId: params.businessId,
        appointmentId: params.appointmentId ?? null,
        recipientType: params.recipientType,
        recipientName: params.recipientName ?? null,
        recipientPhone: params.phone,
        eventType: params.eventType,
        body: params.body,
        status: skipped ? MessageStatus.SKIPPED_NOT_LINKED : MessageStatus.FAILED,
        errorMessage: err instanceof Error ? err.message : "Error desconocido",
      },
    });
  }
}
