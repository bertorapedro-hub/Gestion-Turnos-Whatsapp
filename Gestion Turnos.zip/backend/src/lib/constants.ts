export const Role = {
  SUPERADMIN: "SUPERADMIN",
  BUSINESS_OWNER: "BUSINESS_OWNER",
} as const;
export type Role = (typeof Role)[keyof typeof Role];

export const AppointmentStatus = {
  PENDING: "PENDING",
  CONFIRMED: "CONFIRMED",
  CANCELLED: "CANCELLED",
  DONE: "DONE",
} as const;
export type AppointmentStatus = (typeof AppointmentStatus)[keyof typeof AppointmentStatus];

export const CancelledBy = {
  CLIENT: "CLIENT",
  PROFESSIONAL: "PROFESSIONAL",
  BUSINESS: "BUSINESS",
} as const;
export type CancelledBy = (typeof CancelledBy)[keyof typeof CancelledBy];

export const MessageEventType = {
  BOOKING_CONFIRMATION: "BOOKING_CONFIRMATION",
  REMINDER_DAY: "REMINDER_DAY",
  REMINDER_HOUR: "REMINDER_HOUR",
  DAILY_SUMMARY: "DAILY_SUMMARY",
  CANCELLED_BY_CLIENT: "CANCELLED_BY_CLIENT",
  CANCELLED_BY_PROFESSIONAL: "CANCELLED_BY_PROFESSIONAL",
  CANCELLED_BY_BUSINESS: "CANCELLED_BY_BUSINESS",
  MODIFIED: "MODIFIED",
  BROADCAST: "BROADCAST",
  AUTO_CANCELLED_UNCONFIRMED: "AUTO_CANCELLED_UNCONFIRMED",
  PROFESSIONAL_APPROVAL_REQUEST: "PROFESSIONAL_APPROVAL_REQUEST",
  CLIENT_AWAITING_APPROVAL: "CLIENT_AWAITING_APPROVAL",
  CONFIRMED_BY_PROFESSIONAL: "CONFIRMED_BY_PROFESSIONAL",
} as const;
export type MessageEventType = (typeof MessageEventType)[keyof typeof MessageEventType];

export const ProfessionalMode = {
  SINGLE: "SINGLE",
  MULTI: "MULTI",
} as const;
export type ProfessionalMode = (typeof ProfessionalMode)[keyof typeof ProfessionalMode];

export const BookingConfirmationMode = {
  CLIENT_SELF: "CLIENT_SELF", // el cliente confirma solo, vía recordatorios con links
  PROFESSIONAL_APPROVAL: "PROFESSIONAL_APPROVAL", // el profesional aprueba cada turno nuevo antes de confirmarlo
} as const;
export type BookingConfirmationMode = (typeof BookingConfirmationMode)[keyof typeof BookingConfirmationMode];

export const MessageStatus = {
  SENT: "SENT",
  FAILED: "FAILED",
  SKIPPED_NOT_LINKED: "SKIPPED_NOT_LINKED",
} as const;
export type MessageStatus = (typeof MessageStatus)[keyof typeof MessageStatus];

export const RecipientType = {
  CLIENT: "CLIENT",
  PROFESSIONAL: "PROFESSIONAL",
  BROADCAST: "BROADCAST",
} as const;
export type RecipientType = (typeof RecipientType)[keyof typeof RecipientType];

export const ActionType = {
  CONFIRM: "CONFIRM",
  CANCEL: "CANCEL",
  MODIFY: "MODIFY",
} as const;
export type ActionType = (typeof ActionType)[keyof typeof ActionType];

export const TokenStatus = {
  PENDING: "PENDING",
  USED: "USED",
  EXPIRED: "EXPIRED",
} as const;
export type TokenStatus = (typeof TokenStatus)[keyof typeof TokenStatus];

export const WhatsAppStatus = {
  DISCONNECTED: "DISCONNECTED",
  CONNECTING: "CONNECTING",
  CONNECTED: "CONNECTED",
} as const;
export type WhatsAppStatus = (typeof WhatsAppStatus)[keyof typeof WhatsAppStatus];

export const DEFAULT_TEMPLATES: Record<string, string> = {
  [MessageEventType.BOOKING_CONFIRMATION]:
    "Hola {{cliente}}! Tu turno en {{negocio}} quedó confirmado para el {{fecha}} a las {{hora}} con {{profesional}} ({{servicio}}).\n\nSi necesitás cancelarlo o cambiarlo:\nCancelar: {{link_cancelar}}\nModificar: {{link_modificar}}",
  [MessageEventType.REMINDER_DAY]:
    "Hola {{cliente}}! Te recordamos tu turno mañana {{fecha}} a las {{hora}} en {{negocio}} con {{profesional}} ({{servicio}}).\n\nCancelar: {{link_cancelar}}\nModificar: {{link_modificar}}",
  [MessageEventType.REMINDER_HOUR]:
    "Hola {{cliente}}! Tu turno es hoy a las {{hora}} en {{negocio}} con {{profesional}} ({{servicio}}).\n\nCancelar: {{link_cancelar}}\nModificar: {{link_modificar}}",
  [MessageEventType.DAILY_SUMMARY]:
    "Hola {{profesional}}! Estos son tus turnos de hoy {{fecha}} en {{negocio}}:\n{{lista_turnos}}",
  [MessageEventType.CANCELLED_BY_CLIENT]:
    "El cliente {{cliente}} canceló el turno del {{fecha}} a las {{hora}} ({{servicio}}).",
  [MessageEventType.CANCELLED_BY_PROFESSIONAL]:
    "{{profesional}} canceló tu turno del {{fecha}} a las {{hora}} en {{negocio}}.\n\nReservar de nuevo: {{link_reservar}}",
  [MessageEventType.CANCELLED_BY_BUSINESS]:
    "Tu turno del {{fecha}} a las {{hora}} en {{negocio}} fue cancelado.\n\nReservar de nuevo: {{link_reservar}}",
  [MessageEventType.MODIFIED]:
    "Hola {{cliente}}! Tu turno en {{negocio}} fue reprogramado para el {{fecha}} a las {{hora}} con {{profesional}} ({{servicio}}).\n\nSi necesitás cancelarlo o cambiarlo:\nCancelar: {{link_cancelar}}\nModificar: {{link_modificar}}",
  [MessageEventType.BROADCAST]: "Hola {{cliente}}! {{mensaje}}",
  [MessageEventType.AUTO_CANCELLED_UNCONFIRMED]:
    "Hola {{cliente}}! Tu turno del {{fecha}} a las {{hora}} en {{negocio}} fue cancelado automáticamente por no haber sido confirmado a tiempo.\n\nReservar de nuevo: {{link_reservar}}",
  [MessageEventType.PROFESSIONAL_APPROVAL_REQUEST]:
    "Hola {{profesional}}! {{cliente}} quiere reservar un turno el {{fecha}} a las {{hora}} para {{servicio}}. ¿Podés atenderlo?\n\nAceptar: {{link_confirmar}}\nRechazar: {{link_cancelar}}",
  [MessageEventType.CLIENT_AWAITING_APPROVAL]:
    "Hola {{cliente}}! Recibimos tu pedido de turno para el {{fecha}} a las {{hora}} en {{negocio}} con {{profesional}} ({{servicio}}). Estamos confirmando con {{profesional}} y te avisamos apenas responda.\n\nSi necesitás cancelarlo o cambiarlo:\nCancelar: {{link_cancelar}}\nModificar: {{link_modificar}}",
  [MessageEventType.CONFIRMED_BY_PROFESSIONAL]:
    "Hola {{cliente}}! {{profesional}} confirmó tu turno del {{fecha}} a las {{hora}} en {{negocio}} ({{servicio}}). ¡Te esperamos!\n\nSi necesitás cancelarlo o cambiarlo:\nCancelar: {{link_cancelar}}\nModificar: {{link_modificar}}",
};
