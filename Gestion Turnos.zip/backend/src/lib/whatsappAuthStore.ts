import { BufferJSON, initAuthCreds, proto } from "@whiskeysockets/baileys";
import type { AuthenticationCreds, AuthenticationState, SignalDataTypeMap } from "@whiskeysockets/baileys";
import { prisma } from "./prisma.js";

async function readEntry(businessId: string, key: string): Promise<unknown> {
  const row = await prisma.whatsAppAuthEntry.findUnique({ where: { businessId_key: { businessId, key } } });
  if (!row) return null;
  return JSON.parse(row.value, BufferJSON.reviver);
}

async function writeEntry(businessId: string, key: string, value: unknown): Promise<void> {
  const serialized = JSON.stringify(value, BufferJSON.replacer);
  await prisma.whatsAppAuthEntry.upsert({
    where: { businessId_key: { businessId, key } },
    update: { value: serialized },
    create: { businessId, key, value: serialized },
  });
}

async function removeEntry(businessId: string, key: string): Promise<void> {
  await prisma.whatsAppAuthEntry.deleteMany({ where: { businessId, key } });
}

/** Estado de autenticación de Baileys persistido en la base de datos (una fila por "archivo"). */
export async function useDbAuthState(businessId: string): Promise<{ state: AuthenticationState; saveCreds: () => Promise<void> }> {
  const storedCreds = (await readEntry(businessId, "creds")) as AuthenticationCreds | null;
  const creds: AuthenticationCreds = storedCreds ?? initAuthCreds();

  return {
    state: {
      creds,
      keys: {
        get: async (type, ids) => {
          const data: Record<string, unknown> = {};
          await Promise.all(
            ids.map(async (id) => {
              let value = await readEntry(businessId, `${type}-${id}`);
              if (type === "app-state-sync-key" && value) {
                value = proto.Message.AppStateSyncKeyData.fromObject(value as object);
              }
              data[id] = value;
            })
          );
          return data as { [id: string]: SignalDataTypeMap[typeof type] };
        },
        set: async (data) => {
          const tasks: Promise<void>[] = [];
          for (const category of Object.keys(data) as (keyof SignalDataTypeMap)[]) {
            const entries = data[category] as Record<string, unknown> | undefined;
            if (!entries) continue;
            for (const id of Object.keys(entries)) {
              const value = entries[id];
              const key = `${category}-${id}`;
              tasks.push(value ? writeEntry(businessId, key, value) : removeEntry(businessId, key));
            }
          }
          await Promise.all(tasks);
        },
      },
    },
    saveCreds: () => writeEntry(businessId, "creds", creds),
  };
}

export async function clearAuthState(businessId: string): Promise<void> {
  await prisma.whatsAppAuthEntry.deleteMany({ where: { businessId } });
}
