import cron from "node-cron";
import { processDueReminders } from "../lib/reminders.js";

let running = false;

export function startScheduler(): void {
  cron.schedule("* * * * *", async () => {
    if (running) return; // evita solapar corridas si una tarda más de un minuto
    running = true;
    try {
      await processDueReminders();
    } catch (err) {
      console.error("Error procesando recordatorios automáticos:", err);
    } finally {
      running = false;
    }
  });
  console.log("Scheduler de recordatorios iniciado (cada 1 minuto).");
}
