import { Router } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { AUTH_COOKIE_MAX_AGE_MS, AUTH_COOKIE_NAME, signAuthToken } from "../lib/jwt.js";
import { Role } from "../lib/constants.js";
import { requireAuth } from "../middleware/auth.js";

export const authRouter = Router();

const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

function setSessionCookie(res: import("express").Response, token: string) {
  res.cookie(AUTH_COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: AUTH_COOKIE_MAX_AGE_MS,
    path: "/",
  });
}

/** Login del panel de negocio. */
authRouter.post("/login", async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Usuario y contraseña requeridos" });
  const { username, password } = parsed.data;

  const user = await prisma.user.findUnique({ where: { username } });
  if (!user || user.role !== Role.BUSINESS_OWNER || !user.businessId) {
    return res.status(401).json({ error: "Usuario o contraseña incorrectos" });
  }
  const business = await prisma.business.findUnique({ where: { id: user.businessId } });
  if (!business || !business.isActive) {
    return res.status(403).json({ error: "El negocio está pausado. Contactá al administrador." });
  }
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error: "Usuario o contraseña incorrectos" });

  const token = signAuthToken({ userId: user.id, role: user.role as typeof Role.BUSINESS_OWNER, businessId: user.businessId });
  setSessionCookie(res, token);
  res.json({ id: user.id, username: user.username, businessId: user.businessId, businessName: business.name });
});

/** Login del panel de superadministrador. */
authRouter.post("/superadmin/login", async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Usuario y contraseña requeridos" });
  const { username, password } = parsed.data;

  const user = await prisma.user.findUnique({ where: { username } });
  if (!user || user.role !== Role.SUPERADMIN) {
    return res.status(401).json({ error: "Usuario o contraseña incorrectos" });
  }
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error: "Usuario o contraseña incorrectos" });

  const token = signAuthToken({ userId: user.id, role: user.role as typeof Role.SUPERADMIN, businessId: null });
  setSessionCookie(res, token);
  res.json({ id: user.id, username: user.username });
});

authRouter.post("/logout", (_req, res) => {
  res.clearCookie(AUTH_COOKIE_NAME, { path: "/" });
  res.json({ ok: true });
});

authRouter.get("/me", requireAuth, async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.auth!.userId } });
  if (!user) return res.status(401).json({ error: "No autenticado" });
  const business = user.businessId
    ? await prisma.business.findUnique({ where: { id: user.businessId } })
    : null;
  res.json({
    id: user.id,
    username: user.username,
    role: user.role,
    businessId: user.businessId,
    businessName: business?.name ?? null,
    professionalMode: business?.professionalMode ?? null,
    onboardingCompleted: business ? !!business.onboardingCompletedAt : null,
  });
});

const changePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(6, "La nueva contraseña debe tener al menos 6 caracteres"),
});

authRouter.post("/change-password", requireAuth, async (req, res) => {
  const parsed = changePasswordSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });

  const user = await prisma.user.findUnique({ where: { id: req.auth!.userId } });
  if (!user) return res.status(401).json({ error: "No autenticado" });

  const ok = await bcrypt.compare(parsed.data.currentPassword, user.passwordHash);
  if (!ok) return res.status(400).json({ error: "La contraseña actual no es correcta" });

  const passwordHash = await bcrypt.hash(parsed.data.newPassword, 10);
  await prisma.user.update({ where: { id: user.id }, data: { passwordHash } });
  res.json({ ok: true });
});
