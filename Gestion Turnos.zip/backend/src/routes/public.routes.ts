import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { computeAvailableSlots, isSlotFree } from "../lib/availability.js";
import { AppointmentStatus, BookingConfirmationMode, CancelledBy, MessageEventType, RecipientType } from "../lib/constants.js";
import { createActionLinks, invalidateActionLinks } from "../lib/actionTokens.js";
import { notifyOtherParty } from "../lib/appointmentMessaging.js";
import { renderTemplate, sendAndLog, getTemplateBody } from "../lib/messaging.js";

export const publicRouter = Router();

async function loadActiveBusiness(slug: string) {
  const business = await prisma.business.findUnique({ where: { slug } });
  if (!business || !business.isActive) return null;
  return business;
}

publicRouter.get("/:slug", async (req, res) => {
  const business = await loadActiveBusiness(req.params.slug);
  if (!business) return res.status(404).json({ error: "Este negocio no está disponible" });

  const [professionals, services] = await Promise.all([
    prisma.professional.findMany({
      where: { businessId: business.id, isActive: true },
      select: { id: true, name: true, specialty: true, description: true, photoUrl: true },
      orderBy: { name: "asc" },
    }),
    prisma.service.findMany({
      where: { businessId: business.id, isActive: true },
      select: {
        id: true,
        name: true,
        durationMin: true,
        price: true,
        professionals: { select: { professionalId: true } },
      },
      orderBy: { name: "asc" },
    }),
  ]);

  res.json({
    id: business.id,
    name: business.name,
    slug: business.slug,
    contactPhone: business.contactPhone,
    professionalMode: business.professionalMode,
    professionals,
    services: services.map((s) => ({
      id: s.id,
      name: s.name,
      durationMin: s.durationMin,
      price: s.price,
      professionalIds: s.professionals.map((p) => p.professionalId),
    })),
  });
});

publicRouter.get("/:slug/clients/lookup", async (req, res) => {
  const business = await loadActiveBusiness(req.params.slug);
  if (!business) return res.status(404).json({ error: "Este negocio no está disponible" });

  const documentId = String(req.query.documentId ?? "").trim();
  if (!documentId) return res.status(400).json({ error: "Falta el documento" });

  const client = await prisma.client.findUnique({
    where: { businessId_documentId: { businessId: business.id, documentId } },
  });
  if (!client) return res.json({ found: false });
  res.json({ found: true, fullName: client.fullName, phone: client.phone });
});

publicRouter.get("/:slug/availability", async (req, res) => {
  const business = await loadActiveBusiness(req.params.slug);
  if (!business) return res.status(404).json({ error: "Este negocio no está disponible" });

  const { professionalId, serviceId, date } = req.query;
  if (!professionalId || !serviceId || !date) {
    return res.status(400).json({ error: "Faltan parámetros" });
  }
  const result = await computeAvailableSlots({
    businessId: business.id,
    professionalId: String(professionalId),
    serviceId: String(serviceId),
    dateStr: String(date),
  });
  if (result.error) return res.status(400).json({ error: result.error });
  res.json(result);
});

const bookingSchema = z.object({
  professionalId: z.string().min(1),
  serviceId: z.string().min(1),
  startAt: z.string().min(1),
  client: z.object({
    fullName: z.string().min(1, "El nombre es obligatorio"),
    documentId: z.string().min(1, "El documento es obligatorio"),
    phone: z.string().min(1, "El teléfono es obligatorio"),
  }),
});

publicRouter.post("/:slug/appointments", async (req, res) => {
  const business = await loadActiveBusiness(req.params.slug);
  if (!business) return res.status(404).json({ error: "Este negocio no está disponible" });

  const parsed = bookingSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });

  const service = await prisma.service.findFirst({
    where: { id: parsed.data.serviceId, businessId: business.id, isActive: true },
  });
  if (!service) return res.status(404).json({ error: "Servicio no encontrado" });
  const professional = await prisma.professional.findFirst({
    where: { id: parsed.data.professionalId, businessId: business.id, isActive: true },
  });
  if (!professional) return res.status(404).json({ error: "Profesional no encontrado" });

  const startAt = new Date(parsed.data.startAt);
  if (Number.isNaN(startAt.getTime()) || startAt < new Date()) {
    return res.status(400).json({ error: "Fecha/hora inválida" });
  }
  const endAt = new Date(startAt.getTime() + service.durationMin * 60000);

  const check = await isSlotFree({ businessId: business.id, professionalId: professional.id, startAt, endAt });
  if (!check.ok) return res.status(400).json({ error: check.reason });

  const existingClient = await prisma.client.findUnique({
    where: { businessId_documentId: { businessId: business.id, documentId: parsed.data.client.documentId } },
  });
  const client = existingClient
    ? await prisma.client.update({
        where: { id: existingClient.id },
        data: {
          fullName: parsed.data.client.fullName,
          phone: parsed.data.client.phone,
        },
      })
    : await prisma.client.create({
        data: {
          businessId: business.id,
          fullName: parsed.data.client.fullName,
          documentId: parsed.data.client.documentId,
          phone: parsed.data.client.phone,
        },
      });

  const askProfessional = business.bookingConfirmationMode === BookingConfirmationMode.PROFESSIONAL_APPROVAL && professional.phone;

  const appointment = await prisma.appointment.create({
    data: {
      businessId: business.id,
      clientId: client.id,
      professionalId: professional.id,
      serviceId: service.id,
      startAt,
      endAt,
      // El pedido del cliente ya es la confirmación: solo queda PENDING cuando hace falta
      // que el profesional lo apruebe primero.
      status: askProfessional ? AppointmentStatus.PENDING : AppointmentStatus.CONFIRMED,
    },
    include: { professional: true, service: true },
  });

  const vars = {
    cliente: client.fullName,
    profesional: professional.name,
    servicio: service.name,
    negocio: business.name,
    fecha: startAt.toLocaleDateString("es-AR"),
    hora: startAt.toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" }),
  };

  if (askProfessional) {
    const links = await createActionLinks(appointment.id, RecipientType.PROFESSIONAL);
    const requestBody = await getTemplateBody(business.id, MessageEventType.PROFESSIONAL_APPROVAL_REQUEST);
    if (requestBody) {
      await sendAndLog({
        businessId: business.id,
        phone: professional.phone!,
        body: renderTemplate(requestBody, { ...vars, link_confirmar: links.confirmUrl, link_cancelar: links.cancelUrl }),
        eventType: MessageEventType.PROFESSIONAL_APPROVAL_REQUEST,
        recipientType: RecipientType.PROFESSIONAL,
        recipientName: professional.name,
        appointmentId: appointment.id,
      });
    }
    const awaitingBody = await getTemplateBody(business.id, MessageEventType.CLIENT_AWAITING_APPROVAL);
    if (awaitingBody) {
      const clientLinks = await createActionLinks(appointment.id, RecipientType.CLIENT);
      await sendAndLog({
        businessId: business.id,
        phone: client.phone,
        body: renderTemplate(awaitingBody, {
          ...vars,
          link_cancelar: clientLinks.cancelUrl,
          link_modificar: clientLinks.modifyUrl,
        }),
        eventType: MessageEventType.CLIENT_AWAITING_APPROVAL,
        recipientType: RecipientType.CLIENT,
        recipientName: client.fullName,
        appointmentId: appointment.id,
      });
    }
  } else {
    // Pedir el turno ya es la confirmación: no hay un paso de "confirmar" aparte,
    // el cliente solo puede cancelarlo o modificarlo si lo necesita.
    const links = await createActionLinks(appointment.id, RecipientType.CLIENT);
    const templateBody = await getTemplateBody(business.id, MessageEventType.BOOKING_CONFIRMATION);
    if (templateBody) {
      await sendAndLog({
        businessId: business.id,
        phone: client.phone,
        body: renderTemplate(templateBody, { ...vars, link_cancelar: links.cancelUrl, link_modificar: links.modifyUrl }),
        eventType: MessageEventType.BOOKING_CONFIRMATION,
        recipientType: RecipientType.CLIENT,
        recipientName: client.fullName,
        appointmentId: appointment.id,
      });
    }
  }

  res.status(201).json(appointment);
});

publicRouter.get("/:slug/mis-turnos", async (req, res) => {
  const business = await loadActiveBusiness(req.params.slug);
  if (!business) return res.status(404).json({ error: "Este negocio no está disponible" });

  const documentId = String(req.query.documentId ?? "").trim();
  if (!documentId) return res.status(400).json({ error: "Ingresá tu número de documento" });

  const client = await prisma.client.findUnique({
    where: { businessId_documentId: { businessId: business.id, documentId } },
  });
  if (!client) return res.json([]);

  const appointments = await prisma.appointment.findMany({
    where: { clientId: client.id },
    include: { professional: true, service: true },
    orderBy: { startAt: "desc" },
  });
  res.json(appointments);
});

publicRouter.post("/:slug/mis-turnos/:appointmentId/cancel", async (req, res) => {
  const business = await loadActiveBusiness(req.params.slug);
  if (!business) return res.status(404).json({ error: "Este negocio no está disponible" });

  const documentId = String(req.body.documentId ?? "").trim();
  if (!documentId) return res.status(400).json({ error: "Falta el documento" });

  const appointment = await prisma.appointment.findFirst({
    where: { id: req.params.appointmentId, businessId: business.id },
    include: { client: true, professional: true, service: true },
  });
  if (!appointment || appointment.client.documentId !== documentId) {
    return res.status(404).json({ error: "Turno no encontrado" });
  }
  if (appointment.status === AppointmentStatus.CANCELLED) {
    return res.status(400).json({ error: "Este turno ya estaba cancelado" });
  }

  const updated = await prisma.appointment.update({
    where: { id: appointment.id },
    data: { status: AppointmentStatus.CANCELLED, cancelledBy: CancelledBy.CLIENT },
    include: { professional: true, service: true },
  });
  await invalidateActionLinks(appointment.id);

  const templateBody = await getTemplateBody(business.id, MessageEventType.CANCELLED_BY_CLIENT);
  if (templateBody) {
    await notifyOtherParty(
      { ...appointment, status: updated.status, cancelledBy: updated.cancelledBy },
      business,
      templateBody,
      MessageEventType.CANCELLED_BY_CLIENT,
      "CLIENT"
    );
  }

  res.json(updated);
});
