import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import {
  ActionType,
  AppointmentStatus,
  BookingConfirmationMode,
  CancelledBy,
  MessageEventType,
  RecipientType,
  TokenStatus,
} from "../lib/constants.js";
import { createActionLinks, invalidateActionLinks, publicBookingUrl } from "../lib/actionTokens.js";
import { notifyOtherParty } from "../lib/appointmentMessaging.js";
import { computeAvailableSlots, isSlotFree } from "../lib/availability.js";
import { getTemplateBody } from "../lib/messaging.js";

export const actionsRouter = Router();

const appointmentInclude = { client: true, professional: true, service: true, business: true } as const;

async function loadToken(token: string) {
  const actionToken = await prisma.actionToken.findUnique({
    where: { token },
    include: { appointment: { include: appointmentInclude } },
  });
  return actionToken;
}

actionsRouter.get("/:token", async (req, res) => {
  const actionToken = await loadToken(req.params.token);
  if (!actionToken) return res.status(404).json({ error: "Link inválido" });

  const { appointment } = actionToken;
  res.json({
    action: actionToken.action,
    status: actionToken.status,
    appointment: {
      startAt: appointment.startAt,
      status: appointment.status,
      professional: appointment.professional.name,
      service: appointment.service.name,
      business: appointment.business.name,
      clientName: appointment.client.fullName,
    },
  });
});

function ensureUsable(actionToken: NonNullable<Awaited<ReturnType<typeof loadToken>>>, expectedAction: string) {
  if (actionToken.action !== expectedAction) return "Este link no corresponde a esta acción";
  if (actionToken.status !== TokenStatus.PENDING) return "Este link ya fue usado o ya no es válido";
  if (actionToken.appointment.status === AppointmentStatus.CANCELLED) return "Este turno ya está cancelado";
  return null;
}

actionsRouter.post("/:token/confirm", async (req, res) => {
  const actionToken = await loadToken(req.params.token);
  if (!actionToken) return res.status(404).json({ error: "Link inválido" });
  const problem = ensureUsable(actionToken, ActionType.CONFIRM);
  if (problem) return res.status(400).json({ error: problem });

  const { appointment } = actionToken;

  await prisma.appointment.update({
    where: { id: appointment.id },
    data: { status: AppointmentStatus.CONFIRMED },
  });
  await prisma.actionToken.update({ where: { id: actionToken.id }, data: { status: TokenStatus.USED, usedAt: new Date() } });
  await invalidateActionLinks(appointment.id);

  // El cliente ya no tiene un paso de "confirmar" (pedir el turno ya lo confirma), así que en la
  // práctica este link solo lo usa el profesional al aprobar un pedido.
  if (actionToken.recipientType === "PROFESSIONAL") {
    const eventType = MessageEventType.CONFIRMED_BY_PROFESSIONAL;
    const templateBody = await getTemplateBody(appointment.businessId, eventType);
    if (templateBody) {
      // El cliente recibe ahí mismo sus links para cancelar o modificar — no tiene que
      // esperar al recordatorio del día antes.
      const links = await createActionLinks(appointment.id, RecipientType.CLIENT);
      await notifyOtherParty(appointment, appointment.business, templateBody, eventType, "PROFESSIONAL", {
        link_cancelar: links.cancelUrl,
        link_modificar: links.modifyUrl,
      });
    }
  }

  res.json({ ok: true, message: "Turno confirmado" });
});

actionsRouter.post("/:token/cancel", async (req, res) => {
  const actionToken = await loadToken(req.params.token);
  if (!actionToken) return res.status(404).json({ error: "Link inválido" });
  const problem = ensureUsable(actionToken, ActionType.CANCEL);
  if (problem) return res.status(400).json({ error: problem });

  const { appointment } = actionToken;
  const cancelledBy = actionToken.recipientType === "PROFESSIONAL" ? CancelledBy.PROFESSIONAL : CancelledBy.CLIENT;

  await prisma.appointment.update({
    where: { id: appointment.id },
    data: { status: AppointmentStatus.CANCELLED, cancelledBy },
  });
  await prisma.actionToken.update({ where: { id: actionToken.id }, data: { status: TokenStatus.USED, usedAt: new Date() } });
  await invalidateActionLinks(appointment.id);

  const eventType =
    cancelledBy === CancelledBy.CLIENT ? MessageEventType.CANCELLED_BY_CLIENT : MessageEventType.CANCELLED_BY_PROFESSIONAL;
  const templateBody = await getTemplateBody(appointment.businessId, eventType);
  if (templateBody) {
    // Cancelado: no tiene sentido ofrecer cancelar/modificar ESE turno (ya está muerto),
    // así que al cliente le damos el link para reservar uno nuevo en su lugar.
    const extraVars: Record<string, string> =
      cancelledBy === CancelledBy.PROFESSIONAL ? { link_reservar: publicBookingUrl(appointment.business.slug) } : {};
    await notifyOtherParty(
      appointment,
      appointment.business,
      templateBody,
      eventType,
      cancelledBy === CancelledBy.CLIENT ? "CLIENT" : "PROFESSIONAL",
      extraVars
    );
  }

  res.json({ ok: true, message: "Turno cancelado" });
});

actionsRouter.get("/:token/availability", async (req, res) => {
  const actionToken = await loadToken(req.params.token);
  if (!actionToken) return res.status(404).json({ error: "Link inválido" });
  const problem = ensureUsable(actionToken, ActionType.MODIFY);
  if (problem) return res.status(400).json({ error: problem });

  const date = String(req.query.date ?? "");
  if (!date) return res.status(400).json({ error: "Falta la fecha" });

  const { appointment } = actionToken;
  const result = await computeAvailableSlots({
    businessId: appointment.businessId,
    professionalId: appointment.professionalId,
    serviceId: appointment.serviceId,
    dateStr: date,
    excludeAppointmentId: appointment.id,
  });
  if (result.error) return res.status(400).json({ error: result.error });
  res.json(result);
});

const modifySchema = z.object({ startAt: z.string().min(1) });

actionsRouter.post("/:token/modify", async (req, res) => {
  const parsed = modifySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Falta el nuevo horario" });

  const actionToken = await loadToken(req.params.token);
  if (!actionToken) return res.status(404).json({ error: "Link inválido" });
  const problem = ensureUsable(actionToken, ActionType.MODIFY);
  if (problem) return res.status(400).json({ error: problem });

  const { appointment } = actionToken;
  const startAt = new Date(parsed.data.startAt);
  if (Number.isNaN(startAt.getTime()) || startAt < new Date()) {
    return res.status(400).json({ error: "Fecha/hora inválida" });
  }
  const durationMs = appointment.endAt.getTime() - appointment.startAt.getTime();
  const endAt = new Date(startAt.getTime() + durationMs);

  const check = await isSlotFree({
    businessId: appointment.businessId,
    professionalId: appointment.professionalId,
    startAt,
    endAt,
    excludeAppointmentId: appointment.id,
  });
  if (!check.ok) return res.status(400).json({ error: check.reason });

  // Si fue el cliente quien cambió el horario en modo "el profesional aprueba", el profesional
  // ya había aprobado OTRO horario — hace falta que apruebe este también. Si fue el propio
  // profesional quien lo cambió, no hay nada que volver a aprobar. En "pedir el turno ya lo
  // confirma" tampoco hace falta: ahí no existe un paso de "confirmar" al que volver.
  const clientModified = actionToken.recipientType === "CLIENT";
  const needsReapproval =
    clientModified && appointment.business.bookingConfirmationMode === BookingConfirmationMode.PROFESSIONAL_APPROVAL;
  const newStatus = needsReapproval ? AppointmentStatus.PENDING : AppointmentStatus.CONFIRMED;

  await prisma.appointment.update({
    where: { id: appointment.id },
    data: {
      startAt,
      endAt,
      status: newStatus,
      cancelledBy: null,
      reminderDaySentAt: null,
      reminderHourSentAt: null,
      unconfirmedFollowupSentAt: null,
    },
  });
  await prisma.actionToken.update({ where: { id: actionToken.id }, data: { status: TokenStatus.USED, usedAt: new Date() } });
  await invalidateActionLinks(appointment.id);

  const updatedAppointment = { ...appointment, startAt, endAt };

  if (needsReapproval) {
    // Le mandamos al profesional un pedido de aprobación nuevo ahí mismo, en vez de esperar
    // al aviso periódico — cambió el horario, necesita aprobar este de nuevo.
    const requestBody = await getTemplateBody(appointment.businessId, MessageEventType.PROFESSIONAL_APPROVAL_REQUEST);
    if (requestBody && appointment.professional.phone) {
      const links = await createActionLinks(appointment.id, RecipientType.PROFESSIONAL);
      await notifyOtherParty(updatedAppointment, appointment.business, requestBody, MessageEventType.PROFESSIONAL_APPROVAL_REQUEST, "CLIENT", {
        link_confirmar: links.confirmUrl,
        link_cancelar: links.cancelUrl,
      });
    }
  } else {
    const templateBody = await getTemplateBody(appointment.businessId, MessageEventType.MODIFIED);
    if (templateBody) {
      // Si quien modificó fue el profesional, el cliente recibe el aviso con sus propios
      // links frescos de cancelar/modificar (los suyos anteriores quedaron invalidados arriba).
      const extraVars = actionToken.recipientType === "PROFESSIONAL"
        ? await (async () => {
            const links = await createActionLinks(appointment.id, RecipientType.CLIENT);
            return { link_cancelar: links.cancelUrl, link_modificar: links.modifyUrl };
          })()
        : {};
      await notifyOtherParty(
        updatedAppointment,
        appointment.business,
        templateBody,
        MessageEventType.MODIFIED,
        actionToken.recipientType === "PROFESSIONAL" ? "PROFESSIONAL" : "CLIENT",
        extraVars
      );
    }
  }

  res.json({ ok: true, message: "Turno reprogramado" });
});
