import { Router } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { requireAuth, requireSuperadmin } from "../middleware/auth.js";
import { Role, DEFAULT_TEMPLATES } from "../lib/constants.js";
import { slugify } from "../lib/slug.js";

export const superadminRouter = Router();
superadminRouter.use(requireAuth, requireSuperadmin);

superadminRouter.get("/businesses", async (_req, res) => {
  const businesses = await prisma.business.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      _count: { select: { appointments: true, professionals: true, clients: true } },
      users: { where: { role: Role.BUSINESS_OWNER }, select: { username: true } },
    },
  });
  res.json(businesses);
});

superadminRouter.get("/businesses/:id", async (req, res) => {
  const business = await prisma.business.findUnique({
    where: { id: req.params.id },
    include: { users: { where: { role: Role.BUSINESS_OWNER }, select: { id: true, username: true } } },
  });
  if (!business) return res.status(404).json({ error: "Negocio no encontrado" });
  res.json(business);
});

async function uniqueSlug(base: string): Promise<string> {
  const root = slugify(base) || "negocio";
  let candidate = root;
  let i = 1;
  // eslint-disable-next-line no-await-in-loop
  while (await prisma.business.findUnique({ where: { slug: candidate } })) {
    i += 1;
    candidate = `${root}-${i}`;
  }
  return candidate;
}

const createBusinessSchema = z.object({
  name: z.string().min(1, "El nombre es obligatorio"),
  contactPhone: z.string().optional().or(z.literal("")),
  ownerUsername: z.string().min(3, "El usuario debe tener al menos 3 caracteres"),
  ownerPassword: z.string().min(6, "La contraseña debe tener al menos 6 caracteres"),
});

superadminRouter.post("/businesses", async (req, res) => {
  const parsed = createBusinessSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const { name, contactPhone, ownerUsername, ownerPassword } = parsed.data;

  const existingUser = await prisma.user.findUnique({ where: { username: ownerUsername } });
  if (existingUser) return res.status(400).json({ error: "Ese nombre de usuario ya está en uso" });

  const slug = await uniqueSlug(name);
  const passwordHash = await bcrypt.hash(ownerPassword, 10);

  const business = await prisma.business.create({
    data: {
      name,
      slug,
      contactPhone: contactPhone || null,
      users: {
        create: { username: ownerUsername, passwordHash, role: Role.BUSINESS_OWNER },
      },
      messageTemplates: {
        create: Object.entries(DEFAULT_TEMPLATES).map(([eventType, body]) => ({ eventType, body })),
      },
    },
    include: { users: true },
  });

  res.status(201).json(business);
});

const updateBusinessSchema = z.object({
  name: z.string().min(1).optional(),
  contactPhone: z.string().optional().or(z.literal("")),
});

superadminRouter.put("/businesses/:id", async (req, res) => {
  const parsed = updateBusinessSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });

  const business = await prisma.business.findUnique({ where: { id: req.params.id } });
  if (!business) return res.status(404).json({ error: "Negocio no encontrado" });

  const updated = await prisma.business.update({
    where: { id: req.params.id },
    data: {
      name: parsed.data.name,
      contactPhone: parsed.data.contactPhone === "" ? null : parsed.data.contactPhone,
    },
  });
  res.json(updated);
});

superadminRouter.post("/businesses/:id/pause", async (req, res) => {
  const business = await prisma.business.findUnique({ where: { id: req.params.id } });
  if (!business) return res.status(404).json({ error: "Negocio no encontrado" });
  const updated = await prisma.business.update({ where: { id: req.params.id }, data: { isActive: false } });
  res.json(updated);
});

superadminRouter.post("/businesses/:id/reactivate", async (req, res) => {
  const business = await prisma.business.findUnique({ where: { id: req.params.id } });
  if (!business) return res.status(404).json({ error: "Negocio no encontrado" });
  const updated = await prisma.business.update({ where: { id: req.params.id }, data: { isActive: true } });
  res.json(updated);
});

superadminRouter.delete("/businesses/:id", async (req, res) => {
  const business = await prisma.business.findUnique({ where: { id: req.params.id } });
  if (!business) return res.status(404).json({ error: "Negocio no encontrado" });
  await prisma.business.delete({ where: { id: req.params.id } });
  res.json({ ok: true });
});
