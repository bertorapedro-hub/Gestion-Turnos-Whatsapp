import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../lib/prisma.js";
import { currentBusinessId } from "../../middleware/auth.js";
import { BookingConfirmationMode, ProfessionalMode } from "../../lib/constants.js";

export const onboardingRouter = Router();

onboardingRouter.get("/status", async (req, res) => {
  const businessId = currentBusinessId(req);
  const business = await prisma.business.findUnique({
    where: { id: businessId },
    select: { onboardingCompletedAt: true, professionalMode: true },
  });
  if (!business) return res.status(404).json({ error: "Negocio no encontrado" });
  res.json({ completed: !!business.onboardingCompletedAt, professionalMode: business.professionalMode });
});

const timeRe = /^([01]\d|2[0-3]):([0-5]\d)$/;

const onboardingSchema = z.object({
  professionalMode: z.enum([ProfessionalMode.SINGLE, ProfessionalMode.MULTI]),
  soleProfessional: z
    .object({
      name: z.string().min(1),
      phone: z.string().optional().or(z.literal("")),
      specialty: z.string().optional().or(z.literal("")),
    })
    .optional(),
  bookingConfirmationMode: z.enum([BookingConfirmationMode.CLIENT_SELF, BookingConfirmationMode.PROFESSIONAL_APPROVAL]),
  reminderDaysBefore: z.coerce.number().int().min(0).max(30),
  reminderHoursBefore: z.coerce.number().int().min(0).max(72),
  unconfirmedFollowupHours: z.coerce.number().int().min(1).max(72),
  autoCancelEnabled: z.boolean(),
  autoCancelHoursBefore: z.coerce.number().int().min(1).max(72).optional(),
  dailySummaryTime: z.string().regex(timeRe, "Formato de hora inválido"),
});

onboardingRouter.post("/complete", async (req, res) => {
  const parsed = onboardingSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const data = parsed.data;
  const businessId = currentBusinessId(req);

  if (data.professionalMode === ProfessionalMode.SINGLE) {
    if (!data.soleProfessional?.name) {
      return res.status(400).json({ error: "Falta el nombre del profesional" });
    }
    if (data.bookingConfirmationMode === BookingConfirmationMode.PROFESSIONAL_APPROVAL && !data.soleProfessional.phone) {
      return res.status(400).json({
        error: "Para que vos apruebes cada turno necesitamos tu teléfono, así te podemos escribir por WhatsApp",
      });
    }
    const existingCount = await prisma.professional.count({ where: { businessId } });
    if (existingCount === 0) {
      await prisma.professional.create({
        data: {
          businessId,
          name: data.soleProfessional.name,
          phone: data.soleProfessional.phone || null,
          specialty: data.soleProfessional.specialty || null,
        },
      });
    }
  }

  const business = await prisma.business.update({
    where: { id: businessId },
    data: {
      professionalMode: data.professionalMode,
      bookingConfirmationMode: data.bookingConfirmationMode,
      reminderDaysBefore: data.reminderDaysBefore,
      reminderHoursBefore: data.reminderHoursBefore,
      unconfirmedFollowupHours: data.unconfirmedFollowupHours,
      autoCancelHoursBefore: data.autoCancelEnabled ? data.autoCancelHoursBefore ?? 24 : 0,
      dailySummaryTime: data.dailySummaryTime,
      onboardingCompletedAt: new Date(),
    },
  });

  res.json({ ok: true, professionalMode: business.professionalMode });
});
