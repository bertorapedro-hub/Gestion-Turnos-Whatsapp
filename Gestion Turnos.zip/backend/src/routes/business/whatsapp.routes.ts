import { Router } from "express";
import { currentBusinessId } from "../../middleware/auth.js";
import { connectBusiness, disconnectBusiness, getCurrentQR, getWhatsAppStatus } from "../../lib/whatsapp.js";

export const whatsappRouter = Router();

whatsappRouter.get("/status", async (req, res) => {
  const businessId = currentBusinessId(req);
  const status = await getWhatsAppStatus(businessId);
  res.json(status);
});

whatsappRouter.post("/connect", async (req, res) => {
  const businessId = currentBusinessId(req);
  connectBusiness(businessId).catch((err) => console.error("Error al conectar WhatsApp:", err));
  res.json({ ok: true });
});

whatsappRouter.get("/qr", async (req, res) => {
  const businessId = currentBusinessId(req);
  const qr = getCurrentQR(businessId);
  res.json({ qr });
});

whatsappRouter.post("/disconnect", async (req, res) => {
  const businessId = currentBusinessId(req);
  await disconnectBusiness(businessId);
  res.json({ ok: true });
});
