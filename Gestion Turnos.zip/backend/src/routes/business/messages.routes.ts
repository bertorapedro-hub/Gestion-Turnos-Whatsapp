import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../lib/prisma.js";
import { currentBusinessId } from "../../middleware/auth.js";
import { renderTemplate, sendAndLog } from "../../lib/messaging.js";
import { MessageEventType, RecipientType } from "../../lib/constants.js";

export const messagesRouter = Router();

messagesRouter.get("/templates", async (req, res) => {
  const businessId = currentBusinessId(req);
  const templates = await prisma.messageTemplate.findMany({ where: { businessId }, orderBy: { eventType: "asc" } });
  res.json(templates);
});

const templateSchema = z.object({ body: z.string().min(1, "El mensaje no puede estar vacío") });

messagesRouter.put("/templates/:eventType", async (req, res) => {
  const parsed = templateSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const businessId = currentBusinessId(req);
  const eventType = req.params.eventType;

  const updated = await prisma.messageTemplate.upsert({
    where: { businessId_eventType: { businessId, eventType } },
    update: { body: parsed.data.body },
    create: { businessId, eventType, body: parsed.data.body },
  });
  res.json(updated);
});

messagesRouter.get("/log", async (req, res) => {
  const businessId = currentBusinessId(req);
  const { eventType, status } = req.query;
  const logs = await prisma.messageLog.findMany({
    where: {
      businessId,
      ...(eventType ? { eventType: String(eventType) } : {}),
      ...(status ? { status: String(status) } : {}),
    },
    orderBy: { createdAt: "desc" },
    take: 200,
  });
  res.json(logs);
});

const broadcastSchema = z.object({
  message: z.string().min(1, "El mensaje no puede estar vacío"),
  professionalId: z.string().optional(),
});

messagesRouter.post("/broadcast", async (req, res) => {
  const parsed = broadcastSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const businessId = currentBusinessId(req);

  const business = await prisma.business.findUnique({ where: { id: businessId } });
  const template = await prisma.messageTemplate.findUnique({
    where: { businessId_eventType: { businessId, eventType: MessageEventType.BROADCAST } },
  });
  const templateBody = template?.body ?? "Hola {{cliente}}! {{mensaje}}";

  let clients;
  if (parsed.data.professionalId) {
    const appts = await prisma.appointment.findMany({
      where: { businessId, professionalId: parsed.data.professionalId },
      select: { client: true },
      distinct: ["clientId"],
    });
    clients = appts.map((a) => a.client);
  } else {
    clients = await prisma.client.findMany({ where: { businessId } });
  }

  let sent = 0;
  for (const client of clients) {
    const body = renderTemplate(templateBody, {
      cliente: client.fullName,
      negocio: business?.name ?? "",
      mensaje: parsed.data.message,
    });
    // eslint-disable-next-line no-await-in-loop
    await sendAndLog({
      businessId,
      phone: client.phone,
      body,
      eventType: MessageEventType.BROADCAST,
      recipientType: RecipientType.BROADCAST,
      recipientName: client.fullName,
    });
    sent += 1;
  }

  res.json({ ok: true, recipients: sent });
});
