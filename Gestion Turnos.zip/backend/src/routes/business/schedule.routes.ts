import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../lib/prisma.js";
import { currentBusinessId } from "../../middleware/auth.js";

export const scheduleRouter = Router();

const timeRe = /^([01]\d|2[0-3]):([0-5]\d)$/;

function professionalIdFilter(raw: unknown): string | null {
  return typeof raw === "string" && raw.length > 0 ? raw : null;
}

scheduleRouter.get("/weekly", async (req, res) => {
  const businessId = currentBusinessId(req);
  const professionalId = professionalIdFilter(req.query.professionalId);
  const schedule = await prisma.weeklySchedule.findMany({
    where: { businessId, professionalId },
    orderBy: [{ weekday: "asc" }, { startTime: "asc" }],
  });
  res.json(schedule);
});

const weeklySchema = z.array(
  z.object({
    weekday: z.number().int().min(0).max(6),
    startTime: z.string().regex(timeRe, "Formato de hora inválido"),
    endTime: z.string().regex(timeRe, "Formato de hora inválido"),
  })
);

scheduleRouter.put("/weekly", async (req, res) => {
  const parsed = weeklySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  for (const entry of parsed.data) {
    if (entry.startTime >= entry.endTime) {
      return res.status(400).json({ error: "El horario de inicio debe ser anterior al de fin" });
    }
  }
  const businessId = currentBusinessId(req);
  const professionalId = professionalIdFilter(req.query.professionalId);

  if (professionalId) {
    const prof = await prisma.professional.findFirst({ where: { id: professionalId, businessId } });
    if (!prof) return res.status(404).json({ error: "Profesional no encontrado" });
  }

  await prisma.$transaction([
    prisma.weeklySchedule.deleteMany({ where: { businessId, professionalId } }),
    prisma.weeklySchedule.createMany({
      data: parsed.data.map((e) => ({
        businessId,
        professionalId,
        weekday: e.weekday,
        startTime: e.startTime,
        endTime: e.endTime,
      })),
    }),
  ]);
  const schedule = await prisma.weeklySchedule.findMany({
    where: { businessId, professionalId },
    orderBy: [{ weekday: "asc" }, { startTime: "asc" }],
  });
  res.json(schedule);
});

scheduleRouter.get("/blocks", async (req, res) => {
  const businessId = currentBusinessId(req);
  const from = req.query.from ? new Date(String(req.query.from)) : undefined;
  const to = req.query.to ? new Date(String(req.query.to)) : undefined;
  const blocks = await prisma.scheduleBlock.findMany({
    where: {
      businessId,
      ...(from || to
        ? {
            AND: [from ? { endAt: { gte: from } } : {}, to ? { startAt: { lte: to } } : {}],
          }
        : {}),
    },
    include: { professional: { select: { id: true, name: true } } },
    orderBy: { startAt: "asc" },
  });
  res.json(blocks);
});

const blockSchema = z.object({
  professionalId: z.string().nullable().optional(),
  startAt: z.string().datetime().or(z.string().min(1)),
  endAt: z.string().datetime().or(z.string().min(1)),
  reason: z.string().optional().or(z.literal("")),
});

scheduleRouter.post("/blocks", async (req, res) => {
  const parsed = blockSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const businessId = currentBusinessId(req);

  const startAt = new Date(parsed.data.startAt);
  const endAt = new Date(parsed.data.endAt);
  if (Number.isNaN(startAt.getTime()) || Number.isNaN(endAt.getTime()) || startAt >= endAt) {
    return res.status(400).json({ error: "El rango de fechas/horas es inválido" });
  }

  if (parsed.data.professionalId) {
    const prof = await prisma.professional.findFirst({ where: { id: parsed.data.professionalId, businessId } });
    if (!prof) return res.status(404).json({ error: "Profesional no encontrado" });
  }

  const block = await prisma.scheduleBlock.create({
    data: {
      businessId,
      professionalId: parsed.data.professionalId || null,
      startAt,
      endAt,
      reason: parsed.data.reason || null,
    },
  });
  res.status(201).json(block);
});

scheduleRouter.delete("/blocks/:id", async (req, res) => {
  const businessId = currentBusinessId(req);
  const existing = await prisma.scheduleBlock.findFirst({ where: { id: req.params.id, businessId } });
  if (!existing) return res.status(404).json({ error: "Bloqueo no encontrado" });
  await prisma.scheduleBlock.delete({ where: { id: existing.id } });
  res.json({ ok: true });
});
