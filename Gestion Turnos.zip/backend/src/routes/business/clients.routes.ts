import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../lib/prisma.js";
import { currentBusinessId } from "../../middleware/auth.js";

export const clientsRouter = Router();

clientsRouter.get("/", async (req, res) => {
  const businessId = currentBusinessId(req);
  const q = String(req.query.q ?? "").trim();
  const clients = await prisma.client.findMany({
    where: {
      businessId,
      ...(q
        ? {
            OR: [
              { documentId: { contains: q } },
              { fullName: { contains: q } },
              { phone: { contains: q } },
            ],
          }
        : {}),
    },
    orderBy: { fullName: "asc" },
    take: 100,
  });
  res.json(clients);
});

clientsRouter.get("/:id", async (req, res) => {
  const businessId = currentBusinessId(req);
  const client = await prisma.client.findFirst({
    where: { id: req.params.id, businessId },
    include: {
      appointments: {
        orderBy: { startAt: "desc" },
        include: { professional: true, service: true },
      },
    },
  });
  if (!client) return res.status(404).json({ error: "Cliente no encontrado" });
  res.json(client);
});

const clientSchema = z.object({
  fullName: z.string().min(1, "El nombre es obligatorio"),
  documentId: z.string().min(1, "El documento es obligatorio"),
  phone: z.string().min(1, "El teléfono es obligatorio"),
});

clientsRouter.post("/", async (req, res) => {
  const parsed = clientSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const businessId = currentBusinessId(req);

  const existing = await prisma.client.findUnique({
    where: { businessId_documentId: { businessId, documentId: parsed.data.documentId } },
  });
  if (existing) return res.status(400).json({ error: "Ya existe un cliente con ese documento" });

  const client = await prisma.client.create({
    data: {
      businessId,
      fullName: parsed.data.fullName,
      documentId: parsed.data.documentId,
      phone: parsed.data.phone,
    },
  });
  res.status(201).json(client);
});

clientsRouter.put("/:id", async (req, res) => {
  const parsed = clientSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const businessId = currentBusinessId(req);
  const existing = await prisma.client.findFirst({ where: { id: req.params.id, businessId } });
  if (!existing) return res.status(404).json({ error: "Cliente no encontrado" });

  const duplicate = await prisma.client.findFirst({
    where: { businessId, documentId: parsed.data.documentId, id: { not: existing.id } },
  });
  if (duplicate) return res.status(400).json({ error: "Ya existe otro cliente con ese documento" });

  const updated = await prisma.client.update({
    where: { id: existing.id },
    data: {
      fullName: parsed.data.fullName,
      documentId: parsed.data.documentId,
      phone: parsed.data.phone,
    },
  });
  res.json(updated);
});
