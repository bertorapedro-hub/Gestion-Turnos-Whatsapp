import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../lib/prisma.js";
import { currentBusinessId } from "../../middleware/auth.js";
import { computeAvailableSlots, isSlotFree } from "../../lib/availability.js";
import { AppointmentStatus, CancelledBy, MessageEventType } from "../../lib/constants.js";
import { invalidateActionLinks, publicBookingUrl } from "../../lib/actionTokens.js";
import { notifyOtherParty } from "../../lib/appointmentMessaging.js";
import { getTemplateBody } from "../../lib/messaging.js";

export const appointmentsRouter = Router();

const appointmentInclude = {
  client: true,
  professional: true,
  service: true,
} as const;

appointmentsRouter.get("/", async (req, res) => {
  const businessId = currentBusinessId(req);
  const { from, to, professionalId, status } = req.query;
  const appointments = await prisma.appointment.findMany({
    where: {
      businessId,
      ...(professionalId ? { professionalId: String(professionalId) } : {}),
      ...(status ? { status: String(status) } : {}),
      ...(from || to
        ? {
            AND: [
              from ? { endAt: { gte: new Date(String(from)) } } : {},
              to ? { startAt: { lte: new Date(String(to)) } } : {},
            ],
          }
        : {}),
    },
    include: appointmentInclude,
    orderBy: { startAt: "asc" },
  });
  res.json(appointments);
});

appointmentsRouter.get("/availability", async (req, res) => {
  const businessId = currentBusinessId(req);
  const { professionalId, serviceId, date } = req.query;
  if (!professionalId || !serviceId || !date) {
    return res.status(400).json({ error: "Faltan parámetros: professionalId, serviceId, date" });
  }
  const result = await computeAvailableSlots({
    businessId,
    professionalId: String(professionalId),
    serviceId: String(serviceId),
    dateStr: String(date),
  });
  if (result.error) return res.status(400).json({ error: result.error });
  res.json(result);
});

const createSchema = z.object({
  clientId: z.string().optional(),
  newClient: z
    .object({
      fullName: z.string().min(1),
      documentId: z.string().min(1),
      phone: z.string().min(1),
    })
    .optional(),
  professionalId: z.string().min(1),
  serviceId: z.string().min(1),
  startAt: z.string().min(1),
  notes: z.string().optional().or(z.literal("")),
});

async function resolveClient(businessId: string, data: z.infer<typeof createSchema>) {
  if (data.clientId) {
    return prisma.client.findFirst({ where: { id: data.clientId, businessId } });
  }
  if (data.newClient) {
    const existing = await prisma.client.findUnique({
      where: { businessId_documentId: { businessId, documentId: data.newClient.documentId } },
    });
    if (existing) {
      return prisma.client.update({
        where: { id: existing.id },
        data: {
          fullName: data.newClient.fullName,
          phone: data.newClient.phone,
        },
      });
    }
    return prisma.client.create({
      data: {
        businessId,
        fullName: data.newClient.fullName,
        documentId: data.newClient.documentId,
        phone: data.newClient.phone,
      },
    });
  }
  return null;
}

appointmentsRouter.post("/", async (req, res) => {
  const parsed = createSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const businessId = currentBusinessId(req);

  const client = await resolveClient(businessId, parsed.data);
  if (!client) return res.status(400).json({ error: "Falta indicar el cliente" });

  const service = await prisma.service.findFirst({
    where: { id: parsed.data.serviceId, businessId, isActive: true },
  });
  if (!service) return res.status(404).json({ error: "Servicio no encontrado" });

  const professional = await prisma.professional.findFirst({
    where: { id: parsed.data.professionalId, businessId, isActive: true },
  });
  if (!professional) return res.status(404).json({ error: "Profesional no encontrado" });

  const startAt = new Date(parsed.data.startAt);
  if (Number.isNaN(startAt.getTime())) return res.status(400).json({ error: "Fecha/hora inválida" });
  const endAt = new Date(startAt.getTime() + service.durationMin * 60000);

  const check = await isSlotFree({ businessId, professionalId: professional.id, startAt, endAt });
  if (!check.ok) return res.status(400).json({ error: check.reason });

  const appointment = await prisma.appointment.create({
    data: {
      businessId,
      clientId: client.id,
      professionalId: professional.id,
      serviceId: service.id,
      startAt,
      endAt,
      status: AppointmentStatus.CONFIRMED,
      notes: parsed.data.notes || null,
    },
    include: appointmentInclude,
  });
  res.status(201).json(appointment);
});

const updateSchema = z.object({
  professionalId: z.string().min(1),
  serviceId: z.string().min(1),
  startAt: z.string().min(1),
  notes: z.string().optional().or(z.literal("")),
});

appointmentsRouter.put("/:id", async (req, res) => {
  const parsed = updateSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const businessId = currentBusinessId(req);

  const existing = await prisma.appointment.findFirst({ where: { id: req.params.id, businessId } });
  if (!existing) return res.status(404).json({ error: "Turno no encontrado" });
  if (existing.status === AppointmentStatus.CANCELLED) {
    return res.status(400).json({ error: "No se puede editar un turno cancelado" });
  }

  const service = await prisma.service.findFirst({ where: { id: parsed.data.serviceId, businessId } });
  if (!service) return res.status(404).json({ error: "Servicio no encontrado" });
  const professional = await prisma.professional.findFirst({ where: { id: parsed.data.professionalId, businessId } });
  if (!professional) return res.status(404).json({ error: "Profesional no encontrado" });

  const startAt = new Date(parsed.data.startAt);
  if (Number.isNaN(startAt.getTime())) return res.status(400).json({ error: "Fecha/hora inválida" });
  const endAt = new Date(startAt.getTime() + service.durationMin * 60000);

  const check = await isSlotFree({
    businessId,
    professionalId: professional.id,
    startAt,
    endAt,
    excludeAppointmentId: existing.id,
  });
  if (!check.ok) return res.status(400).json({ error: check.reason });

  const updated = await prisma.appointment.update({
    where: { id: existing.id },
    data: {
      professionalId: professional.id,
      serviceId: service.id,
      startAt,
      endAt,
      notes: parsed.data.notes || null,
    },
    include: appointmentInclude,
  });
  res.json(updated);
});

appointmentsRouter.post("/:id/confirm", async (req, res) => {
  const businessId = currentBusinessId(req);
  const existing = await prisma.appointment.findFirst({ where: { id: req.params.id, businessId } });
  if (!existing) return res.status(404).json({ error: "Turno no encontrado" });
  const updated = await prisma.appointment.update({
    where: { id: existing.id },
    data: { status: AppointmentStatus.CONFIRMED },
    include: appointmentInclude,
  });
  res.json(updated);
});

appointmentsRouter.post("/:id/cancel", async (req, res) => {
  const businessId = currentBusinessId(req);
  const existing = await prisma.appointment.findFirst({ where: { id: req.params.id, businessId } });
  if (!existing) return res.status(404).json({ error: "Turno no encontrado" });
  const updated = await prisma.appointment.update({
    where: { id: existing.id },
    data: { status: AppointmentStatus.CANCELLED, cancelledBy: CancelledBy.BUSINESS },
    include: appointmentInclude,
  });
  await invalidateActionLinks(existing.id);

  const business = await prisma.business.findUnique({ where: { id: businessId } });
  const templateBody = await getTemplateBody(businessId, MessageEventType.CANCELLED_BY_BUSINESS);
  if (business && templateBody) {
    await notifyOtherParty(updated, business, templateBody, MessageEventType.CANCELLED_BY_BUSINESS, "BUSINESS", {
      link_reservar: publicBookingUrl(business.slug),
    });
  }

  res.json(updated);
});
