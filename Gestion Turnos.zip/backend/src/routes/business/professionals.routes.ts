import { Router } from "express";
import multer from "multer";
import path from "node:path";
import crypto from "node:crypto";
import { z } from "zod";
import { prisma } from "../../lib/prisma.js";
import { currentBusinessId } from "../../middleware/auth.js";

export const professionalsRouter = Router();

const upload = multer({
  storage: multer.diskStorage({
    destination: "uploads/professionals",
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).slice(0, 10);
      cb(null, `${crypto.randomUUID()}${ext}`);
    },
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!file.mimetype.startsWith("image/")) return cb(new Error("El archivo debe ser una imagen"));
    cb(null, true);
  },
});

professionalsRouter.get("/", async (req, res) => {
  const businessId = currentBusinessId(req);
  const includeInactive = req.query.includeInactive === "true";
  const professionals = await prisma.professional.findMany({
    where: { businessId, ...(includeInactive ? {} : { isActive: true }) },
    include: { services: { include: { service: true } } },
    orderBy: { name: "asc" },
  });
  res.json(professionals);
});

const professionalSchema = z.object({
  name: z.string().min(1, "El nombre es obligatorio"),
  specialty: z.string().optional().or(z.literal("")),
  description: z.string().optional().or(z.literal("")),
  phone: z.string().optional().or(z.literal("")),
});

professionalsRouter.post("/", async (req, res) => {
  const parsed = professionalSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const businessId = currentBusinessId(req);
  const professional = await prisma.professional.create({
    data: {
      businessId,
      name: parsed.data.name,
      specialty: parsed.data.specialty || null,
      description: parsed.data.description || null,
      phone: parsed.data.phone || null,
    },
  });
  res.status(201).json(professional);
});

professionalsRouter.put("/:id", async (req, res) => {
  const parsed = professionalSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const businessId = currentBusinessId(req);
  const existing = await prisma.professional.findFirst({ where: { id: req.params.id, businessId } });
  if (!existing) return res.status(404).json({ error: "Profesional no encontrado" });

  const updated = await prisma.professional.update({
    where: { id: existing.id },
    data: {
      name: parsed.data.name,
      specialty: parsed.data.specialty || null,
      description: parsed.data.description || null,
      phone: parsed.data.phone || null,
    },
  });
  res.json(updated);
});

professionalsRouter.post("/:id/photo", upload.single("photo"), async (req, res) => {
  const businessId = currentBusinessId(req);
  const existing = await prisma.professional.findFirst({ where: { id: req.params.id, businessId } });
  if (!existing) return res.status(404).json({ error: "Profesional no encontrado" });
  if (!req.file) return res.status(400).json({ error: "No se recibió ninguna imagen" });

  const photoUrl = `/uploads/professionals/${req.file.filename}`;
  const updated = await prisma.professional.update({ where: { id: existing.id }, data: { photoUrl } });
  res.json(updated);
});

async function setActive(req: import("express").Request, res: import("express").Response, isActive: boolean) {
  const businessId = currentBusinessId(req);
  const existing = await prisma.professional.findFirst({ where: { id: req.params.id, businessId } });
  if (!existing) return res.status(404).json({ error: "Profesional no encontrado" });
  const updated = await prisma.professional.update({ where: { id: existing.id }, data: { isActive } });
  res.json(updated);
}

professionalsRouter.post("/:id/deactivate", (req, res) => setActive(req, res, false));
professionalsRouter.post("/:id/activate", (req, res) => setActive(req, res, true));

professionalsRouter.delete("/:id", async (req, res) => {
  const businessId = currentBusinessId(req);
  const existing = await prisma.professional.findFirst({ where: { id: req.params.id, businessId } });
  if (!existing) return res.status(404).json({ error: "Profesional no encontrado" });

  const appointmentCount = await prisma.appointment.count({ where: { professionalId: existing.id } });
  if (appointmentCount > 0) {
    return res.status(400).json({
      error: "Este profesional tiene turnos asociados. Dalo de baja en lugar de eliminarlo para conservar el historial.",
    });
  }
  await prisma.professional.delete({ where: { id: existing.id } });
  res.json({ ok: true });
});

const linkServicesSchema = z.object({ serviceIds: z.array(z.string()) });

professionalsRouter.put("/:id/services", async (req, res) => {
  const parsed = linkServicesSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Lista de servicios inválida" });
  const businessId = currentBusinessId(req);
  const existing = await prisma.professional.findFirst({ where: { id: req.params.id, businessId } });
  if (!existing) return res.status(404).json({ error: "Profesional no encontrado" });

  const services = await prisma.service.findMany({ where: { businessId, id: { in: parsed.data.serviceIds } } });
  await prisma.$transaction([
    prisma.serviceProfessional.deleteMany({ where: { professionalId: existing.id } }),
    prisma.serviceProfessional.createMany({
      data: services.map((s) => ({ professionalId: existing.id, serviceId: s.id })),
    }),
  ]);
  res.json({ ok: true });
});
