import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../lib/prisma.js";
import { currentBusinessId } from "../../middleware/auth.js";
import { BookingConfirmationMode } from "../../lib/constants.js";

export const settingsRouter = Router();

settingsRouter.get("/", async (req, res) => {
  const businessId = currentBusinessId(req);
  const business = await prisma.business.findUnique({
    where: { id: businessId },
    select: {
      name: true,
      contactPhone: true,
      professionalMode: true,
      bookingConfirmationMode: true,
      reminderDaysBefore: true,
      reminderHoursBefore: true,
      unconfirmedFollowupHours: true,
      autoCancelHoursBefore: true,
      dailySummaryTime: true,
    },
  });
  if (!business) return res.status(404).json({ error: "Negocio no encontrado" });
  res.json(business);
});

const timeRe = /^([01]\d|2[0-3]):([0-5]\d)$/;
const settingsSchema = z.object({
  contactPhone: z.string().optional().or(z.literal("")),
  bookingConfirmationMode: z.enum([BookingConfirmationMode.CLIENT_SELF, BookingConfirmationMode.PROFESSIONAL_APPROVAL]),
  reminderDaysBefore: z.coerce.number().int().min(0).max(30),
  reminderHoursBefore: z.coerce.number().int().min(0).max(72),
  unconfirmedFollowupHours: z.coerce.number().int().min(1).max(72),
  autoCancelHoursBefore: z.coerce.number().int().min(0).max(72),
  dailySummaryTime: z.string().regex(timeRe, "Formato de hora inválido"),
});

settingsRouter.put("/", async (req, res) => {
  const parsed = settingsSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const businessId = currentBusinessId(req);

  const updated = await prisma.business.update({
    where: { id: businessId },
    data: { ...parsed.data, contactPhone: parsed.data.contactPhone || null },
    select: {
      contactPhone: true,
      bookingConfirmationMode: true,
      reminderDaysBefore: true,
      reminderHoursBefore: true,
      unconfirmedFollowupHours: true,
      autoCancelHoursBefore: true,
      dailySummaryTime: true,
    },
  });
  res.json(updated);
});
