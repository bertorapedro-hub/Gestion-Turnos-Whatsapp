import { Router } from "express";
import { requireAuth, requireBusinessOwner } from "../../middleware/auth.js";
import { professionalsRouter } from "./professionals.routes.js";
import { servicesRouter } from "./services.routes.js";
import { scheduleRouter } from "./schedule.routes.js";
import { clientsRouter } from "./clients.routes.js";
import { appointmentsRouter } from "./appointments.routes.js";
import { messagesRouter } from "./messages.routes.js";
import { whatsappRouter } from "./whatsapp.routes.js";
import { settingsRouter } from "./settings.routes.js";
import { onboardingRouter } from "./onboarding.routes.js";

export const businessRouter = Router();
businessRouter.use(requireAuth, requireBusinessOwner);

businessRouter.use("/professionals", professionalsRouter);
businessRouter.use("/services", servicesRouter);
businessRouter.use("/schedule", scheduleRouter);
businessRouter.use("/clients", clientsRouter);
businessRouter.use("/appointments", appointmentsRouter);
businessRouter.use("/messages", messagesRouter);
businessRouter.use("/whatsapp", whatsappRouter);
businessRouter.use("/settings", settingsRouter);
businessRouter.use("/onboarding", onboardingRouter);
