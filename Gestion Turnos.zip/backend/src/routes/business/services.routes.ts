import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../lib/prisma.js";
import { currentBusinessId } from "../../middleware/auth.js";

export const servicesRouter = Router();

servicesRouter.get("/", async (req, res) => {
  const businessId = currentBusinessId(req);
  const includeInactive = req.query.includeInactive === "true";
  const services = await prisma.service.findMany({
    where: { businessId, ...(includeInactive ? {} : { isActive: true }) },
    include: { professionals: { include: { professional: true } } },
    orderBy: { name: "asc" },
  });
  res.json(services);
});

const serviceSchema = z.object({
  name: z.string().min(1, "El nombre es obligatorio"),
  durationMin: z.coerce.number().int().min(5, "La duración mínima es 5 minutos"),
  price: z.coerce.number().min(0, "El precio no puede ser negativo"),
  professionalIds: z.array(z.string()).default([]),
});

servicesRouter.post("/", async (req, res) => {
  const parsed = serviceSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const businessId = currentBusinessId(req);

  const professionals = await prisma.professional.findMany({
    where: { businessId, id: { in: parsed.data.professionalIds } },
  });

  const service = await prisma.service.create({
    data: {
      businessId,
      name: parsed.data.name,
      durationMin: parsed.data.durationMin,
      price: parsed.data.price,
      professionals: { create: professionals.map((p) => ({ professionalId: p.id })) },
    },
    include: { professionals: { include: { professional: true } } },
  });
  res.status(201).json(service);
});

servicesRouter.put("/:id", async (req, res) => {
  const parsed = serviceSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
  const businessId = currentBusinessId(req);
  const existing = await prisma.service.findFirst({ where: { id: req.params.id, businessId } });
  if (!existing) return res.status(404).json({ error: "Servicio no encontrado" });

  const professionals = await prisma.professional.findMany({
    where: { businessId, id: { in: parsed.data.professionalIds } },
  });

  await prisma.$transaction([
    prisma.service.update({
      where: { id: existing.id },
      data: { name: parsed.data.name, durationMin: parsed.data.durationMin, price: parsed.data.price },
    }),
    prisma.serviceProfessional.deleteMany({ where: { serviceId: existing.id } }),
    prisma.serviceProfessional.createMany({
      data: professionals.map((p) => ({ serviceId: existing.id, professionalId: p.id })),
    }),
  ]);

  const updated = await prisma.service.findUnique({
    where: { id: existing.id },
    include: { professionals: { include: { professional: true } } },
  });
  res.json(updated);
});

async function setActive(req: import("express").Request, res: import("express").Response, isActive: boolean) {
  const businessId = currentBusinessId(req);
  const existing = await prisma.service.findFirst({ where: { id: req.params.id, businessId } });
  if (!existing) return res.status(404).json({ error: "Servicio no encontrado" });
  const updated = await prisma.service.update({ where: { id: existing.id }, data: { isActive } });
  res.json(updated);
}

servicesRouter.post("/:id/deactivate", (req, res) => setActive(req, res, false));
servicesRouter.post("/:id/activate", (req, res) => setActive(req, res, true));

servicesRouter.delete("/:id", async (req, res) => {
  const businessId = currentBusinessId(req);
  const existing = await prisma.service.findFirst({ where: { id: req.params.id, businessId } });
  if (!existing) return res.status(404).json({ error: "Servicio no encontrado" });

  const appointmentCount = await prisma.appointment.count({ where: { serviceId: existing.id } });
  if (appointmentCount > 0) {
    return res.status(400).json({
      error: "Este servicio tiene turnos asociados. Dalo de baja en lugar de eliminarlo para conservar el historial.",
    });
  }
  await prisma.service.delete({ where: { id: existing.id } });
  res.json({ ok: true });
});
