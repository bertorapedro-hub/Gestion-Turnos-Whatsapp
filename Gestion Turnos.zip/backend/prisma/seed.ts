import "dotenv/config";
import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";
import { Role } from "../src/lib/constants.js";

const prisma = new PrismaClient();

async function main() {
  const username = process.env.SUPERADMIN_USERNAME ?? "superadmin";
  const password = process.env.SUPERADMIN_PASSWORD ?? "cambiar-esta-clave";

  const existing = await prisma.user.findUnique({ where: { username } });
  if (existing) {
    console.log(`Superadmin "${username}" ya existe, no se recrea.`);
    return;
  }

  const passwordHash = await bcrypt.hash(password, 10);
  await prisma.user.create({
    data: { username, passwordHash, role: Role.SUPERADMIN },
  });
  console.log(`Superadmin "${username}" creado.`);
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
