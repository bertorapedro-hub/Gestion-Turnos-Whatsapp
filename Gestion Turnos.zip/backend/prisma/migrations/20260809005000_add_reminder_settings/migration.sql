-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Business" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "contactEmail" TEXT,
    "contactPhone" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "reminderDaysBefore" INTEGER NOT NULL DEFAULT 1,
    "reminderHoursBefore" INTEGER NOT NULL DEFAULT 2,
    "unconfirmedFollowupHours" INTEGER NOT NULL DEFAULT 3,
    "dailySummaryTime" TEXT NOT NULL DEFAULT '08:00',
    "dailySummaryLastSentDate" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_Business" ("contactEmail", "contactPhone", "createdAt", "id", "isActive", "name", "slug", "updatedAt") SELECT "contactEmail", "contactPhone", "createdAt", "id", "isActive", "name", "slug", "updatedAt" FROM "Business";
DROP TABLE "Business";
ALTER TABLE "new_Business" RENAME TO "Business";
CREATE UNIQUE INDEX "Business_slug_key" ON "Business"("slug");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
