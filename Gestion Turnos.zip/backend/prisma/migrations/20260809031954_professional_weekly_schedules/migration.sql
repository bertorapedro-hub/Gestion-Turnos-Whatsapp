-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_WeeklySchedule" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "businessId" TEXT NOT NULL,
    "professionalId" TEXT,
    "weekday" INTEGER NOT NULL,
    "startTime" TEXT NOT NULL,
    "endTime" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "WeeklySchedule_businessId_fkey" FOREIGN KEY ("businessId") REFERENCES "Business" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "WeeklySchedule_professionalId_fkey" FOREIGN KEY ("professionalId") REFERENCES "Professional" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_WeeklySchedule" ("businessId", "createdAt", "endTime", "id", "startTime", "weekday") SELECT "businessId", "createdAt", "endTime", "id", "startTime", "weekday" FROM "WeeklySchedule";
DROP TABLE "WeeklySchedule";
ALTER TABLE "new_WeeklySchedule" RENAME TO "WeeklySchedule";
CREATE INDEX "WeeklySchedule_businessId_professionalId_weekday_idx" ON "WeeklySchedule"("businessId", "professionalId", "weekday");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
