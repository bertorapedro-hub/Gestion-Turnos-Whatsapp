-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Business" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "contactEmail" TEXT,
    "contactPhone" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "reminderDaysBefore" INTEGER NOT NULL DEFAULT 1,
    "reminderHoursBefore" INTEGER NOT NULL DEFAULT 2,
    "unconfirmedFollowupHours" INTEGER NOT NULL DEFAULT 3,
    "autoCancelHoursBefore" INTEGER NOT NULL DEFAULT 0,
    "dailySummaryTime" TEXT NOT NULL DEFAULT '08:00',
    "dailySummaryLastSentDate" TEXT,
    "professionalMode" TEXT NOT NULL DEFAULT 'MULTI',
    "bookingConfirmationMode" TEXT NOT NULL DEFAULT 'CLIENT_SELF',
    "onboardingCompletedAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_Business" ("autoCancelHoursBefore", "contactEmail", "contactPhone", "createdAt", "dailySummaryLastSentDate", "dailySummaryTime", "id", "isActive", "name", "onboardingCompletedAt", "professionalMode", "reminderDaysBefore", "reminderHoursBefore", "slug", "unconfirmedFollowupHours", "updatedAt") SELECT "autoCancelHoursBefore", "contactEmail", "contactPhone", "createdAt", "dailySummaryLastSentDate", "dailySummaryTime", "id", "isActive", "name", "onboardingCompletedAt", "professionalMode", "reminderDaysBefore", "reminderHoursBefore", "slug", "unconfirmedFollowupHours", "updatedAt" FROM "Business";
DROP TABLE "Business";
ALTER TABLE "new_Business" RENAME TO "Business";
CREATE UNIQUE INDEX "Business_slug_key" ON "Business"("slug");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
