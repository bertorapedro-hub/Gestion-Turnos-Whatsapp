-- El sistema es 100% por WhatsApp, el email nunca se usó para nada funcional.
ALTER TABLE "Business" DROP COLUMN "contactEmail";
ALTER TABLE "Client" DROP COLUMN "email";
