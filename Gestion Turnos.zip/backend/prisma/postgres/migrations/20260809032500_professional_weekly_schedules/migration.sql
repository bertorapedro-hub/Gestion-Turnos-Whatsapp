-- AlterTable
ALTER TABLE "WeeklySchedule" ADD COLUMN     "professionalId" TEXT;

-- DropIndex (nombre generado por Prisma para el índice anterior)
DROP INDEX IF EXISTS "WeeklySchedule_businessId_weekday_idx";

-- CreateIndex
CREATE INDEX "WeeklySchedule_businessId_professionalId_weekday_idx" ON "WeeklySchedule"("businessId", "professionalId", "weekday");

-- AddForeignKey
ALTER TABLE "WeeklySchedule" ADD CONSTRAINT "WeeklySchedule_professionalId_fkey" FOREIGN KEY ("professionalId") REFERENCES "Professional"("id") ON DELETE CASCADE ON UPDATE CASCADE;
