-- AlterTable
ALTER TABLE "Business"
  ADD COLUMN "autoCancelHoursBefore" INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN "professionalMode" TEXT NOT NULL DEFAULT 'MULTI',
  ADD COLUMN "onboardingCompletedAt" TIMESTAMP(3);

-- Backfill: los negocios que ya existían antes de esta migración se consideran
-- "ya configurados" y no deben ver el asistente de bienvenida.
UPDATE "Business" SET "onboardingCompletedAt" = CURRENT_TIMESTAMP WHERE "onboardingCompletedAt" IS NULL;
