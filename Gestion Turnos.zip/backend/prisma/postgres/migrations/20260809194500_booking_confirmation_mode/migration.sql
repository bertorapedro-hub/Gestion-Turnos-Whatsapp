-- AlterTable
ALTER TABLE "Business" ADD COLUMN "bookingConfirmationMode" TEXT NOT NULL DEFAULT 'CLIENT_SELF';
