import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import RequireRole from "./components/RequireRole";
import SuperadminLogin from "./pages/superadmin/SuperadminLogin";
import SuperadminLayout from "./pages/superadmin/SuperadminLayout";
import BusinessDashboard from "./pages/superadmin/BusinessDashboard";
import ChangePassword from "./pages/ChangePassword";
import BusinessLogin from "./pages/business/BusinessLogin";
import BusinessLayout from "./pages/business/BusinessLayout";
import BusinessHome from "./pages/business/BusinessHome";
import ProfessionalsPage from "./pages/business/ProfessionalsPage";
import ServicesPage from "./pages/business/ServicesPage";
import SchedulePage from "./pages/business/SchedulePage";
import BlocksPage from "./pages/business/BlocksPage";
import AppointmentsPage from "./pages/business/AppointmentsPage";
import ClientsPage from "./pages/business/ClientsPage";
import PublicBookingPage from "./pages/public/PublicBookingPage";
import MyAppointmentsPage from "./pages/public/MyAppointmentsPage";
import MessagesPage from "./pages/business/MessagesPage";
import WhatsAppPage from "./pages/business/WhatsAppPage";
import ActionPage from "./pages/public/ActionPage";
import OnboardingWizard from "./pages/business/OnboardingWizard";

function Home() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-2 text-center">
      <h1 className="text-xl font-semibold text-gray-900">Gestión de Turnos</h1>
      <p className="text-sm text-gray-500">
        Panel de negocio: <a className="text-indigo-600 hover:underline" href="/admin/login">/admin/login</a>
        {" · "}
        Superadmin: <a className="text-indigo-600 hover:underline" href="/superadmin/login">/superadmin/login</a>
      </p>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/" element={<Home />} />

          <Route path="/superadmin/login" element={<SuperadminLogin />} />
          <Route
            path="/superadmin"
            element={
              <RequireRole role="SUPERADMIN" redirectTo="/superadmin/login">
                <SuperadminLayout />
              </RequireRole>
            }
          >
            <Route index element={<BusinessDashboard />} />
            <Route path="password" element={<ChangePassword />} />
          </Route>

          <Route path="/admin/login" element={<BusinessLogin />} />
          <Route
            path="/admin/bienvenida"
            element={
              <RequireRole role="BUSINESS_OWNER" redirectTo="/admin/login">
                <OnboardingWizard />
              </RequireRole>
            }
          />
          <Route
            path="/admin"
            element={
              <RequireRole role="BUSINESS_OWNER" redirectTo="/admin/login">
                <BusinessLayout />
              </RequireRole>
            }
          >
            <Route index element={<BusinessHome />} />
            <Route path="turnos" element={<AppointmentsPage />} />
            <Route path="clientes" element={<ClientsPage />} />
            <Route path="profesionales" element={<ProfessionalsPage />} />
            <Route path="servicios" element={<ServicesPage />} />
            <Route path="horarios" element={<SchedulePage />} />
            <Route path="bloqueos" element={<BlocksPage />} />
            <Route path="mensajes" element={<MessagesPage />} />
            <Route path="whatsapp" element={<WhatsAppPage />} />
            <Route path="password" element={<ChangePassword />} />
          </Route>

          <Route path="/reservar/:slug" element={<PublicBookingPage />} />
          <Route path="/reservar/:slug/mis-turnos" element={<MyAppointmentsPage />} />
          <Route path="/accion/:token" element={<ActionPage />} />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
