export const PHONE_HINT = "Ej: 5491122233344 (código de país + 9 + código de área sin 0 + número sin 15)";

export function isValidPhone(phone: string) {
  const digits = phone.replace(/\D/g, "");
  return digits.length >= 10 && digits.length <= 15;
}
