export interface Business {
  id: string;
  name: string;
  slug: string;
  contactPhone: string | null;
  isActive: boolean;
  createdAt: string;
  _count?: { appointments: number; professionals: number; clients: number };
  users?: { username: string }[];
}

export interface Professional {
  id: string;
  businessId: string;
  name: string;
  specialty: string | null;
  description: string | null;
  photoUrl: string | null;
  phone: string | null;
  isActive: boolean;
  services?: { service: Service }[];
}

export interface Service {
  id: string;
  businessId: string;
  name: string;
  durationMin: number;
  price: number;
  isActive: boolean;
  professionals?: { professional: Professional }[];
}

export interface WeeklyScheduleEntry {
  id: string;
  professionalId: string | null;
  weekday: number;
  startTime: string;
  endTime: string;
}

export interface ScheduleBlock {
  id: string;
  professionalId: string | null;
  professional?: { id: string; name: string } | null;
  startAt: string;
  endAt: string;
  reason: string | null;
}

export interface Client {
  id: string;
  fullName: string;
  documentId: string;
  phone: string;
}

export interface Appointment {
  id: string;
  clientId: string;
  client: Client;
  professionalId: string;
  professional: Professional;
  serviceId: string;
  service: Service;
  startAt: string;
  endAt: string;
  status: "PENDING" | "CONFIRMED" | "CANCELLED" | "DONE";
  cancelledBy: string | null;
  notes: string | null;
}

export const WEEKDAY_NAMES = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
