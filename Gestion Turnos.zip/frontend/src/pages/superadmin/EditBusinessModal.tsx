import { useState } from "react";
import { api, ApiError } from "../../lib/api";
import { Button, ErrorText, Field, Input } from "../../components/ui";
import { PhoneInput } from "../../components/PhoneInput";
import type { Business } from "../../types";

export default function EditBusinessModal({
  business,
  onClose,
  onUpdated,
}: {
  business: Business;
  onClose: () => void;
  onUpdated: (b: Business) => void;
}) {
  const [name, setName] = useState(business.name);
  const [contactPhone, setContactPhone] = useState(business.contactPhone ?? "");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const updated = await api.put<Business>(`/api/superadmin/businesses/${business.id}`, {
        name,
        contactPhone,
      });
      onUpdated({ ...business, ...updated });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al actualizar el negocio");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
      <div className="w-full max-w-md rounded-xl bg-white p-6 shadow-lg">
        <h2 className="mb-4 text-lg font-semibold text-gray-900">Editar negocio</h2>
        <form onSubmit={handleSubmit} className="space-y-3">
          <Field label="Nombre del negocio">
            <Input value={name} onChange={(e) => setName(e.target.value)} required autoFocus />
          </Field>
          <Field label="Teléfono de contacto">
            <PhoneInput value={contactPhone} onChange={setContactPhone} />
          </Field>
          <ErrorText>{error}</ErrorText>
          <div className="mt-4 flex justify-end gap-2">
            <Button type="button" variant="secondary" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Guardando..." : "Guardar cambios"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
