import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { Button } from "../../components/ui";

export default function SuperadminLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    await logout();
    navigate("/superadmin/login");
  }

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `rounded-lg px-3 py-2 text-sm font-medium ${isActive ? "bg-indigo-50 text-indigo-700" : "text-gray-600 hover:bg-gray-100"}`;

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="border-b border-gray-200 bg-white">
        <div className="mx-auto max-w-6xl px-4 py-3">
          <div className="mb-2 flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-gray-900">Panel Superadministrador</p>
              <p className="text-xs text-gray-500">{user?.username}</p>
            </div>
            <Button variant="ghost" onClick={handleLogout}>
              Salir
            </Button>
          </div>
          <nav className="flex flex-wrap gap-1 overflow-x-auto">
            <NavLink to="/superadmin" end className={linkClass}>
              Negocios
            </NavLink>
            <NavLink to="/superadmin/password" className={linkClass}>
              Mi contraseña
            </NavLink>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6">
        <Outlet />
      </main>
    </div>
  );
}
