import { useEffect, useState } from "react";
import { api, ApiError } from "../../lib/api";
import { Badge, Button, Card } from "../../components/ui";
import type { Business } from "../../types";
import CreateBusinessModal from "./CreateBusinessModal";
import EditBusinessModal from "./EditBusinessModal";

export default function BusinessDashboard() {
  const [businesses, setBusinesses] = useState<Business[] | null>(null);
  const [error, setError] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [editing, setEditing] = useState<Business | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function load() {
    try {
      const data = await api.get<Business[]>("/api/superadmin/businesses");
      setBusinesses(data);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al cargar los negocios");
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function togglePause(b: Business) {
    setBusyId(b.id);
    try {
      const action = b.isActive ? "pause" : "reactivate";
      const updated = await api.post<Business>(`/api/superadmin/businesses/${b.id}/${action}`);
      setBusinesses((prev) => prev?.map((x) => (x.id === b.id ? { ...x, ...updated } : x)) ?? null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al actualizar el estado");
    } finally {
      setBusyId(null);
    }
  }

  async function handleDelete(b: Business) {
    const confirmed = window.confirm(
      `¿Eliminar definitivamente "${b.name}"? Esta acción borra todos sus datos (turnos, clientes, profesionales, mensajes) y no se puede deshacer.`
    );
    if (!confirmed) return;
    setBusyId(b.id);
    try {
      await api.del(`/api/superadmin/businesses/${b.id}`);
      setBusinesses((prev) => prev?.filter((x) => x.id !== b.id) ?? null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al eliminar el negocio");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-lg font-semibold text-gray-900">Negocios</h1>
        <Button onClick={() => setShowCreate(true)}>+ Nuevo negocio</Button>
      </div>

      {error && <p className="mb-3 text-sm text-red-600">{error}</p>}

      <Card className="overflow-x-auto p-0">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="border-b border-gray-200 bg-gray-50 text-xs uppercase text-gray-500">
            <tr>
              <th className="px-4 py-3">Negocio</th>
              <th className="px-4 py-3">Usuario</th>
              <th className="px-4 py-3">Estado</th>
              <th className="px-4 py-3">Turnos</th>
              <th className="px-4 py-3">Link público</th>
              <th className="px-4 py-3 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {businesses?.map((b) => (
              <tr key={b.id} className="border-b border-gray-100 last:border-0">
                <td className="px-4 py-3">
                  <p className="font-medium text-gray-900">{b.name}</p>
                  <p className="text-xs text-gray-500">{b.contactPhone || "—"}</p>
                </td>
                <td className="px-4 py-3 text-gray-600">{b.users?.[0]?.username ?? "—"}</td>
                <td className="px-4 py-3">
                  <Badge tone={b.isActive ? "green" : "yellow"}>{b.isActive ? "Activo" : "Pausado"}</Badge>
                </td>
                <td className="px-4 py-3 text-gray-600">{b._count?.appointments ?? 0}</td>
                <td className="px-4 py-3">
                  <a href={`/reservar/${b.slug}`} target="_blank" rel="noreferrer" className="text-indigo-600 hover:underline">
                    /reservar/{b.slug}
                  </a>
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    <Button variant="secondary" onClick={() => setEditing(b)}>
                      Editar
                    </Button>
                    <Button variant="secondary" disabled={busyId === b.id} onClick={() => togglePause(b)}>
                      {b.isActive ? "Pausar" : "Reactivar"}
                    </Button>
                    <Button variant="danger" disabled={busyId === b.id} onClick={() => handleDelete(b)}>
                      Eliminar
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {businesses?.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                  Todavía no hay negocios cargados.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Card>

      {showCreate && (
        <CreateBusinessModal
          onClose={() => setShowCreate(false)}
          onCreated={(b) => {
            setBusinesses((prev) => [b, ...(prev ?? [])]);
            setShowCreate(false);
          }}
        />
      )}
      {editing && (
        <EditBusinessModal
          business={editing}
          onClose={() => setEditing(null)}
          onUpdated={(b) => {
            setBusinesses((prev) => prev?.map((x) => (x.id === b.id ? b : x)) ?? null);
            setEditing(null);
          }}
        />
      )}
    </div>
  );
}
