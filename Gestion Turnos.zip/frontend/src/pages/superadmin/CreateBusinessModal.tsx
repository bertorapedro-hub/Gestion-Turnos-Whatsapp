import { useState } from "react";
import { api, ApiError } from "../../lib/api";
import { Button, ErrorText, Field, Input } from "../../components/ui";
import { PhoneInput } from "../../components/PhoneInput";
import type { Business } from "../../types";

export default function CreateBusinessModal({
  onClose,
  onCreated,
}: {
  onClose: () => void;
  onCreated: (b: Business) => void;
}) {
  const [name, setName] = useState("");
  const [contactPhone, setContactPhone] = useState("");
  const [ownerUsername, setOwnerUsername] = useState("");
  const [ownerPassword, setOwnerPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const business = await api.post<Business>("/api/superadmin/businesses", {
        name,
        contactPhone,
        ownerUsername,
        ownerPassword,
      });
      onCreated(business);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al crear el negocio");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
      <div className="w-full max-w-md rounded-xl bg-white p-6 shadow-lg">
        <h2 className="mb-4 text-lg font-semibold text-gray-900">Nuevo negocio</h2>
        <form onSubmit={handleSubmit} className="space-y-3">
          <Field label="Nombre del negocio">
            <Input value={name} onChange={(e) => setName(e.target.value)} required autoFocus />
          </Field>
          <Field label="Teléfono de contacto">
            <PhoneInput value={contactPhone} onChange={setContactPhone} />
          </Field>
          <hr className="my-1 border-gray-200" />
          <p className="text-xs text-gray-500">Credenciales de acceso al panel del negocio</p>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Usuario">
              <Input value={ownerUsername} onChange={(e) => setOwnerUsername(e.target.value)} required />
            </Field>
            <Field label="Contraseña">
              <Input type="password" value={ownerPassword} onChange={(e) => setOwnerPassword(e.target.value)} required />
            </Field>
          </div>
          <ErrorText>{error}</ErrorText>
          <div className="mt-4 flex justify-end gap-2">
            <Button type="button" variant="secondary" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Creando..." : "Crear negocio"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
