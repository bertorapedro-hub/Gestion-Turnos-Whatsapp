import { useEffect, useMemo, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { api, ApiError } from "../../lib/api";
import { Button, Card, ErrorText, Field, Input } from "../../components/ui";
import { PhoneInput } from "../../components/PhoneInput";
import { PHONE_HINT, isValidPhone } from "../../lib/validation";

interface PublicProfessional {
  id: string;
  name: string;
  specialty: string | null;
  description: string | null;
  photoUrl: string | null;
}
interface PublicService {
  id: string;
  name: string;
  durationMin: number;
  price: number;
  professionalIds: string[];
}
interface PublicBusiness {
  id: string;
  name: string;
  slug: string;
  contactPhone: string | null;
  professionalMode: "SINGLE" | "MULTI";
  professionals: PublicProfessional[];
  services: PublicService[];
}

const currency = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export default function PublicBookingPage() {
  const { slug } = useParams<{ slug: string }>();
  const [business, setBusiness] = useState<PublicBusiness | null | undefined>(undefined);
  const [professionalId, setProfessionalId] = useState("");
  const [serviceId, setServiceId] = useState("");
  const [date, setDate] = useState(todayStr());
  const [slots, setSlots] = useState<string[]>([]);
  const [selectedSlot, setSelectedSlot] = useState("");
  const [loadingSlots, setLoadingSlots] = useState(false);

  const [fullName, setFullName] = useState("");
  const [documentId, setDocumentId] = useState("");
  const [phone, setPhone] = useState("");
  const [lookupStatus, setLookupStatus] = useState<"idle" | "checking" | "found" | "not_found">("idle");
  const [lookupError, setLookupError] = useState("");
  const [editingFound, setEditingFound] = useState(false);

  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [showReview, setShowReview] = useState(false);

  async function handleLookup(e: React.FormEvent) {
    e.preventDefault();
    setLookupError("");
    if (!documentId.trim()) {
      setLookupError("Ingresá tu documento");
      return;
    }
    setLookupStatus("checking");
    setEditingFound(false);
    try {
      const result = await api.get<{ found: boolean; fullName?: string; phone?: string }>(
        `/api/public/${slug}/clients/lookup?documentId=${encodeURIComponent(documentId.trim())}`
      );
      if (result.found) {
        setFullName(result.fullName ?? "");
        setPhone(result.phone ?? "");
        setLookupStatus("found");
      } else {
        setFullName("");
        setPhone("");
        setLookupStatus("not_found");
      }
    } catch (err) {
      setLookupError(err instanceof ApiError ? err.message : "Error al buscar tus datos");
      setLookupStatus("idle");
    }
  }

  function resetLookup() {
    setLookupStatus("idle");
    setEditingFound(false);
    setShowReview(false);
    setFullName("");
    setPhone("");
  }

  useEffect(() => {
    api
      .get<PublicBusiness>(`/api/public/${slug}`)
      .then((b) => {
        setBusiness(b);
        if (b.professionalMode === "SINGLE" && b.professionals.length === 1) {
          setProfessionalId(b.professionals[0].id);
        }
      })
      .catch(() => setBusiness(null));
  }, [slug]);

  const availableServices = useMemo(
    () => business?.services.filter((s) => !professionalId || s.professionalIds.includes(professionalId)) ?? [],
    [business, professionalId]
  );

  useEffect(() => {
    setSelectedSlot("");
    setSlots([]);
    setShowReview(false);
    if (!professionalId || !serviceId || !date) return;
    setLoadingSlots(true);
    api
      .get<{ slots: string[] }>(
        `/api/public/${slug}/availability?professionalId=${professionalId}&serviceId=${serviceId}&date=${date}`
      )
      .then((r) => setSlots(r.slots))
      .catch(() => setSlots([]))
      .finally(() => setLoadingSlots(false));
  }, [slug, professionalId, serviceId, date]);

  function handleReviewRequest(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!isValidPhone(phone)) {
      setError(`Revisá el teléfono, no parece completo. ${PHONE_HINT}`);
      return;
    }
    setShowReview(true);
  }

  async function handleSubmit() {
    setError("");
    if (!selectedSlot) {
      setError("Elegí un horario disponible");
      return;
    }
    setSubmitting(true);
    try {
      const startAt = new Date(`${date}T${selectedSlot}:00`).toISOString();
      await api.post(`/api/public/${slug}/appointments`, {
        professionalId,
        serviceId,
        startAt,
        client: { fullName, documentId, phone },
      });
      setConfirmed(true);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al reservar el turno");
    } finally {
      setSubmitting(false);
    }
  }

  if (business === undefined) {
    return <div className="flex min-h-screen items-center justify-center text-sm text-gray-500">Cargando...</div>;
  }
  if (business === null) {
    return (
      <div className="flex min-h-screen items-center justify-center text-center">
        <p className="text-sm text-gray-500">Este negocio no está disponible en este momento.</p>
      </div>
    );
  }

  if (confirmed) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4">
        <Card className="w-full max-w-sm text-center">
          <p className="mb-2 text-2xl">✅</p>
          <h1 className="mb-1 text-lg font-semibold text-gray-900">¡Turno reservado!</h1>
          <p className="text-sm text-gray-500">
            Te esperamos el {date} a las {selectedSlot} en {business.name}.
          </p>
          <Link to={`/reservar/${slug}/mis-turnos`} className="mt-4 inline-block text-sm text-indigo-600 hover:underline">
            Ver mis turnos
          </Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 px-4 py-8">
      <div className="mx-auto max-w-2xl">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-xl font-semibold text-gray-900">{business.name}</h1>
          <Link to={`/reservar/${slug}/mis-turnos`} className="text-sm text-indigo-600 hover:underline">
            Mis turnos
          </Link>
        </div>

        {business.professionalMode !== "SINGLE" && (
        <Card className="mb-4">
          <h2 className="mb-3 text-sm font-semibold text-gray-900">Profesionales</h2>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {business.professionals.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => {
                  setProfessionalId(p.id);
                  setServiceId("");
                }}
                className={`flex items-center gap-3 rounded-lg border p-3 text-left ${
                  professionalId === p.id ? "border-indigo-600 bg-indigo-50" : "border-gray-200 hover:bg-gray-50"
                }`}
              >
                {p.photoUrl ? (
                  <img src={p.photoUrl} alt="" className="h-10 w-10 rounded-full object-cover" />
                ) : (
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-indigo-100 text-xs font-semibold text-indigo-700">
                    {p.name.slice(0, 2).toUpperCase()}
                  </div>
                )}
                <div>
                  <p className="text-sm font-medium text-gray-900">{p.name}</p>
                  <p className="text-xs text-gray-500">{p.specialty}</p>
                </div>
              </button>
            ))}
          </div>
        </Card>
        )}

        {professionalId && (
          <Card className="mb-4">
            <h2 className="mb-3 text-sm font-semibold text-gray-900">Servicios</h2>
            <div className="grid grid-cols-1 gap-2">
              {availableServices.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setServiceId(s.id)}
                  className={`flex items-center justify-between rounded-lg border p-3 text-left ${
                    serviceId === s.id ? "border-indigo-600 bg-indigo-50" : "border-gray-200 hover:bg-gray-50"
                  }`}
                >
                  <div>
                    <p className="text-sm font-medium text-gray-900">{s.name}</p>
                    <p className="text-xs text-gray-500">{s.durationMin} min</p>
                  </div>
                  <p className="text-sm font-semibold text-gray-900">{currency.format(s.price)}</p>
                </button>
              ))}
              {availableServices.length === 0 && (
                <p className="text-sm text-gray-400">Este profesional no tiene servicios cargados.</p>
              )}
            </div>
          </Card>
        )}

        {serviceId && (
          <Card className="mb-4">
            <h2 className="mb-3 text-sm font-semibold text-gray-900">Fecha y horario</h2>
            <Field label="Fecha">
              <Input type="date" value={date} min={todayStr()} onChange={(e) => setDate(e.target.value)} />
            </Field>
            <div className="mt-3">
              {loadingSlots && <p className="text-sm text-gray-400">Buscando horarios...</p>}
              {!loadingSlots && slots.length === 0 && <p className="text-sm text-gray-400">No hay horarios libres ese día.</p>}
              <div className="flex flex-wrap gap-2">
                {slots.map((s) => (
                  <button
                    type="button"
                    key={s}
                    onClick={() => {
                      setSelectedSlot(s);
                      setShowReview(false);
                    }}
                    className={`min-h-11 rounded-lg border px-3 py-2 text-sm ${
                      selectedSlot === s
                        ? "border-indigo-600 bg-indigo-600 text-white"
                        : "border-gray-300 text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </Card>
        )}

        {selectedSlot && lookupStatus === "idle" && (
          <Card>
            <h2 className="mb-3 text-sm font-semibold text-gray-900">Tus datos</h2>
            <form onSubmit={handleLookup} className="space-y-3">
              <Field label="Documento">
                <Input value={documentId} onChange={(e) => setDocumentId(e.target.value)} required autoFocus />
              </Field>
              <ErrorText>{lookupError}</ErrorText>
              <Button type="submit" className="w-full">
                Continuar
              </Button>
            </form>
          </Card>
        )}

        {selectedSlot && lookupStatus === "checking" && (
          <Card>
            <p className="text-sm text-gray-500">Buscando tus datos...</p>
          </Card>
        )}

        {selectedSlot && lookupStatus === "found" && !showReview && (
          <Card>
            <h2 className="mb-3 text-sm font-semibold text-gray-900">Tus datos</h2>

            {!editingFound && (
              <>
                <div className="mb-3 rounded-lg bg-green-50 p-3 text-sm text-green-800">
                  Reservando para <strong>{fullName}</strong> ({phone})
                </div>
                <div className="mb-3 flex flex-wrap gap-x-4 gap-y-1 text-sm">
                  <button type="button" onClick={() => setEditingFound(true)} className="text-indigo-600 hover:underline">
                    ¿Cambió tu teléfono o tus datos? Editar
                  </button>
                  <button type="button" onClick={resetLookup} className="text-indigo-600 hover:underline">
                    ¿No sos vos? Ingresar otro documento
                  </button>
                </div>
              </>
            )}

            {editingFound && (
              <div className="mb-3 space-y-3">
                <Field label="Nombre completo">
                  <Input value={fullName} onChange={(e) => setFullName(e.target.value)} required autoFocus />
                </Field>
                <Field label="Teléfono">
                  <PhoneInput value={phone} onChange={setPhone} />
                </Field>
                <button
                  type="button"
                  onClick={() => setEditingFound(false)}
                  className="text-sm text-indigo-600 hover:underline"
                >
                  Listo, no editar más
                </button>
              </div>
            )}

            <form onSubmit={handleReviewRequest}>
              <ErrorText>{error}</ErrorText>
              <Button type="submit" className="w-full">
                Continuar
              </Button>
            </form>
          </Card>
        )}

        {selectedSlot && lookupStatus === "not_found" && !showReview && (
          <Card>
            <h2 className="mb-3 text-sm font-semibold text-gray-900">Tus datos</h2>
            <p className="mb-3 text-xs text-gray-500">
              No encontramos ese documento, completá tus datos para reservar por primera vez.
            </p>
            <button type="button" onClick={resetLookup} className="mb-3 text-sm text-indigo-600 hover:underline">
              ¿Documento incorrecto? Volver a ingresarlo
            </button>
            <form onSubmit={handleReviewRequest} className="space-y-3">
              <Field label="Documento">
                <Input value={documentId} disabled className="bg-gray-100" />
              </Field>
              <Field label="Nombre completo">
                <Input value={fullName} onChange={(e) => setFullName(e.target.value)} required autoFocus />
              </Field>
              <Field label="Teléfono">
                <PhoneInput value={phone} onChange={setPhone} />
              </Field>
              <ErrorText>{error}</ErrorText>
              <Button type="submit" className="w-full">
                Continuar
              </Button>
            </form>
          </Card>
        )}

        {selectedSlot && showReview && (
          <Card>
            <h2 className="mb-1 text-sm font-semibold text-gray-900">Revisá antes de confirmar</h2>
            <p className="mb-3 text-xs text-gray-500">
              Un dato mal escrito (sobre todo el teléfono) hace que no te lleguen los avisos por WhatsApp. Fijate que
              esté todo bien.
            </p>
            <dl className="mb-4 space-y-2 rounded-lg border border-gray-200 p-3 text-sm">
              <div className="flex justify-between gap-3">
                <dt className="text-gray-500">Documento</dt>
                <dd className="font-medium text-gray-900">{documentId}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-gray-500">Nombre</dt>
                <dd className="font-medium text-gray-900">{fullName}</dd>
              </div>
              <div className="flex justify-between gap-3">
                <dt className="text-gray-500">Teléfono</dt>
                <dd className="font-medium text-gray-900">{phone}</dd>
              </div>
              <div className="flex justify-between gap-3 border-t border-gray-100 pt-2">
                <dt className="text-gray-500">Turno</dt>
                <dd className="font-medium text-gray-900">
                  {date} a las {selectedSlot}
                </dd>
              </div>
            </dl>
            <ErrorText>{error}</ErrorText>
            <div className="flex gap-2">
              <Button type="button" variant="secondary" className="flex-1" onClick={() => setShowReview(false)}>
                Corregir
              </Button>
              <Button type="button" className="flex-1" disabled={submitting} onClick={handleSubmit}>
                {submitting ? "Confirmando..." : "Sí, está todo bien"}
              </Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
