import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api, ApiError } from "../../lib/api";
import { Badge, Button, Card, Input } from "../../components/ui";

interface PublicAppointment {
  id: string;
  startAt: string;
  status: "PENDING" | "CONFIRMED" | "CANCELLED" | "DONE";
  professional: { name: string };
  service: { name: string };
}

const STATUS_LABEL: Record<string, string> = {
  PENDING: "Pendiente de confirmar",
  CONFIRMED: "Confirmado",
  CANCELLED: "Cancelado",
  DONE: "Realizado",
};
const STATUS_TONE: Record<string, "gray" | "green" | "red" | "yellow"> = {
  PENDING: "yellow",
  CONFIRMED: "green",
  CANCELLED: "red",
  DONE: "gray",
};

export default function MyAppointmentsPage() {
  const { slug } = useParams<{ slug: string }>();
  const [documentId, setDocumentId] = useState("");
  const [appointments, setAppointments] = useState<PublicAppointment[] | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const data = await api.get<PublicAppointment[]>(
        `/api/public/${slug}/mis-turnos?documentId=${encodeURIComponent(documentId)}`
      );
      setAppointments(data);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al buscar tus turnos");
    } finally {
      setLoading(false);
    }
  }

  async function handleCancel(id: string) {
    if (!window.confirm("¿Cancelar este turno?")) return;
    setBusyId(id);
    try {
      await api.post(`/api/public/${slug}/mis-turnos/${id}/cancel`, { documentId });
      setAppointments((prev) => prev?.map((a) => (a.id === id ? { ...a, status: "CANCELLED" } : a)) ?? null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al cancelar el turno");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 px-4 py-8">
      <div className="mx-auto max-w-xl">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-xl font-semibold text-gray-900">Mis turnos</h1>
          <Link to={`/reservar/${slug}`} className="text-sm text-indigo-600 hover:underline">
            Volver a reservar
          </Link>
        </div>

        <Card className="mb-4">
          <form onSubmit={handleSearch} className="flex gap-2">
            <Input
              placeholder="Tu número de documento"
              value={documentId}
              onChange={(e) => setDocumentId(e.target.value)}
              required
            />
            <Button type="submit" disabled={loading}>
              {loading ? "Buscando..." : "Buscar"}
            </Button>
          </form>
          {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
        </Card>

        {appointments && (
          <div className="space-y-3">
            {appointments.map((a) => (
              <Card key={a.id}>
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-medium text-gray-900">{new Date(a.startAt).toLocaleString("es-AR")}</p>
                    <p className="text-sm text-gray-600">
                      {a.service.name} con {a.professional.name}
                    </p>
                  </div>
                  <Badge tone={STATUS_TONE[a.status]}>{STATUS_LABEL[a.status]}</Badge>
                </div>
                {(a.status === "PENDING" || a.status === "CONFIRMED") && new Date(a.startAt) > new Date() && (
                  <Button
                    variant="danger"
                    className="mt-3"
                    disabled={busyId === a.id}
                    onClick={() => handleCancel(a.id)}
                  >
                    Cancelar turno
                  </Button>
                )}
              </Card>
            ))}
            {appointments.length === 0 && <p className="text-sm text-gray-500">No encontramos turnos con ese documento.</p>}
          </div>
        )}
      </div>
    </div>
  );
}
