import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api, ApiError } from "../../lib/api";
import { Button, Card, ErrorText, Input } from "../../components/ui";

interface TokenInfo {
  action: "CONFIRM" | "CANCEL" | "MODIFY";
  status: "PENDING" | "USED" | "EXPIRED";
  appointment: {
    startAt: string;
    status: string;
    professional: string;
    service: string;
    business: string;
    clientName: string;
  };
}

const ACTION_LABEL: Record<string, string> = {
  CONFIRM: "Confirmar turno",
  CANCEL: "Cancelar turno",
  MODIFY: "Reprogramar turno",
};

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export default function ActionPage() {
  const { token } = useParams<{ token: string }>();
  const [info, setInfo] = useState<TokenInfo | null | undefined>(undefined);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const [date, setDate] = useState(todayStr());
  const [slots, setSlots] = useState<string[]>([]);
  const [loadingSlots, setLoadingSlots] = useState(false);

  useEffect(() => {
    api
      .get<TokenInfo>(`/api/actions/${token}`)
      .then(setInfo)
      .catch(() => setInfo(null));
  }, [token]);

  useEffect(() => {
    if (!info || info.action !== "MODIFY" || info.status !== "PENDING") return;
    setLoadingSlots(true);
    api
      .get<{ slots: string[] }>(`/api/actions/${token}/availability?date=${date}`)
      .then((r) => setSlots(r.slots))
      .catch(() => setSlots([]))
      .finally(() => setLoadingSlots(false));
  }, [info, token, date]);

  async function handleConfirmOrCancel(action: "confirm" | "cancel") {
    setError("");
    setLoading(true);
    try {
      const res = await api.post<{ message: string }>(`/api/actions/${token}/${action}`);
      setResult(res.message);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "No se pudo procesar la acción");
    } finally {
      setLoading(false);
    }
  }

  async function handleModify(slot: string) {
    setError("");
    setLoading(true);
    try {
      const startAt = new Date(`${date}T${slot}:00`).toISOString();
      const res = await api.post<{ message: string }>(`/api/actions/${token}/modify`, { startAt });
      setResult(res.message);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "No se pudo reprogramar el turno");
    } finally {
      setLoading(false);
    }
  }

  if (info === undefined) {
    return <div className="flex min-h-screen items-center justify-center text-sm text-gray-500">Cargando...</div>;
  }

  if (info === null) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4">
        <Card className="w-full max-w-sm text-center">
          <p className="text-sm text-gray-500">Este link no es válido.</p>
        </Card>
      </div>
    );
  }

  if (result) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4">
        <Card className="w-full max-w-sm text-center">
          <p className="mb-2 text-2xl">✅</p>
          <p className="text-lg font-semibold text-gray-900">{result}</p>
        </Card>
      </div>
    );
  }

  const { appointment } = info;
  const isUsable = info.status === "PENDING" && appointment.status !== "CANCELLED";

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4 py-8">
      <Card className="w-full max-w-sm">
        <h1 className="mb-1 text-lg font-semibold text-gray-900">{ACTION_LABEL[info.action]}</h1>
        <p className="mb-4 text-sm text-gray-500">{appointment.business}</p>

        <div className="mb-4 rounded-lg bg-gray-50 p-3 text-sm text-gray-700">
          <p>
            <strong>{new Date(appointment.startAt).toLocaleString("es-AR")}</strong>
          </p>
          <p>
            {appointment.service} con {appointment.professional}
          </p>
          <p className="text-gray-500">{appointment.clientName}</p>
        </div>

        {!isUsable && (
          <p className="text-sm text-gray-500">
            Este link ya fue usado o ya no es válido{appointment.status === "CANCELLED" ? " (el turno está cancelado)" : ""}.
          </p>
        )}

        {isUsable && info.action === "CONFIRM" && (
          <Button className="w-full" disabled={loading} onClick={() => handleConfirmOrCancel("confirm")}>
            {loading ? "Confirmando..." : "Confirmar turno"}
          </Button>
        )}

        {isUsable && info.action === "CANCEL" && (
          <Button variant="danger" className="w-full" disabled={loading} onClick={() => handleConfirmOrCancel("cancel")}>
            {loading ? "Cancelando..." : "Cancelar turno"}
          </Button>
        )}

        {isUsable && info.action === "MODIFY" && (
          <div>
            <Input type="date" value={date} min={todayStr()} onChange={(e) => setDate(e.target.value)} className="mb-3" />
            {loadingSlots && <p className="text-sm text-gray-400">Buscando horarios...</p>}
            {!loadingSlots && slots.length === 0 && <p className="text-sm text-gray-400">No hay horarios libres ese día.</p>}
            <div className="flex flex-wrap gap-2">
              {slots.map((s) => (
                <button
                  key={s}
                  type="button"
                  disabled={loading}
                  onClick={() => handleModify(s)}
                  className="min-h-11 rounded-lg border border-gray-300 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        <ErrorText>{error}</ErrorText>
      </Card>
    </div>
  );
}
