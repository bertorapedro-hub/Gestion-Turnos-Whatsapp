import { useState } from "react";
import { api, ApiError } from "../lib/api";
import { Button, Card, ErrorText, Field, Input } from "../components/ui";

export default function ChangePassword() {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSuccess(false);
    if (newPassword !== confirmPassword) {
      setError("Las contraseñas nuevas no coinciden");
      return;
    }
    setLoading(true);
    try {
      await api.post("/api/auth/change-password", { currentPassword, newPassword });
      setSuccess(true);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al cambiar la contraseña");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card className="max-w-md">
      <h2 className="mb-4 text-base font-semibold text-gray-900">Cambiar contraseña</h2>
      <form onSubmit={handleSubmit} className="space-y-3">
        <Field label="Contraseña actual">
          <Input type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required />
        </Field>
        <Field label="Nueva contraseña">
          <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required minLength={6} />
        </Field>
        <Field label="Confirmar nueva contraseña">
          <Input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required minLength={6} />
        </Field>
        <ErrorText>{error}</ErrorText>
        {success && <p className="mt-2 text-sm text-green-600">Contraseña actualizada correctamente.</p>}
        <Button type="submit" disabled={loading}>
          {loading ? "Guardando..." : "Actualizar contraseña"}
        </Button>
      </form>
    </Card>
  );
}
