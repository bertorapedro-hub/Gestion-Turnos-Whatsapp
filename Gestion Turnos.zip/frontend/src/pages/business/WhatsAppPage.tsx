import { useEffect, useRef, useState } from "react";
import { api, ApiError } from "../../lib/api";
import { Badge, Button, Card, ErrorText, Field, Input } from "../../components/ui";
import { PhoneInput } from "../../components/PhoneInput";
import { PHONE_HINT, isValidPhone } from "../../lib/validation";

interface Status {
  status: "DISCONNECTED" | "CONNECTING" | "CONNECTED";
  phoneNumber: string | null;
}

interface Settings {
  contactPhone: string | null;
  bookingConfirmationMode: "CLIENT_SELF" | "PROFESSIONAL_APPROVAL";
  reminderDaysBefore: number;
  reminderHoursBefore: number;
  unconfirmedFollowupHours: number;
  autoCancelHoursBefore: number;
  dailySummaryTime: string;
}

const STATUS_LABEL: Record<string, string> = {
  DISCONNECTED: "Desconectado",
  CONNECTING: "Conectando...",
  CONNECTED: "Conectado",
};
const STATUS_TONE: Record<string, "gray" | "green" | "yellow"> = {
  DISCONNECTED: "gray",
  CONNECTING: "yellow",
  CONNECTED: "green",
};

function ConnectionCard() {
  const [status, setStatus] = useState<Status | null>(null);
  const [qr, setQr] = useState<string | null>(null);
  const [error, setError] = useState("");
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  async function loadStatus() {
    try {
      const s = await api.get<Status>("/api/business/whatsapp/status");
      setStatus(s);
      if (s.status === "CONNECTED") setQr(null);
      return s;
    } catch {
      return null;
    }
  }

  useEffect(() => {
    loadStatus();
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []);

  function startPolling() {
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(async () => {
      const s = await loadStatus();
      if (s?.status === "CONNECTED" && pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
        return;
      }
      try {
        const { qr: currentQr } = await api.get<{ qr: string | null }>("/api/business/whatsapp/qr");
        if (currentQr) setQr(currentQr);
      } catch {
        // ignore
      }
    }, 2500);
  }

  async function handleConnect() {
    setError("");
    try {
      await api.post("/api/business/whatsapp/connect");
      startPolling();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al iniciar la vinculación");
    }
  }

  async function handleDisconnect() {
    if (!window.confirm("¿Desvincular WhatsApp de este negocio? Dejarán de enviarse los mensajes automáticos.")) return;
    setError("");
    try {
      await api.post("/api/business/whatsapp/disconnect");
      setQr(null);
      loadStatus();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al desvincular");
    }
  }

  return (
    <Card>
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-sm font-semibold text-gray-900">Conexión de WhatsApp</h2>
        {status && <Badge tone={STATUS_TONE[status.status]}>{STATUS_LABEL[status.status]}</Badge>}
      </div>

      {status?.status === "CONNECTED" && (
        <div>
          <p className="text-sm text-gray-600">Número vinculado: {status.phoneNumber}</p>
          <Button variant="danger" className="mt-3" onClick={handleDisconnect}>
            Desvincular
          </Button>
        </div>
      )}

      {status?.status !== "CONNECTED" && (
        <div>
          <p className="mb-3 text-sm text-gray-500">
            Vinculá el WhatsApp del negocio escaneando el código QR desde tu teléfono (WhatsApp {'>'} Dispositivos vinculados).
          </p>
          {qr ? (
            <img src={qr} alt="Código QR de WhatsApp" className="h-56 w-56 rounded-lg border border-gray-200" />
          ) : (
            <Button onClick={handleConnect}>Vincular WhatsApp</Button>
          )}
        </div>
      )}
      <ErrorText>{error}</ErrorText>
    </Card>
  );
}

function SettingsCard() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [phoneConfirmed, setPhoneConfirmed] = useState(true);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get<Settings>("/api/business/settings").then(setSettings).catch(() => {});
  }, []);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!settings) return;
    setError("");
    setSaved(false);
    if (settings.contactPhone?.trim()) {
      if (!isValidPhone(settings.contactPhone)) {
        setError(`Revisá el teléfono, no parece completo. ${PHONE_HINT}`);
        return;
      }
      if (!phoneConfirmed) {
        setError("Confirmá que el teléfono está bien escrito antes de guardar");
        return;
      }
    }
    setSaving(true);
    try {
      const updated = await api.put<Settings>("/api/business/settings", settings);
      setSettings(updated);
      setSaved(true);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al guardar la configuración");
    } finally {
      setSaving(false);
    }
  }

  if (!settings) return null;

  return (
    <Card className="mt-4">
      <h2 className="mb-3 text-sm font-semibold text-gray-900">Automatizaciones</h2>
      <form onSubmit={handleSave} className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <Field label="Teléfono de contacto (opcional)">
            <PhoneInput
              value={settings.contactPhone ?? ""}
              onChange={(v) => {
                setSettings({ ...settings, contactPhone: v });
                setPhoneConfirmed(false);
              }}
            />
          </Field>
          {settings.contactPhone?.trim() && (
            <div className="mt-2 rounded-lg bg-amber-50 p-3">
              <label className="flex items-center gap-2 text-sm text-amber-900">
                <input type="checkbox" checked={phoneConfirmed} onChange={(e) => setPhoneConfirmed(e.target.checked)} />
                Confirmo que el teléfono está bien escrito
              </label>
            </div>
          )}
        </div>
        <div className="sm:col-span-2">
          <label className="mb-1 block text-sm font-medium text-gray-700">
            Cuando un cliente reserva un turno nuevo por la web
          </label>
          <select
            value={settings.bookingConfirmationMode}
            onChange={(e) =>
              setSettings({ ...settings, bookingConfirmationMode: e.target.value as Settings["bookingConfirmationMode"] })
            }
            className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
          >
            <option value="CLIENT_SELF">Pedir el turno ya lo confirma (el cliente cancela o modifica si quiere)</option>
            <option value="PROFESSIONAL_APPROVAL">El profesional aprueba cada turno antes de confirmarlo</option>
          </select>
          {settings.bookingConfirmationMode === "PROFESSIONAL_APPROVAL" && (
            <p className="mt-1 text-xs text-gray-500">
              Cada profesional necesita tener su teléfono cargado (Profesionales → editar) para poder recibir estos
              pedidos.
            </p>
          )}
        </div>
        <Field label="¿Cuántos días antes del turno?">
          <Input
            type="number"
            min={0}
            max={30}
            value={settings.reminderDaysBefore}
            onChange={(e) => setSettings({ ...settings, reminderDaysBefore: Number(e.target.value) })}
          />
        </Field>
        <Field label="¿Y cuántas horas antes?">
          <Input
            type="number"
            min={0}
            max={72}
            value={settings.reminderHoursBefore}
            onChange={(e) => setSettings({ ...settings, reminderHoursBefore: Number(e.target.value) })}
          />
        </Field>
        {settings.bookingConfirmationMode === "PROFESSIONAL_APPROVAL" && (
          <>
            <Field label="Si el profesional no responde, avisarle de nuevo después de (horas)">
              <Input
                type="number"
                min={1}
                max={72}
                value={settings.unconfirmedFollowupHours}
                onChange={(e) => setSettings({ ...settings, unconfirmedFollowupHours: Number(e.target.value) })}
              />
            </Field>
            <div className="sm:col-span-2">
              <label className="mb-1 flex items-center gap-2 text-sm font-medium text-gray-700">
                <input
                  type="checkbox"
                  checked={settings.autoCancelHoursBefore > 0}
                  onChange={(e) => setSettings({ ...settings, autoCancelHoursBefore: e.target.checked ? 24 : 0 })}
                />
                Cancelar automáticamente si el profesional nunca responde
              </label>
              {settings.autoCancelHoursBefore > 0 && (
                <Field label="Cancelar con esta anticipación al turno (horas)">
                  <Input
                    type="number"
                    min={1}
                    max={72}
                    value={settings.autoCancelHoursBefore}
                    onChange={(e) => setSettings({ ...settings, autoCancelHoursBefore: Number(e.target.value) })}
                  />
                </Field>
              )}
            </div>
          </>
        )}
        {settings.bookingConfirmationMode === "CLIENT_SELF" && (
          <p className="sm:col-span-2 text-xs text-gray-500">
            En este modo, pedir el turno ya lo confirma — el cliente solo puede cancelarlo o modificarlo, no hace
            falta que confirme nada aparte.
          </p>
        )}
        <Field label="Hora del resumen diario a profesionales">
          <Input
            type="time"
            value={settings.dailySummaryTime}
            onChange={(e) => setSettings({ ...settings, dailySummaryTime: e.target.value })}
          />
        </Field>
        <div className="sm:col-span-2">
          <ErrorText>{error}</ErrorText>
          {saved && <p className="mb-2 text-sm text-green-600">Configuración guardada.</p>}
          <Button type="submit" disabled={saving}>
            {saving ? "Guardando..." : "Guardar configuración"}
          </Button>
        </div>
      </form>
    </Card>
  );
}

export default function WhatsAppPage() {
  return (
    <div>
      <h1 className="mb-4 text-lg font-semibold text-gray-900">WhatsApp</h1>
      <ConnectionCard />
      <SettingsCard />
    </div>
  );
}
