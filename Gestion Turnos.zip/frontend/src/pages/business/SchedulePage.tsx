import { useEffect, useState } from "react";
import { api, ApiError } from "../../lib/api";
import { useAuth } from "../../context/AuthContext";
import { Button, Card, ErrorText, Input } from "../../components/ui";
import { WEEKDAY_NAMES, type Professional, type WeeklyScheduleEntry } from "../../types";

interface Range {
  startTime: string;
  endTime: string;
}

function groupByDay(entries: WeeklyScheduleEntry[]): Record<number, Range[]> {
  const grouped: Record<number, Range[]> = {};
  for (const e of entries) {
    grouped[e.weekday] = [...(grouped[e.weekday] ?? []), { startTime: e.startTime, endTime: e.endTime }];
  }
  return grouped;
}

export default function SchedulePage() {
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [selected, setSelected] = useState(""); // "" = horario general del negocio
  const [byDay, setByDay] = useState<Record<number, Range[]>>({});
  const [isCustom, setIsCustom] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { user } = useAuth();
  const isSingleMode = user?.professionalMode === "SINGLE";

  useEffect(() => {
    api.get<Professional[]>("/api/business/professionals").then(setProfessionals).catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    setSuccess(false);
    const query = selected ? `?professionalId=${selected}` : "";
    api
      .get<WeeklyScheduleEntry[]>(`/api/business/schedule/weekly${query}`)
      .then((entries) => {
        setByDay(groupByDay(entries));
        setIsCustom(entries.length > 0);
      })
      .catch((err) => setError(err instanceof ApiError ? err.message : "Error al cargar horarios"))
      .finally(() => setLoading(false));
  }, [selected]);

  function addRange(day: number) {
    setByDay((prev) => ({ ...prev, [day]: [...(prev[day] ?? []), { startTime: "09:00", endTime: "18:00" }] }));
    setIsCustom(true);
  }

  function removeRange(day: number, idx: number) {
    setByDay((prev) => ({ ...prev, [day]: (prev[day] ?? []).filter((_, i) => i !== idx) }));
  }

  function updateRange(day: number, idx: number, field: keyof Range, value: string) {
    setByDay((prev) => ({
      ...prev,
      [day]: (prev[day] ?? []).map((r, i) => (i === idx ? { ...r, [field]: value } : r)),
    }));
  }

  async function loadGeneralAsBase() {
    try {
      const entries = await api.get<WeeklyScheduleEntry[]>("/api/business/schedule/weekly");
      setByDay(groupByDay(entries));
      setIsCustom(true);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al copiar el horario general");
    }
  }

  async function handleSave() {
    setError("");
    setSuccess(false);
    setSaving(true);
    const entries = Object.entries(byDay).flatMap(([weekday, ranges]) =>
      ranges.map((r) => ({ weekday: Number(weekday), startTime: r.startTime, endTime: r.endTime }))
    );
    const query = selected ? `?professionalId=${selected}` : "";
    try {
      await api.put(`/api/business/schedule/weekly${query}`, entries);
      setSuccess(true);
      setIsCustom(entries.length > 0);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al guardar los horarios");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h1 className="mb-4 text-lg font-semibold text-gray-900">Horarios de atención</h1>

      {!isSingleMode && (
        <Card className="mb-4">
          <label className="mb-1 block text-sm font-medium text-gray-700">Editando el horario de</label>
          <select
            value={selected}
            onChange={(e) => setSelected(e.target.value)}
            className="w-full max-w-xs rounded-lg border border-gray-300 px-3 py-2 text-sm"
          >
            <option value="">General del negocio</option>
            {professionals.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
          {selected && (
            <p className="mt-2 text-xs text-gray-500">
              {isCustom
                ? "Este profesional tiene un horario propio. Los días que dejes sin franjas quedan cerrados para él/ella, aunque el negocio esté abierto."
                : "Este profesional todavía no tiene horario propio: se usa el horario general del negocio. Agregá una franja para empezar a personalizarlo."}
              {!isCustom && (
                <Button variant="secondary" className="ml-2" onClick={loadGeneralAsBase}>
                  Copiar horario general como base
                </Button>
              )}
            </p>
          )}
        </Card>
      )}

      {loading ? (
        <p className="text-sm text-gray-500">Cargando...</p>
      ) : (
        <div className="space-y-3">
          {WEEKDAY_NAMES.map((name, day) => (
            <Card key={day}>
              <div className="flex items-center justify-between">
                <p className="font-medium text-gray-900">{name}</p>
                <Button variant="secondary" onClick={() => addRange(day)}>
                  + Agregar horario
                </Button>
              </div>
              {(byDay[day] ?? []).length === 0 && <p className="mt-2 text-sm text-gray-400">Cerrado</p>}
              <div className="mt-2 space-y-2">
                {(byDay[day] ?? []).map((r, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <Input
                      type="time"
                      value={r.startTime}
                      onChange={(e) => updateRange(day, idx, "startTime", e.target.value)}
                      className="w-32"
                    />
                    <span className="text-sm text-gray-500">a</span>
                    <Input
                      type="time"
                      value={r.endTime}
                      onChange={(e) => updateRange(day, idx, "endTime", e.target.value)}
                      className="w-32"
                    />
                    <Button variant="ghost" onClick={() => removeRange(day, idx)}>
                      Quitar
                    </Button>
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>
      )}
      <ErrorText>{error}</ErrorText>
      {success && <p className="mt-2 text-sm text-green-600">Horarios guardados.</p>}
      <Button className="mt-4" onClick={handleSave} disabled={saving || loading}>
        {saving ? "Guardando..." : "Guardar horarios"}
      </Button>
    </div>
  );
}
