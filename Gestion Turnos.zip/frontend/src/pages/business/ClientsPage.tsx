import { useEffect, useState } from "react";
import { api, ApiError } from "../../lib/api";
import { Badge, Button, Card, ErrorText, Field, Input } from "../../components/ui";
import { PhoneInput } from "../../components/PhoneInput";
import { PHONE_HINT, isValidPhone } from "../../lib/validation";
import type { Appointment, Client } from "../../types";

function ClientFormModal({
  client,
  onClose,
  onSaved,
}: {
  client: Client | null;
  onClose: () => void;
  onSaved: (c: Client) => void;
}) {
  const [fullName, setFullName] = useState(client?.fullName ?? "");
  const [documentId, setDocumentId] = useState(client?.documentId ?? "");
  const [phone, setPhone] = useState(client?.phone ?? "");
  const [phoneConfirmed, setPhoneConfirmed] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!isValidPhone(phone)) {
      setError(`Revisá el teléfono, no parece completo. ${PHONE_HINT}`);
      return;
    }
    if (!phoneConfirmed) {
      setError("Confirmá que el teléfono está bien escrito antes de guardar");
      return;
    }
    setLoading(true);
    try {
      const payload = { fullName, documentId, phone };
      const saved = client
        ? await api.put<Client>(`/api/business/clients/${client.id}`, payload)
        : await api.post<Client>("/api/business/clients", payload);
      onSaved(saved);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al guardar el cliente");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
      <div className="w-full max-w-md rounded-xl bg-white p-6 shadow-lg">
        <h2 className="mb-4 text-lg font-semibold text-gray-900">{client ? "Editar cliente" : "Nuevo cliente"}</h2>
        <form onSubmit={handleSubmit} className="space-y-3">
          <Field label="Nombre completo">
            <Input value={fullName} onChange={(e) => setFullName(e.target.value)} required autoFocus />
          </Field>
          <Field label="Documento">
            <Input value={documentId} onChange={(e) => setDocumentId(e.target.value)} required />
          </Field>
          <Field label="Teléfono">
            <PhoneInput
              value={phone}
              onChange={(v) => {
                setPhone(v);
                setPhoneConfirmed(false);
              }}
            />
          </Field>
          {phone.trim() && (
            <div className="rounded-lg bg-amber-50 p-3">
              <label className="flex items-center gap-2 text-sm text-amber-900">
                <input type="checkbox" checked={phoneConfirmed} onChange={(e) => setPhoneConfirmed(e.target.checked)} />
                Confirmo que el teléfono está bien escrito
              </label>
            </div>
          )}
          <ErrorText>{error}</ErrorText>
          <div className="mt-4 flex justify-end gap-2">
            <Button type="button" variant="secondary" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Guardando..." : "Guardar"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function ClientsPage() {
  const [query, setQuery] = useState("");
  const [clients, setClients] = useState<Client[]>([]);
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Client | null>(null);
  const [history, setHistory] = useState<{ client: Client; appointments: Appointment[] } | null>(null);

  async function search() {
    try {
      const data = await api.get<Client[]>(`/api/business/clients?q=${encodeURIComponent(query)}`);
      setClients(data);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al buscar clientes");
    }
  }

  useEffect(() => {
    search();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function viewHistory(c: Client) {
    try {
      const full = await api.get<Client & { appointments: Appointment[] }>(`/api/business/clients/${c.id}`);
      setHistory({ client: full, appointments: full.appointments });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al cargar el historial");
    }
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-lg font-semibold text-gray-900">Clientes</h1>
        <Button
          onClick={() => {
            setEditing(null);
            setModalOpen(true);
          }}
        >
          + Nuevo cliente
        </Button>
      </div>

      <div className="mb-4 flex gap-2">
        <Input
          placeholder="Buscar por documento, nombre o teléfono"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && search()}
        />
        <Button variant="secondary" onClick={search}>
          Buscar
        </Button>
      </div>

      {error && <p className="mb-3 text-sm text-red-600">{error}</p>}

      <Card className="overflow-x-auto p-0">
        <table className="w-full min-w-[600px] text-left text-sm">
          <thead className="border-b border-gray-200 bg-gray-50 text-xs uppercase text-gray-500">
            <tr>
              <th className="px-4 py-3">Nombre</th>
              <th className="px-4 py-3">Documento</th>
              <th className="px-4 py-3">Teléfono</th>
              <th className="px-4 py-3 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {clients.map((c) => (
              <tr key={c.id} className="border-b border-gray-100 last:border-0">
                <td className="px-4 py-3 font-medium text-gray-900">{c.fullName}</td>
                <td className="px-4 py-3 text-gray-600">{c.documentId}</td>
                <td className="px-4 py-3 text-gray-600">{c.phone}</td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    <Button variant="secondary" onClick={() => viewHistory(c)}>
                      Historial
                    </Button>
                    <Button
                      variant="secondary"
                      onClick={() => {
                        setEditing(c);
                        setModalOpen(true);
                      }}
                    >
                      Editar
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {clients.length === 0 && (
              <tr>
                <td colSpan={4} className="px-4 py-8 text-center text-gray-500">
                  No se encontraron clientes.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Card>

      {modalOpen && (
        <ClientFormModal
          client={editing}
          onClose={() => setModalOpen(false)}
          onSaved={(c) => {
            setClients((prev) => {
              const exists = prev.some((x) => x.id === c.id);
              return exists ? prev.map((x) => (x.id === c.id ? c : x)) : [c, ...prev];
            });
            setModalOpen(false);
          }}
        />
      )}

      {history && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
          <div className="max-h-[80vh] w-full max-w-lg overflow-y-auto rounded-xl bg-white p-6 shadow-lg">
            <h2 className="mb-1 text-lg font-semibold text-gray-900">{history.client.fullName}</h2>
            <p className="mb-4 text-sm text-gray-500">Historial de turnos</p>
            <ul className="space-y-2">
              {history.appointments.map((a) => (
                <li key={a.id} className="rounded-lg border border-gray-200 p-3 text-sm">
                  <div className="flex items-center justify-between">
                    <p className="font-medium text-gray-900">
                      {new Date(a.startAt).toLocaleString("es-AR")}
                    </p>
                    <Badge tone={a.status === "CANCELLED" ? "red" : a.status === "CONFIRMED" ? "green" : "yellow"}>
                      {a.status}
                    </Badge>
                  </div>
                  <p className="text-gray-600">
                    {a.service.name} con {a.professional.name}
                  </p>
                </li>
              ))}
              {history.appointments.length === 0 && <p className="text-sm text-gray-500">Sin turnos registrados.</p>}
            </ul>
            <Button variant="secondary" className="mt-4" onClick={() => setHistory(null)}>
              Cerrar
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
