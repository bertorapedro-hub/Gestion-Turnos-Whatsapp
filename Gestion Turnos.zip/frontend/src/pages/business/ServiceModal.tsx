import { useEffect, useState } from "react";
import { api, ApiError } from "../../lib/api";
import { useAuth } from "../../context/AuthContext";
import { Button, ErrorText, Field, Input, Label } from "../../components/ui";
import type { Professional, Service } from "../../types";

export default function ServiceModal({
  service,
  onClose,
  onSaved,
}: {
  service: Service | null;
  onClose: () => void;
  onSaved: (s: Service) => void;
}) {
  const [name, setName] = useState(service?.name ?? "");
  const [durationMin, setDurationMin] = useState(String(service?.durationMin ?? 30));
  const [price, setPrice] = useState(String(service?.price ?? ""));
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [selected, setSelected] = useState<Set<string>>(
    new Set(service?.professionals?.map((sp) => sp.professional.id) ?? [])
  );
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const isSingleMode = user?.professionalMode === "SINGLE";

  useEffect(() => {
    api
      .get<Professional[]>("/api/business/professionals")
      .then((list) => {
        setProfessionals(list);
        if (isSingleMode && list.length === 1) {
          setSelected(new Set([list[0].id]));
        }
      })
      .catch(() => setProfessionals([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSingleMode]);

  function toggle(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const payload = { name, durationMin, price, professionalIds: Array.from(selected) };
      const saved = service
        ? await api.put<Service>(`/api/business/services/${service.id}`, payload)
        : await api.post<Service>("/api/business/services", payload);
      onSaved(saved);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al guardar el servicio");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
      <div className="w-full max-w-md rounded-xl bg-white p-6 shadow-lg">
        <h2 className="mb-4 text-lg font-semibold text-gray-900">{service ? "Editar servicio" : "Nuevo servicio"}</h2>
        <form onSubmit={handleSubmit} className="space-y-3">
          <Field label="Nombre">
            <Input value={name} onChange={(e) => setName(e.target.value)} required autoFocus />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Duración (minutos)">
              <Input type="number" min={5} step={5} value={durationMin} onChange={(e) => setDurationMin(e.target.value)} required />
            </Field>
            <Field label="Precio">
              <Input type="number" min={0} step="0.01" value={price} onChange={(e) => setPrice(e.target.value)} required />
            </Field>
          </div>
          {!isSingleMode && (
            <div>
              <Label>Profesionales que lo realizan</Label>
              <div className="max-h-40 space-y-1 overflow-y-auto rounded-lg border border-gray-200 p-2">
                {professionals.map((p) => (
                  <label key={p.id} className="flex items-center gap-2 text-sm text-gray-700">
                    <input type="checkbox" checked={selected.has(p.id)} onChange={() => toggle(p.id)} />
                    {p.name}
                  </label>
                ))}
                {professionals.length === 0 && <p className="text-xs text-gray-400">No hay profesionales cargados todavía.</p>}
              </div>
            </div>
          )}
          <ErrorText>{error}</ErrorText>
          <div className="mt-4 flex justify-end gap-2">
            <Button type="button" variant="secondary" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Guardando..." : "Guardar"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
