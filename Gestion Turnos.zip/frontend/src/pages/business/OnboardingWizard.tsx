import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, ApiError } from "../../lib/api";
import { useAuth } from "../../context/AuthContext";
import { Button, Card, ErrorText, Field, Input, Label } from "../../components/ui";
import { PhoneInput } from "../../components/PhoneInput";
import { PHONE_HINT, isValidPhone } from "../../lib/validation";

const TOTAL_STEPS = 5;

export default function OnboardingWizard() {
  const { user, refresh } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const [professionalMode, setProfessionalMode] = useState<"SINGLE" | "MULTI" | "">("");
  const [soleName, setSoleName] = useState(user?.businessName ?? "");
  const [solePhone, setSolePhone] = useState("");
  const [solePhoneConfirmed, setSolePhoneConfirmed] = useState(false);
  const [soleSpecialty, setSoleSpecialty] = useState("");

  const [bookingConfirmationMode, setBookingConfirmationMode] = useState<"CLIENT_SELF" | "PROFESSIONAL_APPROVAL">(
    "CLIENT_SELF"
  );

  const [reminderDaysBefore, setReminderDaysBefore] = useState(1);
  const [reminderHoursBefore, setReminderHoursBefore] = useState(2);
  const [unconfirmedFollowupHours, setUnconfirmedFollowupHours] = useState(3);

  const [autoCancelEnabled, setAutoCancelEnabled] = useState(false);
  const [autoCancelHoursBefore, setAutoCancelHoursBefore] = useState(24);

  const [dailySummaryTime, setDailySummaryTime] = useState("08:00");

  function canAdvance(): boolean {
    if (step === 0) {
      if (professionalMode === "") return false;
      if (professionalMode === "SINGLE") {
        if (soleName.trim() === "") return false;
        if (solePhone.trim() && (!isValidPhone(solePhone) || !solePhoneConfirmed)) return false;
      }
      return true;
    }
    if (step === 1) {
      if (
        bookingConfirmationMode === "PROFESSIONAL_APPROVAL" &&
        professionalMode === "SINGLE" &&
        !solePhone.trim()
      ) {
        return false;
      }
      return true;
    }
    return true;
  }

  function next() {
    setError("");
    if (!canAdvance()) {
      if (step === 0 && solePhone.trim() && !isValidPhone(solePhone)) {
        setError(`Revisá el teléfono, no parece completo. ${PHONE_HINT}`);
      } else if (step === 0 && solePhone.trim() && !solePhoneConfirmed) {
        setError("Confirmá que el teléfono está bien escrito antes de seguir");
      } else if (step === 1) {
        setError("Necesitamos tu teléfono para poder preguntarte por WhatsApp — volvé al paso anterior y cargalo");
      } else {
        setError("Completá este paso antes de seguir");
      }
      return;
    }
    setStep((s) => Math.min(s + 1, TOTAL_STEPS - 1));
  }

  function back() {
    setError("");
    setStep((s) => Math.max(s - 1, 0));
  }

  async function handleFinish() {
    setError("");
    setSubmitting(true);
    try {
      await api.post("/api/business/onboarding/complete", {
        professionalMode,
        soleProfessional:
          professionalMode === "SINGLE" ? { name: soleName, phone: solePhone, specialty: soleSpecialty } : undefined,
        bookingConfirmationMode,
        reminderDaysBefore,
        reminderHoursBefore,
        unconfirmedFollowupHours,
        autoCancelEnabled,
        autoCancelHoursBefore: autoCancelEnabled ? autoCancelHoursBefore : undefined,
        dailySummaryTime,
      });
      await refresh();
      navigate("/admin");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al guardar la configuración");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4 py-8">
      <Card className="w-full max-w-lg">
        <div className="mb-5">
          <p className="text-xs font-medium uppercase tracking-wide text-indigo-600">
            Paso {step + 1} de {TOTAL_STEPS}
          </p>
          <h1 className="text-lg font-semibold text-gray-900">Bienvenido a {user?.businessName}</h1>
        </div>

        {step === 0 && (
          <div className="space-y-4">
            <p className="text-sm text-gray-600">¿Cómo trabaja tu negocio?</p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => setProfessionalMode("SINGLE")}
                className={`rounded-lg border p-4 text-left ${
                  professionalMode === "SINGLE" ? "border-indigo-600 bg-indigo-50" : "border-gray-200 hover:bg-gray-50"
                }`}
              >
                <p className="font-medium text-gray-900">Un solo profesional</p>
                <p className="text-xs text-gray-500">Sos vos el que atiende todos los turnos</p>
              </button>
              <button
                type="button"
                onClick={() => setProfessionalMode("MULTI")}
                className={`rounded-lg border p-4 text-left ${
                  professionalMode === "MULTI" ? "border-indigo-600 bg-indigo-50" : "border-gray-200 hover:bg-gray-50"
                }`}
              >
                <p className="font-medium text-gray-900">Varios profesionales</p>
                <p className="text-xs text-gray-500">Tu negocio tiene un equipo</p>
              </button>
            </div>

            {professionalMode === "SINGLE" && (
              <div className="space-y-3 rounded-lg border border-gray-200 p-3">
                <Field label="Tu nombre (o el del profesional)">
                  <Input value={soleName} onChange={(e) => setSoleName(e.target.value)} required />
                </Field>
                <Field label="Teléfono (opcional, para recibir el resumen diario y los pedidos de aprobación)">
                  <PhoneInput
                    value={solePhone}
                    onChange={(v) => {
                      setSolePhone(v);
                      setSolePhoneConfirmed(false);
                    }}
                  />
                </Field>
                {solePhone.trim() && (
                  <div className="rounded-lg bg-amber-50 p-3">
                    <label className="flex items-center gap-2 text-sm text-amber-900">
                      <input
                        type="checkbox"
                        checked={solePhoneConfirmed}
                        onChange={(e) => setSolePhoneConfirmed(e.target.checked)}
                      />
                      Confirmo que el teléfono está bien escrito
                    </label>
                  </div>
                )}
                <Field label="Especialidad (opcional)">
                  <Input value={soleSpecialty} onChange={(e) => setSoleSpecialty(e.target.value)} />
                </Field>
              </div>
            )}

            {professionalMode === "MULTI" && (
              <p className="text-xs text-gray-500">
                Después de este asistente vas a poder cargar a cada profesional desde "Profesionales" en el menú.
              </p>
            )}
          </div>
        )}

        {step === 1 && (
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              Cuando un cliente reserva un turno nuevo desde la página web, ¿cómo querés que quede confirmado?
            </p>
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => setBookingConfirmationMode("CLIENT_SELF")}
                className={`w-full rounded-lg border p-3 text-left ${
                  bookingConfirmationMode === "CLIENT_SELF" ? "border-indigo-600 bg-indigo-50" : "border-gray-200 hover:bg-gray-50"
                }`}
              >
                <p className="font-medium text-gray-900">Pedir el turno ya lo confirma</p>
                <p className="text-xs text-gray-500">
                  Apenas reserva queda confirmado, sin pasos extra. Puede cancelarlo o modificarlo cuando quiera con
                  los links que le mandamos.
                </p>
              </button>
              <button
                type="button"
                onClick={() => setBookingConfirmationMode("PROFESSIONAL_APPROVAL")}
                className={`w-full rounded-lg border p-3 text-left ${
                  bookingConfirmationMode === "PROFESSIONAL_APPROVAL"
                    ? "border-indigo-600 bg-indigo-50"
                    : "border-gray-200 hover:bg-gray-50"
                }`}
              >
                <p className="font-medium text-gray-900">
                  {professionalMode === "SINGLE" ? "Yo apruebo cada turno" : "El profesional aprueba cada turno"}
                </p>
                <p className="text-xs text-gray-500">
                  {professionalMode === "SINGLE"
                    ? "Te preguntamos por WhatsApp si podés antes de confirmarlo. El cliente se entera apenas respondas."
                    : "Le preguntamos al profesional correspondiente si puede antes de confirmarlo. El cliente se entera apenas responda."}
                </p>
              </button>
            </div>
            {bookingConfirmationMode === "PROFESSIONAL_APPROVAL" && professionalMode === "SINGLE" && !solePhone.trim() && (
              <p className="text-xs text-amber-600">
                Todavía no cargaste tu teléfono en el paso anterior — lo necesitamos para poder preguntarte por WhatsApp.
              </p>
            )}
            {bookingConfirmationMode === "PROFESSIONAL_APPROVAL" && professionalMode === "MULTI" && (
              <p className="text-xs text-gray-500">
                Para que esto funcione, cada profesional va a necesitar tener su teléfono cargado (Profesionales → editar).
              </p>
            )}
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              ¿Cuándo querés que se le manden los recordatorios automáticos a tus clientes por WhatsApp?
            </p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Field label="¿Cuántos días antes del turno?">
                <Input
                  type="number"
                  min={0}
                  max={30}
                  value={reminderDaysBefore}
                  onChange={(e) => setReminderDaysBefore(Number(e.target.value))}
                />
              </Field>
              <Field label="¿Y cuántas horas antes?">
                <Input
                  type="number"
                  min={0}
                  max={72}
                  value={reminderHoursBefore}
                  onChange={(e) => setReminderHoursBefore(Number(e.target.value))}
                />
              </Field>
            </div>
            {bookingConfirmationMode === "PROFESSIONAL_APPROVAL" && (
              <Field label="Si el profesional no responde, avisarle de nuevo después de (horas)">
                <Input
                  type="number"
                  min={1}
                  max={72}
                  value={unconfirmedFollowupHours}
                  onChange={(e) => setUnconfirmedFollowupHours(Number(e.target.value))}
                />
              </Field>
            )}
          </div>
        )}

        {step === 3 && bookingConfirmationMode === "PROFESSIONAL_APPROVAL" && (
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              Si {professionalMode === "SINGLE" ? "no llegás a responder" : "el profesional no llega a responder"} un
              pedido de turno a tiempo, ¿qué querés que pase?
            </p>
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => setAutoCancelEnabled(false)}
                className={`w-full rounded-lg border p-3 text-left ${
                  !autoCancelEnabled ? "border-indigo-600 bg-indigo-50" : "border-gray-200 hover:bg-gray-50"
                }`}
              >
                <p className="font-medium text-gray-900">Dejarlo pendiente</p>
                <p className="text-xs text-gray-500">No se cancela solo, vos decidís qué hacer desde el panel</p>
              </button>
              <button
                type="button"
                onClick={() => setAutoCancelEnabled(true)}
                className={`w-full rounded-lg border p-3 text-left ${
                  autoCancelEnabled ? "border-indigo-600 bg-indigo-50" : "border-gray-200 hover:bg-gray-50"
                }`}
              >
                <p className="font-medium text-gray-900">Cancelarlo automáticamente</p>
                <p className="text-xs text-gray-500">Libera el horario para que otro cliente lo pueda reservar</p>
              </button>
            </div>
            {autoCancelEnabled && (
              <Field label="Cancelar automáticamente si sigue sin confirmar, con esta anticipación al turno (horas)">
                <Input
                  type="number"
                  min={1}
                  max={72}
                  value={autoCancelHoursBefore}
                  onChange={(e) => setAutoCancelHoursBefore(Number(e.target.value))}
                />
              </Field>
            )}
          </div>
        )}

        {step === 3 && bookingConfirmationMode === "CLIENT_SELF" && (
          <div className="space-y-3">
            <p className="text-sm text-gray-600">
              En el modo que elegiste, pedir el turno ya lo confirma — el cliente solo puede cancelarlo o modificarlo
              después si lo necesita. No hay nada más que configurar acá.
            </p>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              {professionalMode === "SINGLE"
                ? "¿A qué hora querés recibir tu resumen de turnos del día por WhatsApp?"
                : "¿A qué hora querés que cada profesional reciba su resumen de turnos del día?"}
            </p>
            <div>
              <Label>Hora del resumen diario</Label>
              <Input type="time" value={dailySummaryTime} onChange={(e) => setDailySummaryTime(e.target.value)} />
            </div>
            <p className="text-xs text-gray-500">
              Todo esto lo podés volver a cambiar cuando quieras desde WhatsApp → Automatizaciones.
            </p>
          </div>
        )}

        <ErrorText>{error}</ErrorText>

        <div className="mt-6 flex justify-between">
          <Button type="button" variant="secondary" onClick={back} disabled={step === 0}>
            Atrás
          </Button>
          {step < TOTAL_STEPS - 1 ? (
            <Button type="button" onClick={next}>
              Siguiente
            </Button>
          ) : (
            <Button type="button" onClick={handleFinish} disabled={submitting}>
              {submitting ? "Guardando..." : "Empezar a usar el sistema"}
            </Button>
          )}
        </div>
      </Card>
    </div>
  );
}
