import { useState } from "react";
import { api, ApiError } from "../../lib/api";
import { Button, ErrorText, Field, Input, Label } from "../../components/ui";
import { PhoneInput } from "../../components/PhoneInput";
import { PHONE_HINT, isValidPhone } from "../../lib/validation";
import type { Professional } from "../../types";

export default function ProfessionalModal({
  professional,
  onClose,
  onSaved,
}: {
  professional: Professional | null;
  onClose: () => void;
  onSaved: (p: Professional) => void;
}) {
  const [name, setName] = useState(professional?.name ?? "");
  const [specialty, setSpecialty] = useState(professional?.specialty ?? "");
  const [description, setDescription] = useState(professional?.description ?? "");
  const [phone, setPhone] = useState(professional?.phone ?? "");
  const [phoneConfirmed, setPhoneConfirmed] = useState(false);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (phone.trim()) {
      if (!isValidPhone(phone)) {
        setError(`Revisá el teléfono, no parece completo. ${PHONE_HINT}`);
        return;
      }
      if (!phoneConfirmed) {
        setError("Confirmá que el teléfono está bien escrito antes de guardar");
        return;
      }
    }
    setLoading(true);
    try {
      let saved: Professional;
      if (professional) {
        saved = await api.put<Professional>(`/api/business/professionals/${professional.id}`, {
          name,
          specialty,
          description,
          phone,
        });
      } else {
        saved = await api.post<Professional>("/api/business/professionals", { name, specialty, description, phone });
      }

      if (photoFile) {
        const formData = new FormData();
        formData.append("photo", photoFile);
        const res = await fetch(`/api/business/professionals/${saved.id}/photo`, {
          method: "POST",
          credentials: "include",
          body: formData,
        });
        if (res.ok) saved = await res.json();
      }

      onSaved(saved);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al guardar el profesional");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
      <div className="w-full max-w-md rounded-xl bg-white p-6 shadow-lg">
        <h2 className="mb-4 text-lg font-semibold text-gray-900">
          {professional ? "Editar profesional" : "Nuevo profesional"}
        </h2>
        <form onSubmit={handleSubmit} className="space-y-3">
          <Field label="Nombre">
            <Input value={name} onChange={(e) => setName(e.target.value)} required autoFocus />
          </Field>
          <Field label="Especialidad">
            <Input value={specialty} onChange={(e) => setSpecialty(e.target.value)} placeholder="Ej: Colorimetría" />
          </Field>
          <Field label="Teléfono (para el resumen diario y los pedidos de aprobación por WhatsApp)">
            <PhoneInput
              value={phone}
              onChange={(v) => {
                setPhone(v);
                setPhoneConfirmed(false);
              }}
            />
          </Field>
          {phone.trim() && (
            <div className="rounded-lg bg-amber-50 p-3">
              <label className="flex items-center gap-2 text-sm text-amber-900">
                <input
                  type="checkbox"
                  checked={phoneConfirmed}
                  onChange={(e) => setPhoneConfirmed(e.target.checked)}
                />
                Confirmo que el teléfono está bien escrito
              </label>
            </div>
          )}
          <div>
            <Label>Descripción</Label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
          <div>
            <Label>Foto</Label>
            {professional?.photoUrl && !photoFile && (
              <img src={professional.photoUrl} alt="" className="mb-2 h-16 w-16 rounded-full object-cover" />
            )}
            <input
              type="file"
              accept="image/*"
              onChange={(e) => setPhotoFile(e.target.files?.[0] ?? null)}
              className="block w-full text-sm text-gray-600"
            />
          </div>
          <ErrorText>{error}</ErrorText>
          <div className="mt-4 flex justify-end gap-2">
            <Button type="button" variant="secondary" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Guardando..." : "Guardar"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
