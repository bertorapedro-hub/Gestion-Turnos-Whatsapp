import { useEffect, useState } from "react";
import { api, ApiError } from "../../lib/api";
import { Badge, Button, Card, Input } from "../../components/ui";
import type { Appointment } from "../../types";
import NewAppointmentModal from "./NewAppointmentModal";

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

const STATUS_TONE: Record<string, "gray" | "green" | "red" | "yellow"> = {
  PENDING: "yellow",
  CONFIRMED: "green",
  CANCELLED: "red",
  DONE: "gray",
};
const STATUS_LABEL: Record<string, string> = {
  PENDING: "Pendiente",
  CONFIRMED: "Confirmado",
  CANCELLED: "Cancelado",
  DONE: "Realizado",
};

export default function AppointmentsPage() {
  const [date, setDate] = useState(todayStr());
  const [appointments, setAppointments] = useState<Appointment[] | null>(null);
  const [error, setError] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function load() {
    try {
      const from = new Date(`${date}T00:00:00`).toISOString();
      const to = new Date(`${date}T23:59:59`).toISOString();
      const data = await api.get<Appointment[]>(`/api/business/appointments?from=${from}&to=${to}`);
      setAppointments(data);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al cargar turnos");
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  async function handleConfirm(id: string) {
    setBusyId(id);
    try {
      const updated = await api.post<Appointment>(`/api/business/appointments/${id}/confirm`);
      setAppointments((prev) => prev?.map((a) => (a.id === id ? updated : a)) ?? null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al confirmar el turno");
    } finally {
      setBusyId(null);
    }
  }

  async function handleCancel(id: string) {
    if (!window.confirm("¿Cancelar este turno?")) return;
    setBusyId(id);
    try {
      const updated = await api.post<Appointment>(`/api/business/appointments/${id}/cancel`);
      setAppointments((prev) => prev?.map((a) => (a.id === id ? updated : a)) ?? null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al cancelar el turno");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-lg font-semibold text-gray-900">Turnos</h1>
        <div className="flex items-center gap-2">
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-40" />
          <Button onClick={() => setShowNew(true)}>+ Nuevo turno</Button>
        </div>
      </div>

      {error && <p className="mb-3 text-sm text-red-600">{error}</p>}

      <Card className="overflow-x-auto p-0">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="border-b border-gray-200 bg-gray-50 text-xs uppercase text-gray-500">
            <tr>
              <th className="px-4 py-3">Hora</th>
              <th className="px-4 py-3">Cliente</th>
              <th className="px-4 py-3">Profesional</th>
              <th className="px-4 py-3">Servicio</th>
              <th className="px-4 py-3">Estado</th>
              <th className="px-4 py-3 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {appointments?.map((a) => (
              <tr key={a.id} className="border-b border-gray-100 last:border-0">
                <td className="px-4 py-3">
                  {new Date(a.startAt).toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" })}
                </td>
                <td className="px-4 py-3">
                  <p className="font-medium text-gray-900">{a.client.fullName}</p>
                  <p className="text-xs text-gray-500">{a.client.phone}</p>
                </td>
                <td className="px-4 py-3 text-gray-600">{a.professional.name}</td>
                <td className="px-4 py-3 text-gray-600">{a.service.name}</td>
                <td className="px-4 py-3">
                  <Badge tone={STATUS_TONE[a.status]}>{STATUS_LABEL[a.status]}</Badge>
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    {a.status === "PENDING" && (
                      <Button variant="secondary" disabled={busyId === a.id} onClick={() => handleConfirm(a.id)}>
                        Confirmar
                      </Button>
                    )}
                    {a.status !== "CANCELLED" && (
                      <Button variant="danger" disabled={busyId === a.id} onClick={() => handleCancel(a.id)}>
                        Cancelar
                      </Button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
            {appointments?.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                  No hay turnos ese día.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Card>

      {showNew && (
        <NewAppointmentModal
          onClose={() => setShowNew(false)}
          onCreated={(a) => {
            setShowNew(false);
            if (a.startAt.slice(0, 10) === date) {
              setAppointments((prev) => [...(prev ?? []), a].sort((x, y) => x.startAt.localeCompare(y.startAt)));
            }
          }}
        />
      )}
    </div>
  );
}
