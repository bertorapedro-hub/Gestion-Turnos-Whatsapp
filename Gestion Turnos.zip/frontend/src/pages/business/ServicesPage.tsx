import { useEffect, useState } from "react";
import { api, ApiError } from "../../lib/api";
import { Badge, Button, Card } from "../../components/ui";
import type { Service } from "../../types";
import ServiceModal from "./ServiceModal";

const currency = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" });

export default function ServicesPage() {
  const [services, setServices] = useState<Service[] | null>(null);
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Service | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function load() {
    try {
      const data = await api.get<Service[]>("/api/business/services?includeInactive=true");
      setServices(data);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al cargar servicios");
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function toggleActive(s: Service) {
    setBusyId(s.id);
    try {
      const action = s.isActive ? "deactivate" : "activate";
      const updated = await api.post<Service>(`/api/business/services/${s.id}/${action}`);
      setServices((prev) => prev?.map((x) => (x.id === s.id ? { ...x, ...updated } : x)) ?? null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al actualizar el estado");
    } finally {
      setBusyId(null);
    }
  }

  async function handleDelete(s: Service) {
    if (!window.confirm(`¿Eliminar "${s.name}"? Si tiene turnos asociados, usá "Dar de baja" en su lugar.`)) return;
    setBusyId(s.id);
    try {
      await api.del(`/api/business/services/${s.id}`);
      setServices((prev) => prev?.filter((x) => x.id !== s.id) ?? null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al eliminar el servicio");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-lg font-semibold text-gray-900">Servicios</h1>
        <Button
          onClick={() => {
            setEditing(null);
            setModalOpen(true);
          }}
        >
          + Nuevo servicio
        </Button>
      </div>

      {error && <p className="mb-3 text-sm text-red-600">{error}</p>}

      <Card className="overflow-x-auto p-0">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="border-b border-gray-200 bg-gray-50 text-xs uppercase text-gray-500">
            <tr>
              <th className="px-4 py-3">Servicio</th>
              <th className="px-4 py-3">Duración</th>
              <th className="px-4 py-3">Precio</th>
              <th className="px-4 py-3">Profesionales</th>
              <th className="px-4 py-3">Estado</th>
              <th className="px-4 py-3 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {services?.map((s) => (
              <tr key={s.id} className="border-b border-gray-100 last:border-0">
                <td className="px-4 py-3 font-medium text-gray-900">{s.name}</td>
                <td className="px-4 py-3 text-gray-600">{s.durationMin} min</td>
                <td className="px-4 py-3 text-gray-600">{currency.format(s.price)}</td>
                <td className="px-4 py-3 text-gray-600">
                  {s.professionals?.map((sp) => sp.professional.name).join(", ") || "—"}
                </td>
                <td className="px-4 py-3">
                  <Badge tone={s.isActive ? "green" : "gray"}>{s.isActive ? "Activo" : "Inactivo"}</Badge>
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="secondary"
                      onClick={() => {
                        setEditing(s);
                        setModalOpen(true);
                      }}
                    >
                      Editar
                    </Button>
                    <Button variant="secondary" disabled={busyId === s.id} onClick={() => toggleActive(s)}>
                      {s.isActive ? "Dar de baja" : "Reactivar"}
                    </Button>
                    <Button variant="danger" disabled={busyId === s.id} onClick={() => handleDelete(s)}>
                      Eliminar
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {services?.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                  Todavía no cargaste servicios.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Card>

      {modalOpen && (
        <ServiceModal
          service={editing}
          onClose={() => setModalOpen(false)}
          onSaved={(s) => {
            setServices((prev) => {
              if (!prev) return [s];
              const exists = prev.some((x) => x.id === s.id);
              return exists ? prev.map((x) => (x.id === s.id ? s : x)) : [s, ...prev];
            });
            setModalOpen(false);
          }}
        />
      )}
    </div>
  );
}
