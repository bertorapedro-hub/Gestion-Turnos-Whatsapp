import { useEffect, useMemo, useState } from "react";
import { api, ApiError } from "../../lib/api";
import { useAuth } from "../../context/AuthContext";
import { Button, ErrorText, Field, Input, Label } from "../../components/ui";
import { PhoneInput } from "../../components/PhoneInput";
import { PHONE_HINT, isValidPhone } from "../../lib/validation";
import type { Appointment, Client, Professional, Service } from "../../types";

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export default function NewAppointmentModal({
  onClose,
  onCreated,
}: {
  onClose: () => void;
  onCreated: (a: Appointment) => void;
}) {
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [professionalId, setProfessionalId] = useState("");
  const [serviceId, setServiceId] = useState("");
  const [date, setDate] = useState(todayStr());
  const [slots, setSlots] = useState<string[]>([]);
  const [selectedSlot, setSelectedSlot] = useState("");
  const [loadingSlots, setLoadingSlots] = useState(false);

  const [documentQuery, setDocumentQuery] = useState("");
  const [foundClient, setFoundClient] = useState<Client | null>(null);
  const [searched, setSearched] = useState(false);
  const [newClient, setNewClient] = useState({ fullName: "", documentId: "", phone: "" });
  const [newClientPhoneConfirmed, setNewClientPhoneConfirmed] = useState(false);
  const [notes, setNotes] = useState("");

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const isSingleMode = user?.professionalMode === "SINGLE";

  useEffect(() => {
    api
      .get<Professional[]>("/api/business/professionals")
      .then((list) => {
        setProfessionals(list);
        if (isSingleMode && list.length === 1) setProfessionalId(list[0].id);
      })
      .catch(() => {});
    api.get<Service[]>("/api/business/services").then(setServices).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSingleMode]);

  const servicesForProfessional = useMemo(
    () => services.filter((s) => s.professionals?.some((sp) => sp.professional.id === professionalId)),
    [services, professionalId]
  );

  useEffect(() => {
    setSelectedSlot("");
    setSlots([]);
    if (!professionalId || !serviceId || !date) return;
    setLoadingSlots(true);
    api
      .get<{ slots: string[] }>(
        `/api/business/appointments/availability?professionalId=${professionalId}&serviceId=${serviceId}&date=${date}`
      )
      .then((r) => setSlots(r.slots))
      .catch(() => setSlots([]))
      .finally(() => setLoadingSlots(false));
  }, [professionalId, serviceId, date]);

  async function handleSearchClient() {
    setSearched(true);
    setFoundClient(null);
    try {
      const results = await api.get<Client[]>(`/api/business/clients?q=${encodeURIComponent(documentQuery)}`);
      const exact = results.find((c) => c.documentId === documentQuery);
      setFoundClient(exact ?? results[0] ?? null);
      if (!exact && !results[0]) setNewClient((prev) => ({ ...prev, documentId: documentQuery }));
    } catch {
      setFoundClient(null);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!selectedSlot) {
      setError("Elegí un horario disponible");
      return;
    }
    if (!foundClient) {
      if (!isValidPhone(newClient.phone)) {
        setError(`Revisá el teléfono, no parece completo. ${PHONE_HINT}`);
        return;
      }
      if (!newClientPhoneConfirmed) {
        setError("Confirmá que el teléfono está bien escrito antes de guardar");
        return;
      }
    }
    setLoading(true);
    try {
      const startAt = new Date(`${date}T${selectedSlot}:00`).toISOString();
      const appointment = await api.post<Appointment>("/api/business/appointments", {
        clientId: foundClient?.id,
        newClient: foundClient
          ? undefined
          : {
              fullName: newClient.fullName,
              documentId: newClient.documentId,
              phone: newClient.phone,
            },
        professionalId,
        serviceId,
        startAt,
        notes,
      });
      onCreated(appointment);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al crear el turno");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/40 px-4 py-8">
      <div className="w-full max-w-lg rounded-xl bg-white p-6 shadow-lg">
        <h2 className="mb-4 text-lg font-semibold text-gray-900">Nuevo turno</h2>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className={isSingleMode ? "" : "grid grid-cols-2 gap-3"}>
            {!isSingleMode && (
              <div>
                <Label>Profesional</Label>
                <select
                  value={professionalId}
                  onChange={(e) => {
                    setProfessionalId(e.target.value);
                    setServiceId("");
                  }}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
                  required
                >
                  <option value="">Elegir...</option>
                  {professionals.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>
            )}
            <div>
              <Label>Servicio</Label>
              <select
                value={serviceId}
                onChange={(e) => setServiceId(e.target.value)}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
                required
                disabled={!professionalId}
              >
                <option value="">Elegir...</option>
                {servicesForProfessional.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.durationMin} min)
                  </option>
                ))}
              </select>
            </div>
          </div>

          <Field label="Fecha">
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
          </Field>

          <div>
            <Label>Horario disponible</Label>
            {loadingSlots && <p className="text-sm text-gray-400">Buscando horarios...</p>}
            {!loadingSlots && professionalId && serviceId && slots.length === 0 && (
              <p className="text-sm text-gray-400">No hay horarios libres ese día.</p>
            )}
            <div className="flex flex-wrap gap-2">
              {slots.map((s) => (
                <button
                  type="button"
                  key={s}
                  onClick={() => setSelectedSlot(s)}
                  className={`min-h-11 rounded-lg border px-3 py-2 text-sm ${
                    selectedSlot === s
                      ? "border-indigo-600 bg-indigo-600 text-white"
                      : "border-gray-300 text-gray-700 hover:bg-gray-50"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <hr className="border-gray-200" />
          <Label>Cliente</Label>
          <div className="flex gap-2">
            <Input
              value={documentQuery}
              onChange={(e) => setDocumentQuery(e.target.value)}
              placeholder="Buscar por documento"
            />
            <Button type="button" variant="secondary" onClick={handleSearchClient}>
              Buscar
            </Button>
          </div>
          {foundClient && (
            <p className="text-sm text-green-700">
              Cliente encontrado: {foundClient.fullName} ({foundClient.documentId})
            </p>
          )}
          {searched && !foundClient && (
            <div className="space-y-2 rounded-lg border border-gray-200 p-3">
              <p className="text-xs text-gray-500">No se encontró, se creará un cliente nuevo</p>
              <Input
                placeholder="Nombre completo"
                value={newClient.fullName}
                onChange={(e) => setNewClient((p) => ({ ...p, fullName: e.target.value }))}
                required
              />
              <Input
                placeholder="Documento"
                value={newClient.documentId}
                onChange={(e) => setNewClient((p) => ({ ...p, documentId: e.target.value }))}
                required
              />
              <PhoneInput
                value={newClient.phone}
                onChange={(v) => {
                  setNewClient((p) => ({ ...p, phone: v }));
                  setNewClientPhoneConfirmed(false);
                }}
              />
              {newClient.phone.trim() && (
                <div className="rounded-lg bg-amber-50 p-3">
                  <label className="flex items-center gap-2 text-sm text-amber-900">
                    <input
                      type="checkbox"
                      checked={newClientPhoneConfirmed}
                      onChange={(e) => setNewClientPhoneConfirmed(e.target.checked)}
                    />
                    Confirmo que el teléfono está bien escrito
                  </label>
                </div>
              )}
            </div>
          )}

          <Field label="Notas (opcional)">
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} />
          </Field>

          <ErrorText>{error}</ErrorText>
          <div className="mt-4 flex justify-end gap-2">
            <Button type="button" variant="secondary" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Creando..." : "Crear turno"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
