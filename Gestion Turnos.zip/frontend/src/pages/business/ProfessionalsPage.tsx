import { useEffect, useState } from "react";
import { api, ApiError } from "../../lib/api";
import { Badge, Button, Card } from "../../components/ui";
import type { Professional } from "../../types";
import ProfessionalModal from "./ProfessionalModal";

export default function ProfessionalsPage() {
  const [professionals, setProfessionals] = useState<Professional[] | null>(null);
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Professional | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function load() {
    try {
      const data = await api.get<Professional[]>("/api/business/professionals?includeInactive=true");
      setProfessionals(data);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al cargar profesionales");
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function toggleActive(p: Professional) {
    setBusyId(p.id);
    try {
      const action = p.isActive ? "deactivate" : "activate";
      const updated = await api.post<Professional>(`/api/business/professionals/${p.id}/${action}`);
      setProfessionals((prev) => prev?.map((x) => (x.id === p.id ? { ...x, ...updated } : x)) ?? null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al actualizar el estado");
    } finally {
      setBusyId(null);
    }
  }

  async function handleDelete(p: Professional) {
    if (!window.confirm(`¿Eliminar a "${p.name}"? Si tiene turnos asociados, usá "Dar de baja" en su lugar.`)) return;
    setBusyId(p.id);
    try {
      await api.del(`/api/business/professionals/${p.id}`);
      setProfessionals((prev) => prev?.filter((x) => x.id !== p.id) ?? null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al eliminar el profesional");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-lg font-semibold text-gray-900">Profesionales</h1>
        <Button
          onClick={() => {
            setEditing(null);
            setModalOpen(true);
          }}
        >
          + Nuevo profesional
        </Button>
      </div>

      {error && <p className="mb-3 text-sm text-red-600">{error}</p>}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {professionals?.map((p) => (
          <Card key={p.id} className="flex flex-col gap-3">
            <div className="flex items-center gap-3">
              {p.photoUrl ? (
                <img src={p.photoUrl} alt="" className="h-12 w-12 rounded-full object-cover" />
              ) : (
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-indigo-100 text-sm font-semibold text-indigo-700">
                  {p.name.slice(0, 2).toUpperCase()}
                </div>
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium text-gray-900">{p.name}</p>
                <p className="truncate text-xs text-gray-500">{p.specialty || "—"}</p>
              </div>
              <Badge tone={p.isActive ? "green" : "gray"}>{p.isActive ? "Activo" : "Inactivo"}</Badge>
            </div>
            {p.description && <p className="text-sm text-gray-600">{p.description}</p>}
            <div className="mt-auto flex gap-2 pt-2">
              <Button
                variant="secondary"
                className="flex-1"
                onClick={() => {
                  setEditing(p);
                  setModalOpen(true);
                }}
              >
                Editar
              </Button>
              <Button variant="secondary" disabled={busyId === p.id} onClick={() => toggleActive(p)}>
                {p.isActive ? "Dar de baja" : "Reactivar"}
              </Button>
              <Button variant="danger" disabled={busyId === p.id} onClick={() => handleDelete(p)}>
                Eliminar
              </Button>
            </div>
          </Card>
        ))}
        {professionals?.length === 0 && (
          <p className="col-span-full py-8 text-center text-sm text-gray-500">Todavía no cargaste profesionales.</p>
        )}
      </div>

      {modalOpen && (
        <ProfessionalModal
          professional={editing}
          onClose={() => setModalOpen(false)}
          onSaved={(p) => {
            setProfessionals((prev) => {
              if (!prev) return [p];
              const exists = prev.some((x) => x.id === p.id);
              return exists ? prev.map((x) => (x.id === p.id ? p : x)) : [p, ...prev];
            });
            setModalOpen(false);
          }}
        />
      )}
    </div>
  );
}
