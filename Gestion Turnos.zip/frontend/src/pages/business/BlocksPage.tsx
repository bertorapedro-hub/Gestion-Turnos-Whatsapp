import { useEffect, useState } from "react";
import { api, ApiError } from "../../lib/api";
import { Button, Card, ErrorText, Field, Input, Label } from "../../components/ui";
import type { Professional, ScheduleBlock } from "../../types";

function toLocalInput(iso: string) {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export default function BlocksPage() {
  const [blocks, setBlocks] = useState<ScheduleBlock[] | null>(null);
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [professionalId, setProfessionalId] = useState("");
  const [startAt, setStartAt] = useState("");
  const [endAt, setEndAt] = useState("");
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function load() {
    try {
      const [b, p] = await Promise.all([
        api.get<ScheduleBlock[]>("/api/business/schedule/blocks"),
        api.get<Professional[]>("/api/business/professionals"),
      ]);
      setBlocks(b);
      setProfessionals(p);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al cargar los bloqueos");
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const created = await api.post<ScheduleBlock>("/api/business/schedule/blocks", {
        professionalId: professionalId || null,
        startAt: new Date(startAt).toISOString(),
        endAt: new Date(endAt).toISOString(),
        reason,
      });
      setBlocks((prev) => [...(prev ?? []), created].sort((a, b) => a.startAt.localeCompare(b.startAt)));
      setStartAt("");
      setEndAt("");
      setReason("");
      setProfessionalId("");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al crear el bloqueo");
    } finally {
      setLoading(false);
    }
  }

  async function handleDelete(id: string) {
    if (!window.confirm("¿Eliminar este bloqueo?")) return;
    try {
      await api.del(`/api/business/schedule/blocks/${id}`);
      setBlocks((prev) => prev?.filter((b) => b.id !== id) ?? null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al eliminar el bloqueo");
    }
  }

  return (
    <div>
      <h1 className="mb-4 text-lg font-semibold text-gray-900">Bloqueos de agenda</h1>
      <Card className="mb-4">
        <p className="mb-3 text-sm text-gray-500">
          Cargá vacaciones, feriados o ausencias. Dejá "Profesional" vacío para un bloqueo general del negocio.
        </p>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field label="Desde">
            <Input type="datetime-local" value={startAt} onChange={(e) => setStartAt(e.target.value)} required />
          </Field>
          <Field label="Hasta">
            <Input type="datetime-local" value={endAt} onChange={(e) => setEndAt(e.target.value)} required />
          </Field>
          <div>
            <Label>Profesional (opcional)</Label>
            <select
              value={professionalId}
              onChange={(e) => setProfessionalId(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
            >
              <option value="">Todo el negocio</option>
              {professionals.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>
          <Field label="Motivo (opcional)">
            <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Ej: Vacaciones" />
          </Field>
          <div className="sm:col-span-2">
            <ErrorText>{error}</ErrorText>
            <Button type="submit" disabled={loading}>
              {loading ? "Guardando..." : "Crear bloqueo"}
            </Button>
          </div>
        </form>
      </Card>

      <Card className="overflow-x-auto p-0">
        <table className="w-full min-w-[600px] text-left text-sm">
          <thead className="border-b border-gray-200 bg-gray-50 text-xs uppercase text-gray-500">
            <tr>
              <th className="px-4 py-3">Desde</th>
              <th className="px-4 py-3">Hasta</th>
              <th className="px-4 py-3">Alcance</th>
              <th className="px-4 py-3">Motivo</th>
              <th className="px-4 py-3 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {blocks?.map((b) => (
              <tr key={b.id} className="border-b border-gray-100 last:border-0">
                <td className="px-4 py-3">{toLocalInput(b.startAt).replace("T", " ")}</td>
                <td className="px-4 py-3">{toLocalInput(b.endAt).replace("T", " ")}</td>
                <td className="px-4 py-3">{b.professional?.name ?? "Todo el negocio"}</td>
                <td className="px-4 py-3">{b.reason ?? "—"}</td>
                <td className="px-4 py-3 text-right">
                  <Button variant="danger" onClick={() => handleDelete(b.id)}>
                    Eliminar
                  </Button>
                </td>
              </tr>
            ))}
            {blocks?.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-gray-500">
                  No hay bloqueos cargados.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
