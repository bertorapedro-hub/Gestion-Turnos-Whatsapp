import { useEffect, useState } from "react";
import { api } from "../../lib/api";
import { Card } from "../../components/ui";
import type { Appointment, Professional, Service } from "../../types";

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}
function endOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(23, 59, 59, 999);
  return x;
}
function startOfMonth(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}
function endOfMonth(d: Date) {
  return new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59, 999);
}

export default function BusinessHome() {
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [todayAppointments, setTodayAppointments] = useState<Appointment[]>([]);
  const [monthCount, setMonthCount] = useState<number | null>(null);

  useEffect(() => {
    const now = new Date();
    api.get<Professional[]>("/api/business/professionals").then(setProfessionals).catch(() => {});
    api.get<Service[]>("/api/business/services").then(setServices).catch(() => {});
    api
      .get<Appointment[]>(
        `/api/business/appointments?from=${startOfDay(now).toISOString()}&to=${endOfDay(now).toISOString()}`
      )
      .then(setTodayAppointments)
      .catch(() => {});
    api
      .get<Appointment[]>(
        `/api/business/appointments?from=${startOfMonth(now).toISOString()}&to=${endOfMonth(now).toISOString()}`
      )
      .then((list) => setMonthCount(list.length))
      .catch(() => {});
  }, []);

  return (
    <div>
      <h1 className="mb-4 text-lg font-semibold text-gray-900">Resumen</h1>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
        <Card>
          <p className="text-xs uppercase text-gray-500">Turnos hoy</p>
          <p className="mt-1 text-2xl font-semibold text-gray-900">{todayAppointments.length}</p>
        </Card>
        <Card>
          <p className="text-xs uppercase text-gray-500">Turnos este mes</p>
          <p className="mt-1 text-2xl font-semibold text-gray-900">{monthCount ?? "—"}</p>
        </Card>
        <Card>
          <p className="text-xs uppercase text-gray-500">Profesionales activos</p>
          <p className="mt-1 text-2xl font-semibold text-gray-900">{professionals.length}</p>
        </Card>
        <Card>
          <p className="text-xs uppercase text-gray-500">Servicios activos</p>
          <p className="mt-1 text-2xl font-semibold text-gray-900">{services.length}</p>
        </Card>
      </div>

      <Card className="mt-4">
        <h2 className="mb-3 text-sm font-semibold text-gray-900">Agenda de hoy</h2>
        <ul className="divide-y divide-gray-100">
          {todayAppointments.map((a) => (
            <li key={a.id} className="flex items-center justify-between py-2 text-sm">
              <span className="text-gray-500">
                {new Date(a.startAt).toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" })}
              </span>
              <span className="flex-1 px-3 text-gray-900">{a.client.fullName}</span>
              <span className="text-gray-500">
                {a.service.name} · {a.professional.name}
              </span>
            </li>
          ))}
          {todayAppointments.length === 0 && <p className="py-4 text-sm text-gray-500">No hay turnos para hoy.</p>}
        </ul>
      </Card>
    </div>
  );
}
