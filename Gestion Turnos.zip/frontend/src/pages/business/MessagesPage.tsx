import { useEffect, useState } from "react";
import { api, ApiError } from "../../lib/api";
import { Badge, Button, Card, ErrorText, Label } from "../../components/ui";
import type { Professional } from "../../types";

interface Template {
  id: string;
  eventType: string;
  body: string;
}
interface MessageLogEntry {
  id: string;
  recipientType: string;
  recipientName: string | null;
  recipientPhone: string;
  eventType: string;
  body: string;
  status: string;
  errorMessage: string | null;
  createdAt: string;
}

const EVENT_LABELS: Record<string, string> = {
  BOOKING_CONFIRMATION: "Aviso al cliente: turno confirmado",
  REMINDER_DAY: "Aviso al cliente: recordatorio (días antes)",
  REMINDER_HOUR: "Aviso al cliente: recordatorio (horas antes)",
  DAILY_SUMMARY: "Aviso al profesional: resumen diario",
  CANCELLED_BY_CLIENT: "Aviso al profesional: cliente canceló",
  CANCELLED_BY_PROFESSIONAL: "Aviso al cliente: profesional canceló",
  CANCELLED_BY_BUSINESS: "Aviso al cliente: negocio canceló",
  MODIFIED: "Aviso al cliente: turno reprogramado",
  BROADCAST: "Mensaje de difusión",
  AUTO_CANCELLED_UNCONFIRMED: "Aviso al cliente: cancelado automático por no responder el profesional",
  PROFESSIONAL_APPROVAL_REQUEST: "Aviso al profesional: pedido de aprobación",
  CLIENT_AWAITING_APPROVAL: "Aviso al cliente: esperando aprobación",
  CONFIRMED_BY_PROFESSIONAL: "Aviso al cliente: profesional aprobó",
};

// Mostrar un evento que no aplica al modo activo del negocio confunde (por ejemplo, "pedido de
// aprobación al profesional" en un negocio que usa "el cliente confirma solo"). BROADCAST se
// esconde porque ese texto se escribe directo en la pestaña "Difusión" cada vez, no tiene
// sentido como plantilla aparte.
const CLIENT_SELF_ONLY = new Set(["BOOKING_CONFIRMATION"]);
const PROFESSIONAL_APPROVAL_ONLY = new Set([
  "PROFESSIONAL_APPROVAL_REQUEST",
  "CLIENT_AWAITING_APPROVAL",
  "CONFIRMED_BY_PROFESSIONAL",
  "AUTO_CANCELLED_UNCONFIRMED",
]);
const HIDDEN_EVENT_TYPES = new Set(["BROADCAST"]);

function isTemplateVisible(eventType: string, bookingConfirmationMode: string | null): boolean {
  if (HIDDEN_EVENT_TYPES.has(eventType)) return false;
  if (CLIENT_SELF_ONLY.has(eventType)) return bookingConfirmationMode !== "PROFESSIONAL_APPROVAL";
  if (PROFESSIONAL_APPROVAL_ONLY.has(eventType)) return bookingConfirmationMode === "PROFESSIONAL_APPROVAL";
  return true;
}

const VARIABLES_HINT =
  "Variables disponibles: {{cliente}} {{fecha}} {{hora}} {{servicio}} {{profesional}} {{negocio}} {{link_confirmar}} {{link_cancelar}} {{link_modificar}} {{link_reservar}} {{lista_turnos}} {{mensaje}}";

const STATUS_TONE: Record<string, "gray" | "green" | "red" | "yellow"> = {
  SENT: "green",
  FAILED: "red",
  SKIPPED_NOT_LINKED: "yellow",
};

function TemplateEditor({ template, onSaved }: { template: Template; onSaved: (t: Template) => void }) {
  const [body, setBody] = useState(template.body);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);

  async function handleSave() {
    setSaving(true);
    setError("");
    setSaved(false);
    try {
      const updated = await api.put<Template>(`/api/business/messages/templates/${template.eventType}`, { body });
      onSaved(updated);
      setSaved(true);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al guardar la plantilla");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card>
      <p className="mb-2 text-sm font-semibold text-gray-900">
        {EVENT_LABELS[template.eventType] ?? template.eventType}
      </p>
      <textarea
        value={body}
        onChange={(e) => setBody(e.target.value)}
        rows={3}
        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
      />
      <ErrorText>{error}</ErrorText>
      {saved && <p className="mt-1 text-xs text-green-600">Guardado</p>}
      <Button className="mt-2" variant="secondary" disabled={saving} onClick={handleSave}>
        {saving ? "Guardando..." : "Guardar"}
      </Button>
    </Card>
  );
}

function TemplatesTab() {
  const [templates, setTemplates] = useState<Template[] | null>(null);
  const [bookingConfirmationMode, setBookingConfirmationMode] = useState<string | null>(null);

  useEffect(() => {
    api.get<Template[]>("/api/business/messages/templates").then(setTemplates).catch(() => setTemplates([]));
    api
      .get<{ bookingConfirmationMode: string }>("/api/business/settings")
      .then((s) => setBookingConfirmationMode(s.bookingConfirmationMode))
      .catch(() => {});
  }, []);

  if (!templates) return <p className="text-sm text-gray-500">Cargando...</p>;

  const visibleTemplates = templates.filter((t) => isTemplateVisible(t.eventType, bookingConfirmationMode));

  return (
    <div>
      <p className="mb-3 rounded-lg bg-indigo-50 p-3 text-xs text-indigo-800">{VARIABLES_HINT}</p>
      <div className="space-y-3">
        {visibleTemplates.map((t) => (
          <TemplateEditor
            key={t.id}
            template={t}
            onSaved={(updated) => setTemplates((prev) => prev?.map((x) => (x.id === updated.id ? updated : x)) ?? null)}
          />
        ))}
      </div>
    </div>
  );
}

function BroadcastTab() {
  const [message, setMessage] = useState("");
  const [professionalId, setProfessionalId] = useState("");
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [result, setResult] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.get<Professional[]>("/api/business/professionals").then(setProfessionals).catch(() => {});
  }, []);

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setResult("");
    if (!window.confirm("¿Enviar este mensaje a todos los clientes seleccionados?")) return;
    setLoading(true);
    try {
      const res = await api.post<{ recipients: number }>("/api/business/messages/broadcast", {
        message,
        professionalId: professionalId || undefined,
      });
      setResult(`Mensaje procesado para ${res.recipients} cliente(s). Revisá el historial para ver el resultado de cada envío.`);
      setMessage("");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Error al enviar la difusión");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card>
      <form onSubmit={handleSend} className="space-y-3">
        <div>
          <Label>Destinatarios</Label>
          <select
            value={professionalId}
            onChange={(e) => setProfessionalId(e.target.value)}
            className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
          >
            <option value="">Todos los clientes</option>
            {professionals.map((p) => (
              <option key={p.id} value={p.id}>
                Clientes de {p.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <Label>Mensaje</Label>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={4}
            required
            placeholder="Escribí el mensaje que se enviará por WhatsApp a los clientes elegidos"
            className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
          />
        </div>
        <ErrorText>{error}</ErrorText>
        {result && <p className="text-sm text-green-700">{result}</p>}
        <Button type="submit" disabled={loading}>
          {loading ? "Enviando..." : "Enviar difusión"}
        </Button>
      </form>
    </Card>
  );
}

function LogTab() {
  const [logs, setLogs] = useState<MessageLogEntry[] | null>(null);

  useEffect(() => {
    api.get<MessageLogEntry[]>("/api/business/messages/log").then(setLogs).catch(() => setLogs([]));
  }, []);

  return (
    <Card className="overflow-x-auto p-0">
      <table className="w-full min-w-[720px] text-left text-sm">
        <thead className="border-b border-gray-200 bg-gray-50 text-xs uppercase text-gray-500">
          <tr>
            <th className="px-4 py-3">Fecha</th>
            <th className="px-4 py-3">Destinatario</th>
            <th className="px-4 py-3">Evento</th>
            <th className="px-4 py-3">Estado</th>
            <th className="px-4 py-3">Detalle</th>
          </tr>
        </thead>
        <tbody>
          {logs?.map((l) => (
            <tr key={l.id} className="border-b border-gray-100 last:border-0 align-top">
              <td className="px-4 py-3 whitespace-nowrap text-gray-600">{new Date(l.createdAt).toLocaleString("es-AR")}</td>
              <td className="px-4 py-3">
                <p className="font-medium text-gray-900">{l.recipientName ?? "—"}</p>
                <p className="text-xs text-gray-500">{l.recipientPhone}</p>
              </td>
              <td className="px-4 py-3 text-gray-600">{EVENT_LABELS[l.eventType] ?? l.eventType}</td>
              <td className="px-4 py-3">
                <Badge tone={STATUS_TONE[l.status] ?? "gray"}>{l.status}</Badge>
              </td>
              <td className="px-4 py-3 text-xs text-gray-500">{l.errorMessage ?? "—"}</td>
            </tr>
          ))}
          {logs?.length === 0 && (
            <tr>
              <td colSpan={5} className="px-4 py-8 text-center text-gray-500">
                Todavía no se enviaron mensajes.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </Card>
  );
}

export default function MessagesPage() {
  const [tab, setTab] = useState<"templates" | "broadcast" | "log">("templates");

  const tabs: { key: typeof tab; label: string }[] = [
    { key: "templates", label: "Plantillas" },
    { key: "broadcast", label: "Difusión" },
    { key: "log", label: "Historial" },
  ];

  return (
    <div>
      <h1 className="mb-4 text-lg font-semibold text-gray-900">Mensajes</h1>
      <div className="mb-4 flex gap-1 border-b border-gray-200">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`border-b-2 px-3 py-2 text-sm font-medium ${
              tab === t.key ? "border-indigo-600 text-indigo-700" : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>
      {tab === "templates" && <TemplatesTab />}
      {tab === "broadcast" && <BroadcastTab />}
      {tab === "log" && <LogTab />}
    </div>
  );
}
