import { NavLink, Navigate, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { Button } from "../../components/ui";

const NAV_ITEMS = [
  { to: "/admin", label: "Resumen", end: true },
  { to: "/admin/turnos", label: "Turnos" },
  { to: "/admin/profesionales", label: "Profesionales", multiOnly: true },
  { to: "/admin/servicios", label: "Servicios" },
  { to: "/admin/horarios", label: "Horarios" },
  { to: "/admin/bloqueos", label: "Bloqueos" },
  { to: "/admin/clientes", label: "Clientes" },
  { to: "/admin/mensajes", label: "Mensajes" },
  { to: "/admin/whatsapp", label: "WhatsApp" },
  { to: "/admin/password", label: "Mi contraseña" },
];

export default function BusinessLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    await logout();
    navigate("/admin/login");
  }

  if (user && user.onboardingCompleted === false) {
    return <Navigate to="/admin/bienvenida" replace />;
  }

  const navItems = NAV_ITEMS.filter((item) => !item.multiOnly || user?.professionalMode !== "SINGLE");

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium ${isActive ? "bg-indigo-50 text-indigo-700" : "text-gray-600 hover:bg-gray-100"}`;

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="border-b border-gray-200 bg-white">
        <div className="mx-auto max-w-6xl px-4 py-3">
          <div className="mb-2 flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-gray-900">{user?.businessName}</p>
              <p className="text-xs text-gray-500">{user?.username}</p>
            </div>
            <Button variant="ghost" onClick={handleLogout}>
              Salir
            </Button>
          </div>
          <nav className="flex flex-wrap gap-1 overflow-x-auto">
            {navItems.map((item) => (
              <NavLink key={item.to} to={item.to} end={item.end} className={linkClass}>
                {item.label}
              </NavLink>
            ))}
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6">
        <Outlet />
      </main>
    </div>
  );
}
