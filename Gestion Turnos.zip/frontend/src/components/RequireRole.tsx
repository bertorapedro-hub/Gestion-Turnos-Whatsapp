import { Navigate } from "react-router-dom";
import { useAuth, type AuthUser } from "../context/AuthContext";

export default function RequireRole({
  role,
  redirectTo,
  children,
}: {
  role: AuthUser["role"];
  redirectTo: string;
  children: React.ReactNode;
}) {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center text-sm text-gray-500">Cargando...</div>;
  }
  if (!user || user.role !== role) {
    return <Navigate to={redirectTo} replace />;
  }
  return <>{children}</>;
}
