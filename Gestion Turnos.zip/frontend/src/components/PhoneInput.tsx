import { useState } from "react";

interface Country {
  code: string; // calling code digits, sin "+"
  abbr: string;
  name: string;
}

const COUNTRIES: Country[] = [
  { code: "54", abbr: "AR", name: "Argentina" },
  { code: "598", abbr: "UY", name: "Uruguay" },
  { code: "56", abbr: "CL", name: "Chile" },
  { code: "595", abbr: "PY", name: "Paraguay" },
  { code: "55", abbr: "BR", name: "Brasil" },
  { code: "591", abbr: "BO", name: "Bolivia" },
  { code: "34", abbr: "ES", name: "España" },
  { code: "1", abbr: "US", name: "EE.UU." },
];

// Códigos de área más comunes para autodetectar el corte al editar un teléfono ya guardado.
// Lo que no matchea acá simplemente cae en "Otro" y el usuario lo escribe a mano: no hace falta
// una lista exhaustiva, solo evitar que los casos frecuentes se vean todos amontonados en "Número".
const AR_AREA_CODES: { code: string; label: string }[] = [
  { code: "11", label: "11 – CABA / GBA" },
  { code: "221", label: "221 – La Plata" },
  { code: "223", label: "223 – Mar del Plata" },
  { code: "261", label: "261 – Mendoza" },
  { code: "264", label: "264 – San Juan" },
  { code: "291", label: "291 – Bahía Blanca" },
  { code: "341", label: "341 – Rosario" },
  { code: "342", label: "342 – Santa Fe" },
  { code: "343", label: "343 – Paraná" },
  { code: "351", label: "351 – Córdoba" },
  { code: "362", label: "362 – Resistencia" },
  { code: "376", label: "376 – Posadas" },
  { code: "379", label: "379 – Corrientes" },
  { code: "381", label: "381 – Tucumán" },
  { code: "385", label: "385 – Santiago del Estero" },
  { code: "387", label: "387 – Salta" },
  { code: "388", label: "388 – Jujuy" },
  { code: "2920", label: "2920 – Viedma" },
  { code: "3446", label: "3446 – Concordia / Chajarí" },
];
const OTHER = "OTHER";

function onlyDigits(v: string) {
  return v.replace(/\D/g, "");
}

function parseInitial(value: string) {
  const digits = onlyDigits(value);
  if (!digits) {
    return { country: COUNTRIES[0].code, has9: true, areaPreset: OTHER, area: "", number: "" };
  }
  const country = [...COUNTRIES].sort((a, b) => b.code.length - a.code.length).find((c) => digits.startsWith(c.code));
  if (!country) {
    return { country: COUNTRIES[0].code, has9: false, areaPreset: OTHER, area: "", number: digits };
  }
  let rest = digits.slice(country.code.length);
  let has9 = false;
  if (country.code === "54" && rest.startsWith("9")) {
    has9 = true;
    rest = rest.slice(1);
  }
  if (country.code === "54") {
    const match = [...AR_AREA_CODES].sort((a, b) => b.code.length - a.code.length).find((a) => rest.startsWith(a.code));
    if (match) {
      return { country: country.code, has9, areaPreset: match.code, area: match.code, number: rest.slice(match.code.length) };
    }
  }
  return { country: country.code, has9, areaPreset: OTHER, area: "", number: rest };
}

export function PhoneInput({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  const initial = parseInitial(value);
  const [country, setCountry] = useState(initial.country);
  const [has9, setHas9] = useState(initial.has9);
  const [areaPreset, setAreaPreset] = useState(initial.areaPreset);
  const [area, setArea] = useState(initial.area);
  const [number, setNumber] = useState(initial.number);

  function emit(next: { country?: string; has9?: boolean; area?: string; number?: string }) {
    const c = next.country ?? country;
    const nine = c === "54" && (next.has9 ?? has9) ? "9" : "";
    const a = next.area ?? area;
    const n = next.number ?? number;
    onChange(onlyDigits(`${c}${nine}${a}${n}`));
  }

  const selectedCountry = COUNTRIES.find((c) => c.code === country) ?? COUNTRIES[0];

  return (
    <div>
      <div className="flex flex-wrap gap-2">
        <div className="w-24">
          <select
            value={country}
            onChange={(e) => {
              const c = e.target.value;
              setCountry(c);
              if (c !== "54") {
                setHas9(false);
                setAreaPreset(OTHER);
              }
              emit({ country: c, has9: c === "54" ? has9 : false });
            }}
            className="min-h-11 w-full rounded-lg border border-gray-300 px-2 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            {COUNTRIES.map((c) => (
              <option key={c.code} value={c.code}>
                +{c.code} {c.abbr}
              </option>
            ))}
          </select>
        </div>

        {country === "54" && (
          <div className="w-28">
            <select
              value={has9 ? "9" : "0"}
              onChange={(e) => {
                const v = e.target.value === "9";
                setHas9(v);
                emit({ has9: v });
              }}
              className="min-h-11 w-full rounded-lg border border-gray-300 px-2 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="9">9 (celular)</option>
              <option value="0">Sin 9 (fijo)</option>
            </select>
          </div>
        )}

        {country === "54" ? (
          <div className="w-40">
            <select
              value={areaPreset}
              onChange={(e) => {
                const v = e.target.value;
                setAreaPreset(v);
                const a = v === OTHER ? "" : v;
                setArea(a);
                emit({ area: a });
              }}
              className="min-h-11 w-full rounded-lg border border-gray-300 px-2 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              {AR_AREA_CODES.map((a) => (
                <option key={a.code} value={a.code}>
                  {a.label}
                </option>
              ))}
              <option value={OTHER}>Otro código de área</option>
            </select>
            {areaPreset === OTHER && (
              <input
                value={area}
                onChange={(e) => {
                  const a = onlyDigits(e.target.value);
                  setArea(a);
                  emit({ area: a });
                }}
                placeholder="Ej: 3446"
                className="mt-2 min-h-11 w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            )}
          </div>
        ) : (
          <div className="w-28">
            <input
              value={area}
              onChange={(e) => {
                const a = onlyDigits(e.target.value);
                setArea(a);
                emit({ area: a });
              }}
              placeholder="Área"
              className="min-h-11 w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        )}

        <div className="min-w-32 flex-1">
          <input
            value={number}
            onChange={(e) => {
              const n = onlyDigits(e.target.value);
              setNumber(n);
              emit({ number: n });
            }}
            placeholder="Número"
            className="min-h-11 w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          />
        </div>
      </div>
      <p className="mt-1 text-xs text-gray-400">
        Se va a guardar como +{selectedCountry.code} {country === "54" && has9 ? "9 " : ""}
        {area} {number}
      </p>
    </div>
  );
}
