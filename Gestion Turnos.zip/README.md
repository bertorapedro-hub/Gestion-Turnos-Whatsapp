# Gestión de Turnos

Plataforma multi-negocio de reservas con recordatorios y confirmaciones automáticas por WhatsApp.

## Estructura

```
backend/    API (Express + TypeScript + Prisma), WhatsApp (Baileys) y el scheduler de recordatorios
frontend/   SPA (React + Vite + Tailwind): panel de negocio, panel superadmin, página pública de reservas y páginas de acción
```

## Requisitos

- Node.js 18+ (se desarrolló con Node 22)

## Puesta en marcha (desarrollo local)

```bash
npm install                      # instala backend y frontend (workspaces)
cp backend/.env.example backend/.env   # y completar los valores
cd backend
npx prisma migrate dev           # crea la base SQLite local (dev.db)
npm run seed                     # crea el usuario superadmin
cd ..
npm run dev:backend              # http://localhost:4001
npm run dev:frontend             # http://localhost:5173
```

Login superadmin: `/superadmin/login` con el usuario/clave definidos en `backend/.env` (`SUPERADMIN_USERNAME` / `SUPERADMIN_PASSWORD`).

Desde el panel de superadmin se crea cada negocio (nombre + usuario/clave del dueño). Cada negocio accede en `/admin/login` y tiene su página pública en `/reservar/<slug>`.

## Base de datos

Desarrollo: SQLite (`backend/prisma/dev.db`, gitignored). El schema evita features específicas de un motor (sin enums nativos, sin arrays) para poder pasar a PostgreSQL en producción cambiando solo `provider`/`DATABASE_URL` en `backend/prisma/schema.prisma` y `backend/.env`.

## WhatsApp

Usa [Baileys](https://github.com/WhiskeySockets/Baileys) (no oficial, conexión tipo WhatsApp Web por QR — sin Chromium, liviano). Se vincula desde el panel de negocio (`/admin/whatsapp`). La sesión se persiste en la base de datos, así que sobrevive a reinicios del servidor. **Importante:** al no ser la API oficial de Meta, existe riesgo de baneo del número si se envían muchos mensajes en poco tiempo.

## Automatizaciones

El scheduler corre cada 1 minuto (`backend/src/jobs/scheduler.ts`) y revisa, por negocio (configurable en `/admin/whatsapp`):

- Recordatorio X días antes del turno
- Recordatorio X horas antes del turno
- Aviso a turnos sin confirmar pasadas X horas de la reserva
- Resumen diario a cada profesional a la hora configurada

Los recordatorios al cliente incluyen links de un solo uso para confirmar/cancelar/modificar (`/accion/:token`), que se invalidan automáticamente al usarse o al cambiar el estado del turno por otra vía.

## Estado

Todas las funcionalidades del pedido original están implementadas y verificadas manualmente en el navegador: panel de negocio completo, panel superadmin, página pública de reservas, WhatsApp real (Baileys) y sistema de links de acción.

Pendiente: despliegue a producción. Requiere que el usuario cree la cuenta y la VM "Always Free" en Oracle Cloud (paso que no puede delegarse), y luego se completa la configuración del servidor (Docker, PostgreSQL, Nginx, HTTPS).
